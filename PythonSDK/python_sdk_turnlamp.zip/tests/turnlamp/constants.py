"""
Global test constants
"""

from enum import IntEnum


class TURNSIGNAL_LEVER(IntEnum):
    OFF = 0
    RIGHT = 1
    LEFT = -1
