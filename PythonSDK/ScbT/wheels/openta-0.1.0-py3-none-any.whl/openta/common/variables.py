import collections.abc
import typing

import allure
import numpy as np
import numpy.typing as npt
from openta.registry.registry import Registry

from . import exceptions
from .quantity import Quantity
from .variables_base import VariableDescription, VariableReference


class FrameworkVariable(VariableDescription):
    """
    A FrameworkVariable is a global alias with a unique id.
    It maps is mapped to a corresponding PortVariable,
    which allows uniform acccess of Frameworkvariable while Environments may change.
    """

    def __init__(
        self,
        identifier: str,
        dtype: npt.DTypeLike,
        unit_id: str | None,
    ) -> None:
        super().__init__(identifier, dtype, unit_id)

    @property
    def description(self) -> str:
        return "<description>"

    @property
    def value(self) -> np.generic:
        port_var = Registry().get_port_variable(self)
        return Registry().get_port(port_var.port_id).read(port_var)

    @value.setter
    def value(self, value: np.generic | Quantity | typing.Any) -> None:
        """
        Read/Write access of the named FrameworkVariable as plain value. The unit as defined in mapping is assumed.
        """
        with allure.step(f"{self} = {value}"):
            if isinstance(value, Quantity):
                raise NotImplementedError("FrameworkVariable.value prooperty setter with `Quantity` value")
            port_var = Registry().get_port_variable(self)
            return Registry().get_port(port_var.port_id).write(port_var, value)

    @property
    def quantity(self) -> Quantity:
        raise NotImplementedError("FrameworkVariable.quantity.getter")

    @quantity.setter
    def quantity(self, value: Quantity) -> None:
        """
        Read/Write access of the named FrameworkVariable as quantity.
        """
        raise NotImplementedError("FrameworkVariable.quantity.setter")

    def __str__(self) -> str:
        return self.id

    def __repr__(self) -> str:
        # return f"FrameworkVariable({self._framework_label})"
        return str(self)


class VariablesList(collections.abc.Mapping[str, FrameworkVariable]):
    """
    List of all defined Framework variables.
    Framework variables can be retrieved by dotted access or random access
    if framework labels are not valid python identifiers.
    """

    def __repr__(self):
        return str(self)

    def __str__(self):
        return "FrameworkVariables"

    def __getattr__(self, key: VariableReference | str) -> FrameworkVariable:
        """
        Look up a FrameworkVariable by name in dotted access notation.
        """
        if isinstance(key, VariableReference):
            key = key.id
        return Registry().get_framework_variable(key)

    def __getitem__(self, key: VariableReference | str) -> FrameworkVariable:
        """
        Look up a FrameworkVariable by name.
        """
        if isinstance(key, VariableReference):
            key = key.id
        return Registry().get_framework_variable(key)

    def __setitem__(self, key: VariableReference | str, value: FrameworkVariable) -> None:
        raise TypeError(f"Cannot set attribute '{key}'. The variable list is read only")

    def __len__(self) -> int:
        # look up number of frameworklabels
        return Registry().get_framework_variable_count()

    def __contains__(self, key: object) -> bool:
        try:
            if isinstance(key, (VariableReference, FrameworkVariable)):
                key = key.id
            elif not isinstance(key, str):
                raise TypeError(f"Containment check for VariabeList not supported for key of given type: {type(key)}")
            Registry().get_framework_variable(key)
        except exceptions.NotFoundError:
            return False
        return True

    def __iter__(self) -> typing.Iterator[str]:
        for v in Registry().get_framework_variables():
            yield v.id
