import numpy.typing as npt
from openta.registry.registry import Registry


class VariableDescription:
    """
    Common abstract definition of a variables.
    It consist of a
    - `id`: a unique id in the context of the variable
    - `unit_id`: ???? and
    - `dtype`: which is the dtype definitio from numpy
    """

    def __init__(self, identifier: str, dtype: npt.DTypeLike, unit_id: None | str) -> None:
        self._identifier = identifier
        self._dtype = dtype
        self._unit_id = unit_id

    @property
    def id(self) -> str:
        """
        the native port specific variable identifier.
        (currently string)
        """
        return self._identifier

    @property
    def unit_id(self) -> None | str:
        """
        The unit identifer as defined by configuration.
        """
        return self._unit_id

    @property
    def dtype(self) -> npt.DTypeLike:
        """
        The datatype of the Variable as specified by the configuration.
        """
        return self._dtype


class VariableReference:
    """
    A class simply for referencing a Framework variable and delegating all access.
    Class instances are generated for ease of use and more sophisticated documention.
    """

    def __init__(self, identifier: str):
        self._identifier = identifier

    @property
    def id(self) -> str:
        """
        the framework label identifier
        """
        return self._identifier

    def __getattr__(self, key: str) -> object:
        return getattr(Registry().get_framework_variable(self.id), key)
