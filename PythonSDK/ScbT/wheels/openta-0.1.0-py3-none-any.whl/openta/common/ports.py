import collections.abc
import enum
import typing
from abc import ABC, abstractmethod

import numpy as np
import numpy.typing as npt
from openta.common.capture import AbstractCapture
from openta.common.variables_base import VariableDescription
from openta.registry.registry import Registry

from . import exceptions


class PortVariable(VariableDescription):
    """
    Common abstract definition of a port specific variable.
    It consist of a
    - `id`: port specific identifier, which is only meaningful for a specific port, this variable is used to access
    - `unit_id`: ???? and
    - `dtype`: which is the dtype definitio from numpy
    """

    def __init__(
        self,
        identifier: str,
        port_id: str,
        dtype: npt.DTypeLike,
        unit_id: None | str,
    ) -> None:
        super().__init__(identifier, dtype, unit_id)
        self._port_id = port_id

    @property
    def port_id(self) -> str:
        """
        The port identifier of current PortVariable
        """
        return self._port_id

    def __eq__(self, other: object):
        if isinstance(other, PortVariable):
            return (
                self.id == other.id
                and self.port_id == other.port_id
                and self.unit_id == other.unit_id
                and self.dtype == other.dtype
            )
        return False


class PortState(enum.IntEnum):
    RELEASED = 0
    """
    The port is not yet created or already released.
    """

    CREATED = 1
    """
    The port is created but no yet configured or connected.
    """

    CONNECTED = 2
    """
    The port is configured and connected.
    """

    STARTED = 3
    """
    The port is started. The meanings depends on the port.
    """


class AbstractPort(ABC):
    """
    Abstract base class for Port.
    This class acts as configuration, placeholder and wrapper around to be created instances
    for accessing hardware or software components.
    """

    def __init__(
        self,
        name: str,
        config: dict[str, typing.Any],
    ) -> None:
        """
        Initialize the port.
        This merely creates this wrapping Port instance.
        """
        self._name = name
        self.config = config

    @property
    def name(self) -> str:
        """
        The name of the port as defined by the configuration
        """
        return self._name

    def get_option(
        self,
        key: str | tuple[str] | list[str],
        config: dict[str, typing.Any] | None = None,
        raise_error: bool = False,
        default: typing.Any | None = None,
    ) -> typing.Any:
        """
        get a keyword argument from provided `config` or the `config` provided to port __init__.
        if the key is not existent in at least one config object, either an exception is raised if `raise_error` is true
        or the `default` is returned.
        """
        if isinstance(key, str):
            key = (key,)
        if config is not None:
            for k in key:
                if k in config:
                    return config[k]
        for k in key:
            if k in self.config:
                return self.config[k]
        if raise_error:
            if len(key) == 1:
                raise exceptions.PortConfigError(
                    f"{self.__class__.__name__} '{self.name}': Missing mandatory configuration '{key[0]}'."
                )
            keys = ", ".join([f"{k}" for k in key])
            raise exceptions.PortConfigError(
                f"{self.__class__.__name__} '{self.name}': Missing mandatory configuration for one of the following similar keys: {keys}"
            )
        return default

    @property
    @abstractmethod
    def state(self) -> PortState:
        """
        Get the current state of the port.
        """

    @property
    @abstractmethod
    def origin(self) -> typing.Any:
        """
        Get the underlying/wrapped port representation, whatever it may be.
        Implementations have to raise `PortStateError` if that object
        is not available because the port is already in RELEASED state.
        """

    @abstractmethod
    def create(self, **kwargs: typing.Any) -> None:
        """
        Create the underlying/wrapped port.
        """

    @abstractmethod
    def connect(self, **kwargs: typing.Any) -> None:
        """
        Configure the underlying/wrapped port and connect it.
        """

    @abstractmethod
    def start(self, **kwargs: typing.Any) -> None:
        """
        start the port in order to work with it.
        """

    @abstractmethod
    def stop(self, **kwargs: typing.Any) -> None:
        """
        stop the port, this is the counterpart of stop.
        A stopped port can be started again
        """

    @abstractmethod
    def disconnect(self, **kwargs: typing.Any) -> None:
        """
        Disconnect the Port
        """

    @abstractmethod
    def release(self, **kwargs: typing.Any) -> None:
        """
        Release the port...
        """

    @abstractmethod
    def read(self, variable: PortVariable) -> np.generic:
        """
        Read the given FrameworkLabel from platform, with XIL API Framework.
        A quantity as specified in Mapping is returned.
        """

    @abstractmethod
    def write(self, variable: PortVariable, value: np.generic | float | int | bool | str) -> None:
        """
        Write the given value Quantity to platform, with XIL API Framework.
        """

    @abstractmethod
    def create_capture(self, **kwargs: typing.Any) -> AbstractCapture:
        """
        Create a capture object for measuring data.
        The port instantiates a port specific capture object.
        Provided keyword arguments are be passed to the created capture.
        """


class PortList(collections.abc.Mapping[str, AbstractPort]):
    """
    Registry of all configured ports.
    A port is accessible by its configured identifier.
    """

    def __getattr__(self, port_id: str) -> AbstractPort:
        """
        Look up a Port by name in dotted access notation.
        """
        return Registry().get_port(port_id)

    def __getitem__(self, port_id: str) -> AbstractPort:
        """
        Look up a Port by given port_id.
        """
        return Registry().get_port(port_id)

    def __setitem__(self, port_id: str, value: AbstractPort) -> None:
        raise TypeError(f"Cannot set attribute '{port_id}'. The port list is read only")

    def __len__(self) -> int:
        """
        get the number of ports.
        """
        return Registry().get_port_count()

    def __contains__(self, key: object) -> bool:
        try:
            if not isinstance(key, str):
                raise TypeError(f"Containment check for PortList not supported for key of given type: {type(key)}")
            Registry().get_port(key)
        except exceptions.NotFoundError:
            return False
        return True

    def __iter__(self) -> typing.Iterator[str]:
        for p in Registry().get_ports():
            yield p.name

    def __reversed__(self):
        for p in reversed(Registry().get_ports()):
            yield p.name
