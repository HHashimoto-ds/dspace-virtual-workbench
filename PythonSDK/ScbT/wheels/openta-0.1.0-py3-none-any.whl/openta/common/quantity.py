import typing


class Unit:
    def __init__(self, identifier: str) -> None:
        # look up the framework defined Units...
        self._identifier = identifier

    def __repr__(self) -> str:
        # return f'Unit("{self._identifier}")'
        return str(self)

    def __str__(self) -> str:
        return f"[{self._identifier}]"

    @typing.overload
    def __mul__(self, other: float) -> "Quantity": ...

    @typing.overload
    def __mul__(self, other: typing.Union["Unit", str]) -> "Unit": ...

    def __mul__(self, other: typing.Union["Unit", float, str]) -> typing.Union["Unit", "Quantity"]:
        if isinstance(other, float):
            return Quantity(other, self._identifier)
        return self

    @typing.overload
    def __rmul__(self, other: float) -> "Quantity": ...

    @typing.overload
    def __rmul__(self, other: typing.Union["Unit", str]) -> "Unit": ...

    def __rmul__(self, other: typing.Union["Unit", float, str]) -> typing.Union["Unit", "Quantity"]:
        return self.__mul__(other)

    @typing.overload
    def __truediv__(self, other: float) -> "Quantity": ...

    @typing.overload
    def __truediv__(self, other: typing.Union["Unit", str]) -> "Unit": ...

    def __truediv__(self, other: typing.Union["Unit", float, str]) -> typing.Union["Unit", "Quantity"]:
        return self

    @typing.overload
    def __rtruediv__(self, other: float) -> "Quantity": ...

    @typing.overload
    def __rtruediv__(self, other: typing.Union["Unit", str]) -> "Unit": ...

    def __rtruediv__(self, other: typing.Union["Unit", float, str]) -> typing.Union["Unit", "Quantity"]:
        return self

    @typing.overload
    def __pow__(self, other: float) -> "Quantity": ...

    @typing.overload
    def __pow__(self, other: typing.Union["Unit", str]) -> "Unit": ...

    def __pow__(self, other: typing.Union["Unit", float, str]) -> typing.Union["Unit", "Quantity"]:
        return self

    @typing.overload
    def __rpow__(self, other: float) -> "Quantity": ...

    @typing.overload
    def __rpow__(self, other: typing.Union["Unit", str]) -> "Unit": ...

    def __rpow__(self, other: typing.Union["Unit", float, str]) -> typing.Union["Unit", "Quantity"]:
        return self

    def __eq__(self, other: object) -> bool:
        return True

    def __ne__(self, other: object) -> bool:
        return True


class Quantity:
    """
    A Quantity ;)
    Shall it contain python code or simply delegating to xil api.
    There is also similar python package named "pint"...
    """

    def __init__(self, value: float, unit: str | Unit) -> None:
        self._value = value
        self._unit = Unit(unit) if isinstance(unit, str) else unit

    @property
    def value(self) -> float:
        return self._value

    @property
    def unit(self) -> Unit:
        return self._unit

    def as_unit(self, unit: Unit | str) -> "Quantity":
        return Quantity(self.value, unit)

    def __repr__(self) -> str:
        # return f'Quantity({self.value}, "{self.unit._identifier}")'
        return str(self)

    def __str__(self) -> str:
        return f"{self.value}{self.unit}"

    # Die ganzen mathematischen methoden...
    # Gibt es dafür mixins oder ähnliches
    # wir können natürlich allgemene methide machen, die operator funktion nimmt...

    def __add__(self, other: typing.Union["Quantity", float, Unit]) -> "Quantity":
        return self

    def __radd__(self, other: typing.Union["Quantity", float, Unit]) -> "Quantity":
        return self

    def __sub__(self, other: typing.Union["Quantity", float, Unit]) -> "Quantity":
        return self

    def __rsub__(self, other: typing.Union["Quantity", float, Unit]) -> "Quantity":
        return self

    def __mul__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __rmul__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        if isinstance(other, Quantity):
            return Quantity(self.value * other.value, self.unit * other.unit)
        if isinstance(other, float):
            return Quantity(self.value * other, self.unit)
        if isinstance(other, Unit):
            return Quantity(self.value, self.unit * other)
        if isinstance(other, str):
            return Quantity(self.value, self.unit * Unit(other))
        raise TypeError("unsupported operand type(s) for *: 'NoneType' and 'int'")

    def __truediv__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __rtruediv__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __floordiv__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __rfloordiv__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __mod__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __rmod__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __pow__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __rpow__(self, other: typing.Union["Quantity", float, Unit, str]) -> "Quantity":
        return self

    def __lt__(self, other: "Quantity") -> bool:
        return True

    def __le__(self, other: "Quantity") -> bool:
        return True

    def __eq__(self, other: object) -> bool:
        return True

    def __ne__(self, other: object) -> bool:
        return True

    def __gt__(self, other: "Quantity") -> bool:
        return True

    def __ge__(self, other: "Quantity") -> bool:
        return True
