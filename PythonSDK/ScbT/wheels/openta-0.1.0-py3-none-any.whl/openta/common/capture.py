import enum
import os
import pathlib
import typing
from abc import ABC, abstractmethod

from evaluationlib.core.signal import Signal
from openta.common.variables import FrameworkVariable

if typing.TYPE_CHECKING:
    from openta.common.ports import AbstractPort


class CaptureState(enum.IntEnum):
    RELEASED = 0
    """
    The wrapped (3rd party) port specific capture is already released.
    """

    CONFIGURED = 1
    """
    The capture is created and configured.
    """

    ACTIVATED = 2
    """
    The capture is started and waiting for an optional start trigger.
    """

    RUNNING = 3
    """
    The capture is running.
    """

    FINISHED = 4
    """
    The capture has finished and can be stopped.
    """


class AbstractCapture(ABC):
    """
    Abstract base class for openta captures that provides a common and abstract interface,
    that shields port-specific or 3rd party related differences.
    """

    @property
    @abstractmethod
    def port(self) -> "AbstractPort":
        """
        Get the corresponding openta port instance.
        """

    @property
    @abstractmethod
    def state(self) -> CaptureState:
        """
        Get the current state of the capture.
        """

    @property
    @abstractmethod
    def origin(self) -> typing.Any | None:
        """
        Get the underlying/wrapped (3rd party) port specific object.
        Returned value is implementation specific and may be None.
        """

    @property
    @abstractmethod
    def raster_name(self) -> str:
        """
        Get the defined measurement raster.
        """

    @property
    @abstractmethod
    def variables(self) -> typing.Iterable[FrameworkVariable]:
        """
        Get the defined variables as iterable of FrameworkVariables.
        The variables to capture cannot be changed by modifying the returned collection,
        but must be set as a whole.
        """

    @variables.setter
    @abstractmethod
    def variables(self, value: typing.Iterable[FrameworkVariable | str]) -> None:
        """
        Set the variables to capture.+
        Provided strings are treated as alises (names of FrameworkVariables) and looked up in the configured mapping.
        """

    @property
    @abstractmethod
    def datafile_path(self) -> pathlib.Path | None:
        """
        Teturn the specified path to a datafile, if any.
        """

    @datafile_path.setter
    @abstractmethod
    def datafile_path(self, value: str | os.PathLike[str]) -> None:
        """
        Set a file path to a datafile, which is created while capturing.
        The file type may be determined from the suffix.
        The implementation is port specific, but for XIL API ports
        it is assumed to be a single mf4 file.
        """

    @abstractmethod
    def set_start_trigger(self, condition: str, delay: float | None = None) -> None:
        """
        Set an optional start trigger.
        After `start()` the capturing then waits for the condition to be satisfied.
        """

    @abstractmethod
    def set_stop_trigger(self, condition_or_duration: str | float, delay: float | None = None) -> None:
        """
        Set an optional stop trigger.
        If the capturing is in `RUNNING` state it waits for the condition to be fulfilled.
        """

    @abstractmethod
    def start(self) -> None:
        """
        Start the capture process.
        """

    @abstractmethod
    def stop(self) -> None:
        """
        Stop the capture process.
        """

    @abstractmethod
    def release(self) -> None:
        """
        Release the wrapped (3rd party) port specific capture object
        """

    @abstractmethod
    def get_signal(self, variable: FrameworkVariable | str) -> Signal:
        """
        Get the captured values as evaluationlib signal object.
        To retrieve the signal, the capture has to be in `FINISHED` state.
        """
