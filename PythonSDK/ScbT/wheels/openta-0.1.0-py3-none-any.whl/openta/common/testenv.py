import logging
import types
import typing

import allure
from openta.common.ports import PortList, PortState
from openta.common.variables import VariablesList
from openta.registry.registry import Registry

_logger = logging.getLogger("openta")


class TestEnvironmentAccess:
    """
    Currently used as fixture in pytest to grant access to `vars` and `ports` list.
    """

    # This prevents pytest from collecting this class.
    __test__ = False

    def __enter__(self) -> None:
        """
        Start/Initialize the Framework as configured
        """
        self.setup()

    def __exit__(
        self,
        exc_type: typing.Type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> bool:
        """
        Shutdown Framework and release ports in reverse order.
        """
        self.teardown()
        return False

    def __init__(self) -> None:
        self._ports = PortList()
        self._framework_labels = VariablesList()

    def setup(self):
        with allure.step("XIL create ports"):
            _logger.info("XIL create ports")
            for port in Registry().get_ports():
                target_state = port.get_option("target_state", default=PortState.CREATED)

                if target_state >= PortState.CREATED:
                    port.create()

                # configure
                if target_state >= PortState.CONNECTED:
                    port.connect()

                # and start if needed
                if target_state >= PortState.STARTED:
                    port.start()

    def teardown(self):
        """
        Shutdown Framework
        """
        with allure.step("XIL release port."):
            _logger.info("XIL release port.")
            # Shutdown ports in reverse order
            for port in reversed(Registry().get_ports()):
                if port.state >= PortState.STARTED:
                    port.stop()

                if port.state >= PortState.CONNECTED:
                    port.disconnect()

                port.release()

    @property
    def vars(self) -> VariablesList:
        return self._framework_labels

    @property
    def ports(self) -> PortList:
        """
        get the collection of all defined FrameworkLabels from active mapping.
        The returned FrameworkLabels collections supports random access [] as well as
        dotted access of named aliases.
        """
        return self._ports
