# -*- coding: utf-8 -*-
"""
Description: This module implements a logging.FileHandler that logs messages to a file.
"""

# ------------------------------------------------------------------------------
# module imports
# ------------------------------------------------------------------------------
import logging

logger = logging.getLogger("openta")
