class ConfigurationError(Exception):
    pass


class RegistryError(Exception):
    pass


class AlreadyExistsError(RegistryError):
    """
    An item of given `kind` cannot be registered with given `key`,
    because another item is already registered with that key.
    """

    def __init__(self, key: str, kind: str, existing: object, new: object) -> None:
        super().__init__(f"Cannot register given {kind} as '{key}'. An item with that associated key already exists.")
        self.key = key
        self.kind = kind
        self.existing_repr = repr(existing)
        self.new_repr = repr(new)


class NotFoundError(RegistryError):
    """
    An item of `kind` cannot be found in registry.
    """

    def __init__(self, key: str, kind: str) -> None:
        super().__init__(f"A {kind} item with key '{key}' is not registered.")
        self.key = key
        self.kind = kind


class PortError(Exception):
    pass


class PortTypeError(PortError):
    pass


class PortConfigError(PortError):
    pass


class PortStateError(PortError):
    pass


class CaptureError(Exception):
    pass


class CaptureStateError(CaptureError):
    pass


class ScenarioError(Exception):
    pass


class ScenarioConfigError(ScenarioError):
    pass
