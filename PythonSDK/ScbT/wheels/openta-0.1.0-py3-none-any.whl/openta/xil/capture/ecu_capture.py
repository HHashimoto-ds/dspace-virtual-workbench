from openta.common import exceptions
from openta.common.ports import AbstractPort
from openta.xil.capture.xil_capture import XILCapture


class ECUCapture(XILCapture):
    """
    A dSPACE XIL API ECUPort specific capture object.
    Start and stop trigger are not supported.
    """

    def __init__(self, port: AbstractPort, raster_name: str | None = None):
        """
        Create port specific capture.
        Note that this has to stops a measurement on the ecuport.
        """
        # duck typing for dSPACE XIL API ECUPort (M & C)
        if not (hasattr(port, "start_measurement") or hasattr(port, "stop_measurement")):
            raise exceptions.CaptureError(
                f"Cannot create ECUCapture for '{port}' port instance. Expected a dSPACE XIL API ECUPort."
            )
        # port must not be in measurement mode, when capture is created
        # note that the port is passed to supers constructor, thus we use the parameter directly here
        port.stop_measurement()
        super().__init__(port, raster_name)

    def set_start_trigger(self, condition: str, delay: float | None = None):
        """
        Configure the start trigger condition of this capture.
        Only ConditionWatcher supported.
        """
        raise NotImplementedError("Trigger is not supported on ECUCapture.")

    def set_stop_trigger(self, condition_or_duration: str | float, delay: float | None = None):
        raise NotImplementedError("Trigger is not supported on ECUCapture.")

    def start(self) -> None:
        """
        start the capture.
        For ECU port the measurement has to be started beforehand.
        """
        self.port.start_measurement()
        super().start()
