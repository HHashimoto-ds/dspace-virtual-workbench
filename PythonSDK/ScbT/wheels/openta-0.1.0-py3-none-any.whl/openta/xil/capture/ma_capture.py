import importlib
import logging
import time
import typing

from openta.common.capture import CaptureState
from openta.registry.registry import Registry
from openta.xil import ges
from openta.xil.capture.xil_capture import XILCapture
from System.Collections.Generic import Dictionary

_logger = logging.getLogger("openta")


class ModelCapture(XILCapture):
    """
    An XIL API MAPort specific Capture object
    """

    def stop(self) -> None:
        """
        stop the capture and store capture result
        """
        if self.origin.StartTriggerWatcher is not None:
            # Waiting for StopTrigger -> Capture reach state FINISHED
            while self.state != CaptureState.FINISHED:
                time.sleep(0.1)

        super().stop()

    def _create_defines(self, condition_term: str) -> typing.Any:
        """
        Extract Frameworkvariable identifier from condition term and setup defines map.
        Return .NET dictionary
        """
        variable_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
        defines = Dictionary[str, variable_ref.IVariableRef]()
        for alias in ges.get_framework_label_from_condition_term(condition_term):
            try:
                test_bench_path = Registry().get_port_variable(alias).id
            except Exception:
                _logger.warning("Unkown identifier %s in condition term %s.", alias, condition_term)
                continue

            # dSPACE Limitation: Only ValueRepresentation of type eRawValue supported
            # These are the defines for the trigger condition, evaluation on the platform,
            # so it makes sense to only support raw values here
            var_reference = self.port.testbench.VariableRefFactory.CreateGenericVariableRef(
                test_bench_path, variable_ref.Enum.ValueRepresentation.eRawValue
            )
            defines.Add(alias, var_reference)
        return defines

    def set_start_trigger(self, condition: str, delay: float | None = None):
        """
        Configure the start trigger condition of this capture.
        Only ConditionWatcher supported.
        """
        defines = self._create_defines(condition)
        watcher = self.port.testbench.WatcherFactory.CreateConditionWatcher2(condition, defines)

        duration = self.port.testbench.DurationFactory.CreateTimeSpanDuration(delay if delay is not None else 0.0)
        self.origin.SetStartTrigger(watcher, duration)

    def set_stop_trigger(self, condition_or_duration: str | float, delay: float | None = None):
        """
        Configure the stop trigger condition of this capture.
        Condition and Duration Watcher supported.
        """
        if isinstance(condition_or_duration, str):
            defines = self._create_defines(condition_or_duration)
            watcher = self.port.testbench.WatcherFactory.CreateConditionWatcher2(condition_or_duration, defines)
        elif isinstance(condition_or_duration, float):
            watcher = self.port.testbench.WatcherFactory.CreateDurationWatcherByTimeSpan(condition_or_duration)
        else:
            raise Exception("Stop trigger condition must be a string or float value.")

        stop_delay = self.port.testbench.DurationFactory.CreateTimeSpanDuration(delay if delay is not None else 0.0)
        self.origin.SetStopTrigger(watcher, stop_delay)
