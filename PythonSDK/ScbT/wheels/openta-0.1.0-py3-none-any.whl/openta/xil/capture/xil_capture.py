import importlib
import logging
import os
import pathlib
import traceback
import typing

# ToDo: Dependencies concept
from evaluationlib.core.signal import Signal
from openta.common import exceptions
from openta.common.capture import AbstractCapture, CaptureState
from openta.common.ports import AbstractPort
from openta.common.variables import FrameworkVariable
from openta.registry.registry import Registry
from openta.xil.ports.xil_port import XilPort
from System import Array

_logger = logging.getLogger("openta")


class XILCapture(AbstractCapture):
    """
    Common intermediate implementation of XIL API Captures.
    This is the common (still abstract) base class for `ModelCapture` and `ECUCapture`.
    """

    def __init__(self, port: AbstractPort, raster_name: str | None = None):
        if not isinstance(port, XilPort):
            raise ValueError("Port provided to XILCapture has to be a XILPort")

        self._port: XilPort = port

        # If no raster_name is provided, take the first one...
        self._raster_name: str = raster_name if raster_name is not None else port.origin.TaskNames[0]
        try:
            self._capture = self.port.origin.CreateCapture(self._raster_name)
        except Exception as err:
            raise exceptions.CaptureError(
                f"Failed to create XIL API '{self._port.name}' port capture with '{self._raster_name}' raster. :: {traceback.format_exception_only(err)}"
            ) from err

        self._capture_writer = None
        self._capture_result = None

        self._variables: list[FrameworkVariable] = []
        self._mf4_filepath = None

    @property
    def datafile_path(self) -> pathlib.Path | None:
        """
        Returns the configured path to the mf4 capture data file.
        None if not configured.
        """
        return self._mf4_filepath

    @datafile_path.setter
    def datafile_path(self, value: os.PathLike[str] | str) -> None:
        """
        Path of capture result mf4 file (optional)
        """
        p = pathlib.Path(value)
        if not p.suffixes:
            p = p.with_suffix(".mf4")
        elif p.suffix.lower() != ".mf4":
            raise exceptions.CaptureError("Expected filename with .mf4 suffix")
        self._mf4_filepath = p

    @property
    def variables(self) -> list[FrameworkVariable]:
        """
        Collection of alias identifer to capture
        """
        return self._variables

    @variables.setter
    def variables(self, value: typing.Iterable[FrameworkVariable | str]) -> None:
        """
        Collection of alias identifer to capture
        """
        variable_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
        reg = Registry()

        # create list of FrameworkVariabkes from argument, will be stored if setting to XIL origin succeeds
        fw_variables = [
            item if isinstance(item, FrameworkVariable) else reg.get_framework_variable(item) for item in value
        ]

        # Ceate XIL API VariableRef instances
        xil_variable_refs = [
            self._create_variable_reference(Registry().get_port_variable(fw_variable).id)
            for fw_variable in fw_variables
        ]

        self.origin.Variables2 = Array[variable_ref.IVariableRef](xil_variable_refs)
        self._variables = fw_variables

    @property
    def raster_name(self) -> str:
        """
        Task name for capture process
        (optional) If not set first task of port is used.
        """
        # ToDo: Make used default task from port available?
        return self._raster_name

    @raster_name.setter
    def raster_name(self, value: str) -> None:
        """
        Configure capture task
        """
        raise exceptions.CaptureError("For XIL API Captures the `raster_name` cannot be changed.")

    @property
    def origin(self) -> typing.Any:
        """
        Get the underlying XIL API Capture object.
        """
        return self._capture

    @property
    def port(self) -> XilPort:
        """
        Get the corresponding port object.
        """
        return self._port

    @property
    def state(self) -> CaptureState:
        if self._capture is None:
            return CaptureState.RELEASED

        # NOTE: the numbers are differently ordered as for ma_port
        state = int(self._capture.State)
        if state == 0:  # eCONFIGURED
            return CaptureState.CONFIGURED
        if state == 1:  # eACTIVATED
            return CaptureState.ACTIVATED
        if state == 2:  # eRUNNING
            return CaptureState.RUNNING
        if state == 3:  # eFINISHED
            return CaptureState.FINISHED
        raise exceptions.CaptureStateError(
            f"Unable to determine XIL API Capture state. Retrieved state unknown: {state}"
        )

    @property
    def duration(self) -> float:
        """
        Get the duration of finished capture in seconds.
        """
        return 0.0

    def release(self) -> None:
        """
        Call dispose of XIL capture and release member
        """
        if self._capture is not None:
            self._capture.Dispose()

        self._capture = None

    def __del__(self):
        self.release()
        self._capture_result = None
        self._port = None

    def start(self) -> None:
        """
        start the model access port capture
        """
        capturing_factory = self.port.testbench.CapturingFactory
        if self._mf4_filepath:
            writer = capturing_factory.CreateCaptureResultMDFWriterByFileName(os.fspath(self._mf4_filepath))
        else:
            writer = capturing_factory.CreateCaptureResultMemoryWriter()

        self.origin.Start(writer)

    def stop(self) -> None:
        """
        stop the capture and store capture result
        """
        self.origin.Stop()

        self._prepare_capture_result()

    def _create_value_repr(self, value_rep: str):
        """
        Create an ASAM value representation item
        """
        # TODO Support of raw/physical values in general. In special remove strings here
        variable_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
        if value_rep and value_rep.upper() == "ERAWVALUE":
            return variable_ref.Enum.ValueRepresentation.eRawValue
        else:
            return variable_ref.Enum.ValueRepresentation.ePhysicalValue

    def _create_variable_reference(self, test_bench_path: str):
        """
        Create a ASAM.XIL.VariableReference item
        """
        return self.port.testbench.VariableRefFactory.CreateGenericVariableRef(
            test_bench_path, self._create_value_repr("ePhysicalValue")
        )

    def _prepare_capture_result(self):
        """
        Post processing step after capture to prepare capture result member.
        """
        # Capturing has finished.
        # If mf4 data has been captured open storage file for capture result item.
        if not self._capture_result and self._mf4_filepath and self._mf4_filepath.exists():
            self._capture_result = self.port.testbench.CapturingFactory.CreateCaptureResult()
            reader = self.port.testbench.CapturingFactory.CreateCaptureResultMDFReaderByFileName(
                os.fspath(self._mf4_filepath)
            )
            # Open the mf4 file for capture result. CaptureResult than ready to extract single signals.
            self._capture_result.Open(reader)
        # In case of memory writer, get capture result.
        elif not self.datafile_path:
            self._capture_result = self.origin.CaptureResult

    # def get_signal(self, key: FrameworkVariable | str, value_rep: str | None = None) -> Signal:
    def get_signal(self, variable: FrameworkVariable | str) -> Signal:
        """
        Get signal from captures measured data by alias name.
        """
        port_variable = Registry().get_port_variable(variable)
        testbench_path = port_variable.id

        # Get Signal from capture result
        if self._capture_result:
            var_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
            rep = var_ref.Enum.ValueRepresentation.ePhysicalValue

            for cap_sig_group in self._capture_result.SignalGroups:
                for sig_info in cap_sig_group.SignalInfos:
                    if sig_info.Name == testbench_path:
                        variable = self.port.testbench.VariableRefFactory.CreateGenericVariableRef(testbench_path, rep)

                        yValue = list(cap_sig_group.GetScalarSignalValues(variable).Value)
                        xValue = list(cap_sig_group.GetTimestamps(rep).Value)
                        return Signal(xValue, yValue)

        raise exceptions.CaptureError(
            f"Cannot extract signal '{variable}' with path '{testbench_path}' from capture result of port {self.port.name}. Capture result is not set."
        )

    def __getitem__(self, key: str | FrameworkVariable) -> Signal:
        return self.get_signal(key)
