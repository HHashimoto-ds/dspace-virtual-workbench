import os
import pathlib
import typing
from xml.etree import ElementTree

#
# currently unused....
#


class FrameworkConfigReader:
    def __init__(self, filename: str | os.PathLike[str]) -> None:
        self._config_filename = pathlib.Path(os.fspath(filename))

        self._etree_root = ElementTree.parse(self._config_filename).getroot()
        self._namespace = self._etree_root.tag.split("}")[0].strip("{")

    @property
    def mapping_files(self) -> typing.Generator[pathlib.Path]:
        for item in self._etree_root.iterfind(".//ns:MappingFileList/ns:MappingFile", {"ns": self._namespace}):
            yield self._config_filename.parent / os.fspath(item.text)
