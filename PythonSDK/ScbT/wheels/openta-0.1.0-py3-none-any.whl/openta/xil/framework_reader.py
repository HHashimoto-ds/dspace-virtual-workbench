import logging
import os
import xml.etree.ElementTree

from openta.common.ports import PortList
from openta.common.variables import VariablesList
from openta.registry.registry import Registry
from openta.xil.testbench import TestbenchProvider

from .mapping_reader import MappingReader
from .ports.ecu_port import ECUPort
from .ports.ma_port import MAPort

_logger = logging.getLogger("openta")


class FrameworkReader:
    """
    Read the specified framework configuration file and create ports and
    mapping items and add them
    """

    def __init__(self, config: str | os.PathLike[str]) -> None:
        """
        Configure Testbenchfactory by config.xml.
        """
        self.config_file = os.fspath(config)
        _logger.info("configure XIL API according to: '%s'", self.config_file)

        self._ports = PortList()
        self._framework_labels = VariablesList()

        self._etree_root = xml.etree.ElementTree.parse(self.config_file).getroot()
        self._namespace = self._etree_root.tag.split("}")[0].strip("{")

    def _get_xil_version(self):
        return self._namespace.split("/")[-1]

    def add_to_registry(self):
        self.CreatePorts()
        self._create_mapping()

    def CreatePorts(self):
        ns = {"ns": f"{self._namespace}"}

        # Alle MAPortDefinition-Elemente finden
        port_definitions = self._etree_root.findall(".//ns:PortDefinitionList/*", ns)

        # Informationen zu den PortDefinitions ausgeben
        for port_def in port_definitions:
            port_type = port_def.tag.split("}")[-1]
            instance_name = port_def.get("InstanceName")
            # init_order = port.get('InitOrder')
            # shutdown_order = port.get('ShutdownOrder')
            vendor_name = str(port_def.find("ns:VendorName", ns).text)
            product_name = str(port_def.find("ns:ProductName", ns).text)
            product_version = str(port_def.find("ns:ProductVersion", ns).text)

            tb_key = (vendor_name, product_name, product_version)
            tb = TestbenchProvider().get_testbench(*tb_key)

            configfilepath = ""
            configs = port_def.findall(".//ns:PortConfigurationFile", ns)
            if len(configs) == 1:
                configfilepath = configs[0].text

            if configfilepath:
                configfilepath = os.path.join(os.path.dirname(self.config_file), configfilepath)

            # Create ecu ports
            if port_type == "ECUMPortDefinition":
                _logger.info("register %s port: '%s'", "dSPACE ECU", instance_name)
                loading_type = port_def.find(".//ns:LoadingType", ns).text
                port = ECUPort(instance_name, tb, {"port_config_file": configfilepath, "loading_type": loading_type})
                Registry().add_port(port)

            # Create ma ports
            elif port_type == "MAPortDefinition":
                _logger.info("register %s port: '%s'", "MAPort", instance_name)
                force_config = port_def.find(".//ns:ForceConfig", ns).text.lower() == "true"
                port = MAPort(instance_name, tb, {"port_config_file": configfilepath, "force_config": force_config})
                Registry().add_port(port)

    def _create_mapping(self):
        ns = {"ns": self._namespace}

        config_folder = os.path.dirname(self.config_file)
        mapping_files = [
            os.path.join(config_folder, os.fspath(f.text))
            for f in self._etree_root.findall(".//ns:MappingFileList/ns:MappingFile", ns)
        ]

        reader = MappingReader(mapping_files)
        reader.add_to_registry()
