import numpy as np

# TODO : save import stuff
# TODO: Currently moved to __init__.py
# _assembly_path = os.path.abspath(os.path.dirname(__file__))
# clr.AddReference(os.path.join(_assembly_path, "dSPACE.Common.XilMappingHandler.dll"))
# clr.AddReference(os.path.join(_assembly_path, "dSPACE.Common.XilMappingHandlerInterfaces.dll"))
# ruff: noqa: E402
# import of C# dlls not at top file, because we first havge to add the refrences to dlls
from dSPACE.Common.XilMappingHandler import XilMapping
from dSPACE.Common.XilMappingHandlerInterfaces import ValueType, VariableType

from openta.common.exceptions import ConfigurationError
from openta.common.ports import PortVariable
from openta.common.variables import FrameworkVariable
from openta.registry.registry import Registry

MAP_VALUETYPE_TO_DTYPE = {
    int(ValueType.FloatValue): np.dtype("float64"),
    int(ValueType.IntValue): np.dtype("int64"),
    int(ValueType.UintValue): np.dtype("uint64"),
    int(ValueType.StringValue): np.dtype("str"),
    int(ValueType.BooleanValue): np.dtype("bool"),
    int(ValueType.IntVectorValue): np.dtype("int64"),
    int(ValueType.FloatVectorValue): np.dtype("float64"),
    int(ValueType.UintVectorValue): np.dtype("uint64"),
    int(ValueType.StringVectorValue): np.dtype("str"),
    int(ValueType.BooleanVectorValue): np.dtype("bool"),
    int(ValueType.IntMatrixValue): np.dtype("int64"),
    int(ValueType.UintMatrixValue): np.dtype("uint64"),
    int(ValueType.FloatMatrixValue): np.dtype("float64"),
    int(ValueType.StringMatrixValue): np.dtype("str"),
    int(ValueType.BooleanMatrixValue): np.dtype("bool"),
}


MAP_VARIABLETYPE_TO_DTYPE = {
    int(VariableType.UIntVariable): np.dtype("uint64"),
    int(VariableType.IntVariable): np.dtype("int64"),
    int(VariableType.FloatVariable): np.dtype("float64"),
    int(VariableType.BoolVariable): np.dtype("bool"),
    int(VariableType.StringVariable): np.dtype("str"),
    int(VariableType.UIntVectorVariable): np.dtype("uint64"),
    int(VariableType.IntVectorVariable): np.dtype("int64"),
    int(VariableType.FloatVectorVariable): np.dtype("float64"),
    int(VariableType.BoolVectorVariable): np.dtype("bool"),
    int(VariableType.StringVectorVariable): np.dtype("str"),
    # [ ... ]
}


class MappingReader:
    def __init__(self, fileNames: list[str]):
        if isinstance(fileNames, str):
            fileNames = [fileNames]

        if len(fileNames) == 0:
            raise ConfigurationError("No Mapping files are specified")
        elif len(fileNames) > 1:
            raise ConfigurationError("We are sorry, currently only ONE Mapping file is supported.")

        self._filename = fileNames[0]

    def add_to_registry(self):
        # try:
        xilMapping = XilMapping()

        # currently only one, So no merge needed, later possible
        xilMapping.Load(self._filename)
        if xilMapping.ErrorMessage:
            raise Exception(f"Failed to read XIL API Mapping: {xilMapping.ErrorMessage}")

        try:
            testbenchtype = {
                (item.PortId, item.Id): MAP_VALUETYPE_TO_DTYPE[int(item.SimpleType.Type)]
                for item in xilMapping.TestbenchLabels
            }
        except KeyError as err:
            raise Exception("Unsupported XIL API Mapping ValueType") from err

        try:
            frameworktype = {
                (item.Id): MAP_VARIABLETYPE_TO_DTYPE[int(item.Type)] for item in xilMapping.FrameworkLabels
            }
        except KeyError as err:
            raise Exception("Unsupported XIL API Mapping VariableType") from err

        registry = Registry()
        for item in xilMapping.LabelMappings:
            fw_var = FrameworkVariable(
                str(item.FrameworkLabelReference.LabelId),
                frameworktype[item.FrameworkLabelReference.LabelId],
                None,
            )

            port_var = PortVariable(
                str(item.TestbenchLabelReference.LabelId),
                str(item.TestbenchLabelReference.PortId),
                testbenchtype[
                    (
                        item.TestbenchLabelReference.PortId,
                        item.TestbenchLabelReference.LabelId,
                    )
                ],
                None,
            )

            registry.add_mapping_item(fw_var, port_var)
