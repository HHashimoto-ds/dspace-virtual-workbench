import importlib
import logging
import sys
import typing

# FIXME: Currently the clr gets iniatlized in /openta/xil/__init__.py depending on the platform.
import clr

_logger = logging.getLogger("xil testbench")


class TestbenchProvider:
    _openta_testbench_provider_instance: typing.Optional["TestbenchProvider"] = None
    _assembly_token = {"win32": {"2.2.0": "bf471dff114ae984"}, "linux": {"2.2.0": "f9604847d8afbfbb"}}

    def __new__(cls) -> "TestbenchProvider":
        if cls._openta_testbench_provider_instance is None:
            cls._openta_testbench_provider_instance = super().__new__(cls)
            cls._openta_testbench_provider_instance._initialized = False
        return cls._openta_testbench_provider_instance

    def __init__(self) -> None:
        if not self._initialized:
            self._initialized = True
            self.xil_version: str | None = None
            self._testbench_factory: typing.Any | None = None
            self._testbenches: dict[tuple[str, str, str], typing.Any] = {}
            self.load_assemblies()
            self.create_testbench_factory()

    def load_assemblies(self, xil_version: str = "2.2.0") -> None:
        _logger.info(
            "load ASAM testbench factory assemblies for XIL version: %s",
            xil_version,
        )
        # FIXME: Should not be done here I guess
        if sys.platform == "linux":
            sys.path.append("/opt/dspace/xilapi2024a/Testbench/Main/bin")

        xil_tb_fact = f"ASAM.XIL.Implementation.TestbenchFactory, Version={xil_version}.0, Culture=neutral, PublicKeyToken={self._assembly_token[sys.platform][xil_version]}"
        xil_interfaces = f"ASAM.XIL.Interfaces, Version={xil_version}.0, Culture=neutral, PublicKeyToken={self._assembly_token[sys.platform][xil_version]}"
        # TODO: version specific
        xil_ext_interfaces = "dSPACE.XIL.Testbench.ExtendedInterfaces, Version=22.2.0.0, Culture=neutral, PublicKeyToken=f9604847d8afbfbb"

        # Load ASAM assemblies from the global assembly cache (GAC).
        clr.AddReference(xil_tb_fact)
        clr.AddReference(xil_interfaces)
        clr.AddReference(xil_ext_interfaces)

    def create_testbench_factory(self):
        tb_module = importlib.import_module("ASAM.XIL.Implementation.TestbenchFactory.Testbench")
        self._testbench_factory = tb_module.TestbenchFactory()

    def get_testbench(self, vendor_name: str, product_name: str, product_version: str) -> typing.Any:
        key = (vendor_name, product_name, product_version)
        if self._testbench_factory is None:
            self.create_testbench_factory()
        if key not in self._testbenches:
            self._testbenches[key] = self._testbench_factory.CreateVendorSpecificTestbench(
                vendor_name, product_name, product_version
            )
        return self._testbenches[key]
