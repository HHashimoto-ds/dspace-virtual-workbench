# -*- coding: utf-8 -*-
"""
Description: This module implements helper function to handle ASAM Global Expression Syntax.
"""

import re
import typing

GES_FUNCTION_IDENTIFIER = frozenset(
    (
        "sin",
        "cos",
        "tan",
        "asin",
        "acos",
        "atan",
        "sinh",
        "cosh",
        "tanh",
        "log",
        "log10",
        "exp",
        "pow",
        "sqrt",
        "abs",
        "sgn",
        "round",
        "ceil",
        "floor",
        "min",
        "max",
        "posedge",
        "negedge",
        "strictposedge",
        "strictnegedge",
        "changed",
        "hwtrigger",
        "mantrigger",
        "changedneg",
        "changedpos",
    )
)

# Regular Exporession that matches Identifiers, consist only of
# alphanumeric characters but do not start with digital
IDENTIFIER_REGEX = re.compile("([^\\d\\W]\\w*)", re.UNICODE | re.MULTILINE)


def get_framework_label_from_condition_term(condition: str) -> typing.List[str]:
    """
    Extract all frameworklabel (alias) identifier from a GES expression and return them as list.
    """
    return [link for link in re.findall(IDENTIFIER_REGEX, condition) if link not in GES_FUNCTION_IDENTIFIER]
