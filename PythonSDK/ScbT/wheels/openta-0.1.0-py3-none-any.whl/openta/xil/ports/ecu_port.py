import importlib
import traceback
import typing
import warnings

import numpy as np
from openta.common import exceptions
from openta.common.log import logger
from openta.common.ports import PortState, PortVariable
from openta.xil.capture.ecu_capture import ECUCapture

from .xil_port import XilPort


class ECUPort(XilPort):
    def __init__(
        self,
        name: str,
        testbench: typing.Any,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, testbench, config)
        self._port = None

    @property
    def origin(self) -> typing.Any:
        """
        Get the underlying XIL API Port object.
        This returns the pythonnet object wrapped by this ECUPort
        """
        if self._port is None:
            # TODO
            raise exceptions.PortStateError("Cannot provide XIL ECUPort. Port is not yet created.")
        return self._port

    @property
    def state(self) -> PortState:
        if self._port is None:
            return PortState.RELEASED

        # TODO: use xil api enums ???
        # NOTE: the numbers are differently ordered as for maport
        state = int(self._port.CalibrationState)
        if state == 0:  # eCALIBRATION_DISCONNECTED
            return PortState.CREATED
        if state == 2:  # eCALIBRATION_ONLINE
            return PortState.STARTED
        if state == 1:  # eCALIBRATION_OFFLINE
            return PortState.CONNECTED
        raise exceptions.PortStateError(f"Unable to determine ECUPort state. retrieved state unknown: {state}")

    def create(self, **kwargs: typing.Any) -> None:
        # NOTE the assemblies have to be already registered
        ext_int = importlib.import_module("dSPACE.XIL.Testbench.ExtendedInterfaces.Testbench")
        self._port = ext_int.IDSTestbench(self._testbench).ECUPortFactory.CreateECUPort(self.name)

    def connect(self, **kwargs: typing.Any) -> None:
        """
        Load port configuratio file and configure port.
        """
        port_config_file = self.get_option(["port_config_file", "PortConfigurationFile"], kwargs, raise_error=True)
        try:
            port_config = self.origin.LoadConfiguration(port_config_file)
        except Exception as err:
            raise exceptions.PortConfigError(
                f"Cannot configure XIL ECUPort. Cannot load config file '{port_config_file}'. :: {traceback.format_exception_only(err)}"
            ) from err

        try:
            logger.info("Connect ecuport '%s'", self.name)
            self.origin.Configure(port_config)
        except Exception as err:
            raise exceptions.PortConfigError("Failed to configure XIL ECUPort.") from err

    def start(self, **kwargs: typing.Any) -> None:
        """
        start the port in order to work with it.
        """
        if self.state == PortState.STARTED:
            warnings.warn("ECUPort.start(): start is skipped, because the port is already started.")
            return

        # start calibration with configured loading type
        loading_type = self.get_option(["loading_type", "LoadingType"], kwargs, default="eUPLOAD")
        self.start_calibration(loading_type)

    def stop(self, **kwargs: typing.Any) -> None:
        """
        stop the port, this is the counterpart of start.
        """
        if self.origin is None:
            raise exceptions.PortStateError("Cannot stop XIL ECUPort. Port is not yet created.")
        if self.state != PortState.STARTED:
            warnings.warn("ECUPort.stop(): Stop is skipped, because the port is not started.")
            return

        # Stop a running measurement
        self.stop_measurement()

        # Stop active calibration
        self.stop_calibration()

    def read(self, variable: PortVariable) -> np.generic:
        """
        Read the physical value from given variable.
        """
        # ToDo: Use Read2 to support physical or raw value
        value = self.origin.Read(variable.id)
        return self._create_numpy_value(value, variable.dtype)

    def write(self, variable: PortVariable, value: typing.Any) -> None:
        """
        Write the given value to variable.
        The given value object is converted to a XIL API BaseValue according to dtype of PortVariable.
        """
        # Todo: Use Write2
        # You can use this method only in the eCALIBRATION_ONLINE state, otherwise the eCOMMON_INVALID_STATE exception occurs.
        converted_value = self._create_base_value(value, variable.dtype)
        return self.origin.Write(variable.id, converted_value)

    def create_capture(self, **kwargs: typing.Any) -> ECUCapture:
        """
        Create ECUCapture, all provided keyword arguments are passed to the cpature object.
        """
        return ECUCapture(self, **kwargs)

    def start_calibration(self, loading_type: str = "eUPLOAD") -> None:
        """
        Start the calibration of ECU port.
        @params: loading_type - str
            "eUPLOAD"   Transfers values from the ECU to the application.
            "eDOWNLOAD" Transfers values from the application to the ECU.
        """
        # determine LoadingType
        enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")

        if loading_type.upper() == "EUPLOAD":
            ltype = enums.LoadingType.eUPLOAD
        elif loading_type.upper() == "EDOWNLOAD":
            ltype = enums.LoadingType.eDOWNLOAD
        else:
            raise exceptions.PortConfigError(
                f"Cannot start ECUPort. Unknown LoadingType {loading_type}. Must be one of 'eUPLOAD' or 'eDOWNLOAD'."
            )

        # Start Calibration
        enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
        if self.origin.CalibrationState != enums.ECUPortCalibrationState.eCALIBRATION_ONLINE:
            self.origin.StartOnlineCalibration(ltype)

    def stop_calibration(self) -> None:
        """
        Stop the calibration of ECU port.
        """
        enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
        if self.origin.CalibrationState == enums.ECUPortCalibrationState.eCALIBRATION_ONLINE:
            self.origin.StopOnlineCalibration()

    def start_measurement(self) -> None:
        """
        Ensure a running measurement of ecu port.
        """
        enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
        if self.origin.MeasurementState == enums.ECUPortMeasurementState.eMEASUREMENT_STOPPED:
            # Start measurement at xil ecuport
            self.origin.StartMeasurement()
        elif self.origin.MeasurementState == enums.ECUPortMeasurementState.eMEASUREMENT_DISCONNECTED:
            raise exceptions.PortError(
                f"Cannot start ECUPort measuring. Port '{self.name}' has to be configured first."
            )

    def stop_measurement(self) -> None:
        """
        Stop the measurement of ECU port.
        """
        enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
        if self.origin.MeasurementState == enums.ECUPortMeasurementState.eMEASUREMENT_RUNNING:
            self.origin.StopMeasurement()
