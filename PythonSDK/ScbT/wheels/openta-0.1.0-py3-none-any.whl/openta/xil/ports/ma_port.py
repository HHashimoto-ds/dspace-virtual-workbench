import time
import traceback
import typing
import warnings

import numpy as np
from openta.common import exceptions
from openta.common.log import logger
from openta.common.ports import PortState, PortVariable
from openta.xil.capture.ma_capture import ModelCapture

from .xil_port import XilPort


class MAPort(XilPort):
    """
    XIL API MAPort
    currently able to read and write
    """

    def __init__(
        self,
        name: str,
        testbench: typing.Any,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, testbench, config)
        self._port = None

    @property
    def origin(self) -> typing.Any:
        """
        Get the underlying XIL API Port object.
        This returns the pythonnet object wrapped by this MAPort.
        """
        if self._port is None:
            raise exceptions.PortStateError("Cannot provide XIL MAPort. Port is not yet created.")
        return self._port

    @property
    def state(self) -> PortState:
        if self._port is None:
            return PortState.RELEASED

        # TODO: use xil api enums ???
        state = int(self._port.State)
        if state == 2:  # eDISCONNECTED
            return PortState.CREATED
        if state == 0 or state == 3:  # eSIMULATION_STOPPED | #eSIMULATION_PAUSED
            # simply not running is connected and can be started....
            return PortState.CONNECTED
        if state == 1:  # eSIMULATION_RUNNING
            return PortState.STARTED

        raise exceptions.PortStateError(f"Unable to determine MAPort state. retrieved state unknown: {state}")

    def create(self, **kwargs: typing.Any) -> None:
        """
        Create maport instance
        """
        self._port = self._testbench.MAPortFactory.CreateMAPort(self.name)

    def connect(self, **kwargs: typing.Any) -> None:
        """
        Load port configuratio file and configure port.
        """
        port_config_file = self.get_option(["port_config_file", "PortConfigurationFile"], kwargs, raise_error=True)
        try:
            port_config = self.origin.LoadConfiguration(port_config_file)
        except Exception as err:
            raise exceptions.PortConfigError(
                f"Cannot configure XIL MAPort. Cannot load config file '{port_config_file}'. :: {traceback.format_exception_only(err)}"
            ) from err

        # Configure the XIL API MAPort
        force_config = bool(self.get_option(["force_config", "ForceConfig"], kwargs, default=False))
        try:
            logger.info("Connect maport '%s'", self.name)
            self.origin.Configure(port_config, force_config)
        except Exception as err:
            raise exceptions.PortConfigError("Failed to configure XIL MAPort.") from err

    def start(self, **kwargs: typing.Any) -> None:
        """
        start the port in order to work with it.
        """
        if self.state == PortState.STARTED:
            warnings.warn("MAPort.start(): start is skipped, because the port is already started.")
            return
        self.origin.StartSimulation()

    def stop(self, **kwargs: typing.Any) -> None:
        """
        stop the port, this is the counterpart of stop.
        A stopped port can be started again
        """
        if self.state != PortState.STARTED:
            warnings.warn("MAPort.stop(): stop is skipped, because the port is not started.")
            return
        self.origin.StopSimulation()

    def read(self, variable: PortVariable) -> np.generic:
        """
        Read the physical value from given variable.
        """
        value = self.origin.Read(variable.id)
        return self._create_numpy_value(value, variable.dtype)

    def write(self, variable: PortVariable, value: typing.Any) -> None:
        """
        Write the given value to variable.
        The given value object is converted to a XIL API BaseValue according to dtype of PortVariable.
        """
        converted_value = self._create_base_value(value, variable.dtype)
        return self.origin.Write(variable.id, converted_value)

    def create_capture(self, **kwargs: typing.Any) -> ModelCapture:
        """
        Create ModelCapture, all provided keyword arguments are passed to the cpature object.
        """
        return ModelCapture(self, **kwargs)

    def wait(self, duration_in_sec: float, timeout_factor: int = 50) -> None:
        """
        To wait for a specific period of time defined by given value.
        """
        if self.state < PortState.STARTED:
            raise exceptions.PortStateError("Cannot wait on MAPort DAQClock. Port is not started/running.")

        if not hasattr(self.origin, "DAQClock"):
            raise exceptions.PortTypeError("Cannot wait on MAPort DAQClock. Port seems not to have a `DAQClock`.")
        timeout_sys = 0
        stop_time = self.origin.DAQClock + duration_in_sec

        # Calculate timeout if desired
        if timeout_factor > 0:
            timeout_sys = time.time() + duration_in_sec * timeout_factor

        while stop_time >= self.origin.DAQClock:
            # if timeout should be enabled
            if timeout_factor > 0:
                if timeout_sys < time.time():
                    raise TimeoutError(f"Wait step run into timeout after {timeout_sys} seconds (system clock).")

            time.sleep(0.01)
