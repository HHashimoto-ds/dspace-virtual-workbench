import typing

import numpy as np
import numpy.typing as npt
from openta.common import exceptions
from openta.common.log import logger
from openta.common.ports import AbstractPort, PortState


class XilPort(AbstractPort):
    """
    Comon base class for all XIL API Ports
    """

    def __init__(
        self,
        name: str,
        testbench: typing.Any,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, config)
        self._testbench = testbench

    def _create_base_value(self, value: typing.Any, dtype: npt.DTypeLike) -> typing.Any:
        """
        Create a XIL API testbench specific base value according to given dtype.
        """
        dt = np.dtype(dtype)
        if dt.kind == "f":  # float
            return self._testbench.ValueFactory.CreateFloatValue(value)
        if dt.kind == "i":  # integers
            return self._testbench.ValueFactory.CreateIntegerValue(value)
        if dt.kind == "u":  # unsigned integers
            return self._testbench.ValueFactory.CreateUnsignedIntegerValue(value)
        if dt.kind == "b":  # boolean
            return self._testbench.ValueFactory.CreateIntegerValue(value)
        if dt.kind == "U":  # Unicode
            return self._testbench.ValueFactory.CreateStringValue(value)

        raise TypeError(f"Unknown dtype {dtype}. Failed to create XIL AI BaseValue from value {value}.")

    def _create_numpy_value(self, value: typing.Any, dtype: npt.DTypeLike) -> np.generic:
        """
        Create a scalar numpy value acording to specified numpy dtype
        """
        #
        #   maybe check between asam datatype and expected numpy dtype... ?
        #
        dt = np.dtype(dtype)
        return dt.type(value.Value)

    def disconnect(self, **kwargs: typing.Any) -> None:
        """
        Disconnect the port
        """
        if self.origin is None:
            # TODO
            raise exceptions.PortStateError("Cannot disconnect XIL Port. Port is not yet created.")
        logger.info("Disconnect port '%s'", self.name)
        self.origin.Disconnect()

    def release(self, **kwargs: typing.Any) -> None:
        """
        Disconnect the port
        """
        if self.origin is None:
            # TODO
            raise exceptions.PortStateError("Cannot release XIL Port. Port is not yet created.")
        if self.state >= PortState.CONNECTED:
            self.disconnect()
        logger.info("Dispose port '%s'", self.name)
        self.origin.Dispose()

    @property
    def testbench(self) -> typing.Any:
        """
        Get the underlying XIL API testbench object.
        """
        return self._testbench
