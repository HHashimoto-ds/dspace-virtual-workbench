"""
This module initializes platform-specific dependencies and sets up the environment for accessing MF4 data files
and .NET assemblies required for XIL functionality.

Platform-specific behavior:
- On Linux:
    - Loads the .NET Core runtime using pythonnet and clr_loader.
    - Sets the runtime configuration from a local 'pythonnet.runtimeconfig.json'.
    - Sets the path to the 'libCmnDSMF4AccessU.so' shared library for MF4 access.
- On Windows:
    - Sets the path to the 'CmnDSMF4AccessU.dll' for MF4 access.
- On unsupported platforms:
    - Raises NotImplementedError.

After platform-specific setup, the module:
- Imports the 'clr' module to enable interoperability with .NET assemblies.
- Adds references to required .NET assemblies:
    - dSPACE.Common.XilMappingHandler.dll
    - dSPACE.Common.XilMappingHandlerInterfaces.dll
    - System.Collections
"""

import importlib
from pathlib import Path
from sys import platform

import evaluationlib.data.mf4access  # pyright: ignore[reportMissingImports]

if platform == "linux":
    from pythonnet import load  # pyright: ignore[reportMissingTypeStubs]

    load("coreclr", runtime_config=str(Path(__file__).parent / "pythonnet.runtimeconfig.json"))

    library_file = Path(evaluationlib.data.mf4access.__file__).parent / "libCmnDSMF4AccessU.so"  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
    evaluationlib.data.mf4access._mf4access_api.DLL.set_dllpath(str(library_file))  # pyright: ignore[reportUnknownMemberType]

elif platform == "win32":
    library_file = Path(evaluationlib.data.mf4access.__file__).parent / "CmnDSMF4AccessU.dll"  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
    evaluationlib.data.mf4access._mf4access_api.DLL.set_dllpath(str(library_file))  # pyright: ignore[reportUnknownMemberType]

else:
    raise NotImplementedError(f"Platform '{platform}' is not supported.")


import clr  # pyright: ignore[reportMissingTypeStubs]

_assembly_path = Path(__file__).parent.resolve()
clr.AddReference(str(_assembly_path / "dSPACE.Common.XilMappingHandler.dll"))  # pyright: ignore[reportUnknownMemberType,reportAttributeAccessIssue]
clr.AddReference(str(_assembly_path / "dSPACE.Common.XilMappingHandlerInterfaces.dll"))  # pyright: ignore[reportUnknownMemberType,reportAttributeAccessIssue]
clr.AddReference(str(_assembly_path / "dSPACE.AutomationDesk.XILAPIPyObjectEncoder22"))
clr.AddReference("System.Collections")  # pyright: ignore[reportUnknownMemberType,reportAttributeAccessIssue]

encoder22 = importlib.import_module("dSPACE.AutomationDesk.XILAPIPyObjectEncoder22")
if encoder22:
    encoder22.XILAPIPyObjectEncoderManager22.RegisterPyObjectEncoders()
