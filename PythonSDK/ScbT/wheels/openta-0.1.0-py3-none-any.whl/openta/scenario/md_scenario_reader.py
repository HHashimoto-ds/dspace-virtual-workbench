import copy
import os
import pathlib
import tempfile
import traceback
import typing
import xml.etree
import xml.etree.ElementTree
from xml.etree.ElementTree import Element

from openta.common.exceptions import ScenarioConfigError
from openta.registry.registry import Registry


class ModelDeskScenarioReader:
    """
    Load a specified ModelDesk scenario from provided pool directory.
    Currently traffic and maneuver aliases can be determined from that ModelDesk scenario file.
    This class is used byModelDeskScenario to analyze the scenario
    and create a collection of `ScenarioParameters`.
    """

    _XMLNS_SCENARIO_COMMON = "http://www.dspace.com/XMLSchema/ScenarioAccess/Scenario/Common"
    _XMLNS_SCENARIO_TRAFFIC = "http://www.dspace.com/XMLSchema/ScenarioAccess/Scenario/Traffic"
    _XMLNS = {"common": _XMLNS_SCENARIO_COMMON, "traffic": _XMLNS_SCENARIO_TRAFFIC}

    def __init__(self, pool_directory: os.PathLike[str] | str, scenario: os.PathLike[str] | str):
        self._pool_directory = pathlib.Path(pool_directory)
        self._scenario_name = pathlib.Path(scenario)
        self._xmlroot: Element | None = None

    def load(self) -> None:
        """
        Load the specified ModelDesk scenario to determine scenario parameter aliases for maneuver and traffic.
        If the file is loaded successfully, the `get_maneuver_aliases()` and `get_traffic_aliases()` can be called to determine traffic and maneuver aliases.
        """
        filename = self._pool_directory / "Environment" / "Scenario" / self._scenario_name

        if not filename.exists():
            if filename.suffix == "" and filename.with_suffix(".xml").exists():
                filename = filename.with_suffix(".xml")
            else:
                raise ScenarioConfigError(
                    f"Cannot read '{self._scenario_name}' ModelDesk scenario file from given '{self._pool_directory}' pool directory. The file does not exist: {filename}"
                )

        try:
            self._xmlroot = xml.etree.ElementTree.parse(filename).getroot()
        except Exception as err:
            raise ScenarioConfigError(
                f"Failed to load or parse ModelDesk scenario file as xml: '{filename}'. :: {traceback.format_exception_only(err)}"
            ) from err

    def _get_aliases(self, xpath: str) -> typing.Generator[str, None, None]:
        """
        Internal method to iterate all maneuver or traffic aliases by specified `xpath` and.
        Returned generator yields text property of xml elements found by specified `xpath` parameter.
        """
        if self._xmlroot is None:
            raise ScenarioConfigError(
                f"Internal Error: Cannot read scenario aliases from '{self._scenario_name}' ModelDesk scenario xml file. File not loaded."
            )

        for element in self._xmlroot.iterfind(xpath, self._XMLNS):
            if element.text is not None:
                yield element.text

    def get_maneuver_aliases(self) -> typing.Generator[str, None, None]:
        """
        returns a generator of all maneuver aliases in specified ModelDesk scenario.
        """
        return self._get_aliases(
            "./traffic:AliasListManeuver/common:AliasVariableList/common:AliasVariable/common:Name"
        )

    def get_traffic_aliases(self) -> typing.Generator[str, None, None]:
        """
        returns a generator of all traffic aliases in specified ModelDesk scenario.
        """
        return self._get_aliases("./traffic:AliasListTraffic/common:AliasVariableList/common:AliasVariable/common:Name")


class MAPortConfigHandler:
    def __init__(self, port_id: str):
        self._port_id = port_id
        try:
            port = Registry().get_port(self._port_id)
        except Exception as err:
            raise ScenarioConfigError(
                f"Failed to configure ModelDesk scenario. Cannot get specified '{self._port_id}' dSPACE MAPort. :: {traceback.format_exception_only(err)}"
            )

        # read the maport config xml
        self._config_file = pathlib.Path(port.get_option("port_config_file", raise_error=True))
        self._config_dir = self.config_file_path.parent
        try:
            self._xmlroot: Element = xml.etree.ElementTree.parse(self._config_file).getroot()
        except Exception as err:
            raise ScenarioConfigError(
                f"Failed to load or parse dSPACE MAPort config xml file: '{self._config_file}'. :: {traceback.format_exception_only(err)}"
            ) from err

    @property
    def config_file_path(self) -> pathlib.Path:
        return self._config_file

    def _get_xml_element(self, xpath: str, xmlroot: Element) -> Element:
        """
        Get the text contents of defined xpath from specified `xmlroot`.
        Note, that this method is used to read text from loaded maportconfig.xml
        as well as modifying a copy of it, to download another scenario.
        If you want to read the loaded maportconfig, provide self._xmlroot
        """
        xml_node = xmlroot.find(xpath)
        if xml_node is None or xml_node.text is None:
            raise ScenarioConfigError(
                "Failed to configure ModelDesk scenario. Cannot read {xpath} from '{self._port_id}' dSPACE MAPort config xml file. Element not found or empty.",
            )
        else:
            return xml_node

    def _get_text(self, xpath: str) -> str:
        """
        Get the text contents of defined xpath in loaded maport config xml file.
        """
        xml_node = self._get_xml_element(xpath, self._xmlroot)
        if xml_node.text is None or xml_node.text == "":
            raise ScenarioConfigError(
                "Failed to configure ModelDesk scenario. Cannot read {xpath} from '{self._port_id}' dSPACE MAPort config xml file. Element not found or empty.",
            )
        else:
            return xml_node.text

    def get_pool_directory(self) -> pathlib.Path:
        """
        Determine the ModelDesk scenario pool directory from specified ports configuration xml file.
        Returns the `MAPortConfig/ScenarioApiConfig/Parameterization/PoolDirectory` text from xml.
        """
        return self._config_dir / pathlib.Path(
            self._get_text("./MAPortConfig/ScenarioApiConfig/Parameterization/PoolDirectory")
        )

    def get_environment_paths_file(self) -> pathlib.Path:
        """
        Determine the ModelDesk scenario environment paths xml file from specified ports configuration xml file.
        Returns the `MAPortConfig/ScenarioApiConfig/EnvironmentPathsFile` text from xml.
        MAPort variables for maneuver control (start, stop, reset) are determined from that file.
        """
        return self._config_dir / pathlib.Path(self._get_text("./MAPortConfig/ScenarioApiConfig/EnvironmentPathsFile"))

    def create_temporary(self, scenario: str | os.PathLike[str], road: str | os.PathLike[str] | None) -> pathlib.Path:
        """
        Create a copy of current MAPort config xml file in temp folder.
        The specified values for scenario and road are rewritten.
        Known paths of scenario and other files are rewritten as absolute paths.
        The absolut path to the temporary file is returned.
        The temporary file is not removed or deleted by functionality of MAPortConfigHandler.
        """
        xml_copy = copy.deepcopy(self._xmlroot)

        # read the original paths from maport config and resolve them relative config file
        abs_pool_dir = self.get_pool_directory()
        abs_env_paths_file = self.get_environment_paths_file()
        abs_sdf = self._config_dir / pathlib.Path(self._get_text("./MAPortConfig/SystemDescriptionFile"))

        # write them back as absolute values, because the save the copy into temporary folder
        self._get_xml_element(
            "./MAPortConfig/ScenarioApiConfig/Parameterization/PoolDirectory", xml_copy
        ).text = abs_pool_dir.as_posix()

        self._get_xml_element(
            "./MAPortConfig/ScenarioApiConfig/EnvironmentPathsFile", xml_copy
        ).text = abs_env_paths_file.as_posix()

        self._get_xml_element("./MAPortConfig/SystemDescriptionFile", xml_copy).text = abs_sdf.as_posix()

        # change the scenario and road
        scenario_file_node = self._get_xml_element(
            "./MAPortConfig/ScenarioApiConfig/Parameterization/ScenarioFileName", xml_copy
        )
        road_file_node = self._get_xml_element(
            "./MAPortConfig/ScenarioApiConfig/Parameterization/RoadFileName", xml_copy
        )

        if scenario:
            scenario_file_node.text = os.fspath(scenario)
        if road:
            road_file_node.text = os.fspath(road)

        # WRITE NEW TEMPORARY Maport Config File to temp folder
        temp_dir = pathlib.Path(tempfile.mkdtemp(prefix="openta.scenario.maport."))
        temp_file = temp_dir / "maportconfig.xml"
        with open(temp_file, "wb") as f:
            xml.etree.ElementTree.ElementTree(xml_copy).write(f, encoding="utf-8")

        return temp_file
