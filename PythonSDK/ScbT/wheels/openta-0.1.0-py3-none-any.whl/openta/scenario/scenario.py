import os
import typing

from openta.common.scenario import AbstractScenario, ManeuverState, ScenarioParametersList

from .md_scenario import ModelDeskScenario


class Scenario(AbstractScenario):
    """
    The Scenario object offers features for downloading, parameterizing and the controlling the scenario/maneuver.
    To start, the object is created with a appropriate reference to a scenario.

    For parameterizing the Scenario object offers a `vars` collection similar to the TestEnvironmentAccess vars collection.
    But in oposite to that the provided variables are defined by scenario.
    For ModelDesk scenarios, these are aliases for traffic and maneuver defined in the ModelDesk scenario xml file,
    and accessible by name.

    Depending on the concrete scenario, further arguments may be valid.
    These can be defined as keyword arguments and passed to the `__init__` of created Scenario as keyword arguments.

    NOTE, that currently only ModelDesk scenarios are supported
    and in that case the `Pool` directory is determined from a defined dSPACE XIL API MAPort config file,
    thus the scenario can be determined by its filename.

    ```python
    sc = Scenario("NCAP_AEB_CCRb")
    sc.download()
    sc.vars.v_EGO.value = 80
    st.start_maneuver()
    ```
    """

    def __new__(cls, scenario: str | os.PathLike[str], **kwargs: typing.Any) -> AbstractScenario:
        # Somehow determine the concrete Scenario class by magic.
        # Currently Only ModelDeslScenarios are supported.
        return ModelDeskScenario(scenario, **kwargs)

    # The following "implementations" of the abstract methods,
    # are needed in order to instantiate this `Scenario`` class.
    # However due to the __new__ method concrete subclasses are instantiated,
    # such that these methods are overwritten by concrete implementations.

    def download(self) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def start(self) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def stop(self) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def reset(self) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def wait_for_maneuver_state(self, state: ManeuverState, timeout: float | None = None) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def wait_for_maneuver_finished(self, timeout: float | None = None) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    @property
    def maneuver_state(self) -> ManeuverState:
        raise NotImplementedError("Internal Error. This should have never been called.")

    @property
    def vars(self) -> ScenarioParametersList:
        raise NotImplementedError("Internal Error. This should have never been called.")
