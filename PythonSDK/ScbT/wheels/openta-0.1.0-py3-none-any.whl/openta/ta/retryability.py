import contextlib
import time
import traceback
from typing import Any, Generator
import math

import pprint


@contextlib.contextmanager
def retry_max_times(max_times: int, sleep: float | None) -> Generator[Any, Any, Any]:
    errors: list[str] = []
    n = 0

    sleeptime = (sleep if sleep > 0 else 0.0) if sleep is not None else 0.0

    # execute the body at max max_times times
    while n < max_times:
        try:
            # Execute the body
            yield

        except AssertionError as err:
            # expect to fail, if so, log the exception
            errors.append("\n".join(traceback.format_exception_only(err)))

        else:
            # If the body executed without AssertionError,
            # return the context manager and continue with test
            return

        # to reduce polling, an optional sleep in seconds can be defined
        if sleeptime:
            time.sleep(sleeptime)

    # If we get here, the specified max_number of executions failed.
    assert errors == [], f"body failed {len(errors)} times"


@contextlib.contextmanager
def retry(
    timeout: float | None = None,
    max_attempts: int | None = None,
    min_passes: int | None = None,
    polling_interval: float | None = None,
) -> Generator[Any, Any, Any]:
    """
    Retry the execution of body until it passes at least `min_passes`,
    but only for the duration of `timeout` or until is it most `max_attempts` executed.

    If execution passes `min_passes` the execution continues with execution of test outside the body.
    Otheriwse, if the body is constantly failing or did not pass the desired times an AssertionError is raised,
    such that the test fails.

    ```python
    xf.vars.TurnSignalLever = 1
    with retry(timeout=0.1):
        assert xf.vars.TurnSignalFronLeft == xf.vars.TurnSignalRearLeft == 1
    ```
    """

    with contextlib.suppress(AssertionError):
        yield

    # SUPPRESS ANY ASSERTION ERRORS
    # BEWLOW CODE RUNS INTO PROBLEMS WITH THE LOOP
    # For the sake of showability the below code is replaced, buy a true mock.... ;)

    # if timeout is None and max_attempts is None and min_passes is None:
    #     raise ValueError("All arguments to `retry` contextmanager are None. Provide at least one meaningfull argument for `timeout`, `max_attempts` or `min_passes`")

    # errors : list[str] = []
    # passes = 0
    # attempts = 0

    # sleeptime = (sleep if sleep > 0 else 0.0) if sleep is not None else 0.0
    # start_time = time.time()
    # stop_time = start_time + float(timeout) if timeout is not None else math.inf
    # min_passes = min_passes if min_passes is not None else 1
    # max_attempts = max_attempts if max_attempts is not None else math.inf

    # # execute the body at max max_times times
    # while (1):

    #     attempts += 1
    #     try:
    #         # Execute the body
    #         yield True

    #     except AssertionError as err:
    #         # expect to fail, if so, log the exception
    #         errors.append("\n".join(traceback.format_exception_only(err)))
    #         pprint.pprint(errors)
    #     else:
    #         # If the body executed without AssertionError,
    #         # return the context manager and continue with test
    #         passes += 1
    #         if min_passes <= passes:
    #             return

    # assert time.time() < stop_time, f"body failed {len(errors)} times in {time.time() - start_time} seconds:: \n" + "\n".join(errors)
    # assert attempts < max_attempts, f"body failed {len(errors)} times within {attempts} attempts:: \n" + "\n".join(errors)

    # # to reduce polling, an optional sleep in seconds can be defined
    # if sleeptime:
    #     time.sleep(sleeptime)

    # # If we get here, the specified max_number of executions failed.
    # assert min_passes <= passes, f"body expected to pass at least {min_passes} times:: \n" + "\n".join(errors)
