import typing
import operator

import allure
from openta.common.variables import FrameworkVariable


@typing.overload
def Assert(value: typing.Callable, *args, **kwargs) -> bool: ...


@typing.overload
def Assert(value: str, **kwargs) -> bool: ...


def Assert(value: typing.Any, *args, **kwargs) -> None:
    """
    Assert a given callable, expression text or value.
    If a callable is provided it is called in assert statement
    If a text is provided it is evaluated in assert satement
    I any other case the given value is directly provided to assert statement

    NOTE: Here still the assert statement is used to fail fast in a case of failure
    and make use of pytests assertion rewriting
    """
    with allure.step(f"ASSERT {value}"):
        if callable(value):
            assert value(*args, **kwargs)
        elif isinstance(value, str):
            assert eval(value, globals(), kwargs), value
        elif isinstance(value, Operation):
            assert value._assert(), str(value)
        else:
            assert value


class Expectation:
    def __init__(self, var: FrameworkVariable) -> None:
        self.variable = var

    def __eq__(self, other):
        return Operation(self, other, operator.eq, "==")

    def __str__(self):
        return str(self.variable)

    def _get(self):
        return self.variable.value


class Operation:
    def __init__(self, lhs, rhs, op, symbol):
        self._lhs = lhs
        self._rhs = rhs
        self._op = op
        self._symbol = symbol

    def __bool__(self):
        with allure.step(f"check {self._lhs} {self._symbol} {self._rhs}"):
            return self._op(self._lhs._get(), self._rhs)

    def _assert(self):
        # Abgrenzung gegen bool, wird von unserem Assert verwendet
        return self._op(self._lhs._get(), self._rhs)

    def __str__(self):
        return f"{self._lhs} {self._symbol} {self._rhs}"


def expect(obj: object) -> Expectation:
    return Expectation(obj)
