import json
import logging
import os
import typing

import yaml
from jsonschema import ValidationError, validate
from openta.common.exceptions import ConfigurationError
from openta.common.ports import PortState
from openta.config.plugins import PluginProvider
from openta.registry.registry import Registry
from openta.xil.mapping_reader import MappingReader
from openta.xil.ports.ecu_port import ECUPort
from openta.xil.ports.ma_port import MAPort
from openta.xil.testbench import TestbenchProvider

_logger = logging.getLogger("testenv_config")


class TestEnvironmentConfigReader:
    def __init__(self, config_file_name: str) -> None:
        self._filename = config_file_name
        self._dirname = os.path.dirname(self._filename)
        if not os.path.isabs(self._dirname):
            self._dirname = os.path.join(os.getcwd(), self._dirname)

    def load(self) -> typing.Any:
        schema_file_name = os.path.normpath(os.path.join(os.path.dirname(__file__), "testenv_schema.json"))
        # Load JSON Schema
        with open(schema_file_name, "r") as schema_file:
            schema = json.load(schema_file)

        # Load YAML file
        _logger.info("TestEnv config: Load file: '%s'", self._filename)
        with open(self._filename, "r") as yaml_file:
            yaml_data = yaml.safe_load(yaml_file)

        # Validate YAML data against the schema
        try:
            validate(instance=yaml_data, schema=schema)
        except ValidationError as err:
            raise ConfigurationError(
                "Failed to load provided openta test environment configuration file: {self._filename}"
            ) from err

        return yaml_data

    def add_to_registry(self):
        config = self.load()

        if "plugins" in config:
            _logger.info("TestEnv config : analyzing plugins")
            self._add_plugins(config["plugins"])

        if "ports" in config:
            _logger.info("TestEnv config : analyzing port specifications")
            self._add_ports(config["ports"])
        else:
            _logger.warning("TestEnv config : no ports specified")

        if "mappings" in config:
            _logger.info("TestEnv config : analyzing mappings")
            self._add_mappings(config["mappings"])
        else:
            _logger.warning("TestEnv config : no mappings specified")

    def _add_ports(self, port_specs: typing.Any) -> None:
        for port_spec in port_specs:
            _logger.info("TestEnv config : register '%s' %s port.", port_spec["name"], port_spec["type"])

            # XIL built-ins Port
            if port_spec["type"] in ("XIL API MAPort", "XIL API dSPACE ECUPort"):
                tb_key = self._get_testbench_identifier(port_spec)
                tb = TestbenchProvider().get_testbench(*tb_key)
                port_config_file = self._get_filename(port_spec["port_config_file"])
                if port_spec["type"] == "XIL API MAPort":
                    port = MAPort(
                        port_spec["name"],
                        tb,
                        {
                            "port_config_file": port_config_file,
                            "force_config": port_spec["force_config"],
                            "order": port_spec["order"],
                            "target_state": self._get_target_state(port_spec),
                        },
                    )
                    Registry().add_port(port)

                elif port_spec["type"] == "XIL API dSPACE ECUPort":
                    port = ECUPort(
                        port_spec["name"],
                        tb,
                        {
                            "port_config_file": port_config_file,
                            "loading_type": port_spec["loading_type"],
                            "order": port_spec["order"],
                            "target_state": self._get_target_state(port_spec),
                        },
                    )
                    Registry().add_port(port)

            # Custom Port
            elif port_spec["type"] == "Custom":
                port_type = PluginProvider().get_port_type(port_spec["factory"]["type"])
                port = port_type(port_spec["name"], port_spec["config"])
                Registry().add_port(port)

    def _get_testbench_identifier(self, port_spec: typing.Any) -> tuple[str, str, str]:
        try:
            factory = port_spec["factory"]
            return (
                factory["vendor_name"],
                factory["product_name"],
                factory["product_version"],
            )
        except Exception as err:
            raise ConfigurationError("Failed to determine XIL API Factory parameters") from err

    def _add_mappings(self, mapping_specs: typing.Any) -> None:
        for mapping_spec in mapping_specs:
            if mapping_spec["type"] == "XIL API Mapping":
                reader = MappingReader([self._get_filename(mapping_spec["file"])])
                reader.add_to_registry()
            else:
                _logger.warning("TestEnv config : Skip unknown mapping file: %s", repr(mapping_spec))

    def _add_plugins(self, plugin_specs: typing.Any) -> None:
        for plugin_spec in plugin_specs:
            PluginProvider().load_plugins_from_folder(self._get_filename(plugin_spec["folder"]))

    def _get_filename(self, relative_path: str) -> str:
        return os.path.normpath(os.path.join(self._dirname, relative_path))

    def _get_target_state(self, port_spec: dict[str, typing.Any]) -> PortState:
        target_state = port_spec["target_state"].upper()
        match target_state:
            case "RELEASED":
                return PortState.RELEASED
            case "CREATED":
                return PortState.CREATED
            case "CONNECTED":
                return PortState.CONNECTED
            case "STARTED":
                return PortState.STARTED
            case _:
                raise ConfigurationError(f'Invalid target_state "{target_state}" for port "{port_spec["name"]}".')
