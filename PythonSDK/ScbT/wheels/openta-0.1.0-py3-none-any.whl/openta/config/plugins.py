import importlib
import importlib.util
import json
import logging
import sys
import typing
from pathlib import Path

from openta.common.ports import AbstractPort

_logger = logging.getLogger("plugin provider")


class PluginProvider:
    _openta_plugin_provider_instance: typing.Optional["PluginProvider"] = None
    _assembly_token = {"2.2.0": "bf471dff114ae984"}

    def __new__(cls) -> "PluginProvider":
        if cls._openta_plugin_provider_instance is None:
            cls._openta_plugin_provider_instance = super().__new__(cls)
            cls._openta_plugin_provider_instance._initialized = False
        return cls._openta_plugin_provider_instance

    def __init__(self) -> None:
        if not self._initialized:
            self._initialized = True
            self._custom_port_classes: dict[str, type[AbstractPort]] = {}

    def get_port_type(self, port_type_name: str) -> type[AbstractPort]:
        return self._custom_port_classes[port_type_name]

    def load_plugins_from_folder(self, folder: str | Path) -> None:
        """Load plugins from a folder."""
        folder = Path(folder)

        # Check if the given folder exists and is a directory
        if not folder.is_dir():
            raise ValueError(f"{folder} is not a directory.")

        # Add the folder to sys.path so modules can be imported from it
        #
        #   TODO: sicher ????
        #
        # sys.path.insert(0, str(folder.resolve()))

        config_path = Path(folder) / "config.json"

        # If a config.json exists, load plugin file names from it
        if config_path.exists():
            with open(config_path, "r") as f:
                config = json.load(f)
                plugin_files = [Path(folder) / file for file in config.get("plugins", [])]
                for file in plugin_files:
                    if not file.exists():
                        raise ValueError(f"Plugin file {file} listed in config does not exist.")
                _logger.info("Loaded config: %s", config)
        else:
            # Otherwise, find all .py files in the folder that are not private (don't start with '_')
            plugin_files = [
                f for f in folder.iterdir() if f.is_file() and not f.name.startswith("_") and f.suffix == ".py"
            ]

        print(f"Found plugin files: {plugin_files}")

        # Iterate over each plugin file and attempt to load it as a module
        for file in plugin_files:
            plugin_name = file.stem  # Module name without .py extension
            module_path = Path(folder) / file

            # Create a module spec from the file location
            spec = importlib.util.spec_from_file_location(plugin_name, str(module_path))

            if spec and spec.loader:
                # Load the module from the spec
                module = importlib.util.module_from_spec(spec)
                sys.modules[plugin_name] = module
                spec.loader.exec_module(module)

                # Register any class in the module that implements PluginInterface (except the interface itself)
                for attr in dir(module):
                    obj = getattr(module, attr)
                    if isinstance(obj, type) and issubclass(obj, AbstractPort) and attr != AbstractPort.__name__:
                        self._custom_port_classes[obj.__name__] = obj
                        print(f"Registered plugin: {obj.__name__} -> {obj.__name__}")
