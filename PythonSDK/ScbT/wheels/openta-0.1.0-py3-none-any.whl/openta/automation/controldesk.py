import os
import struct
import types
import typing
import uuid
import platform
import warnings
from openta.common.ports import PortVariable
from openta.common.variables import FrameworkVariable
from openta.registry.registry import Registry


# pyright: reportConstantRedefinition=false
if platform.system() == "Windows":
    try:
        import pywintypes
    except ImportError as err:
        _COM_ERROR = None
        warnings.warn(f"Failed to import `pywintypes`. ControlDesk automation support disabled. :: {err}")
    else:
        _COM_ERROR = pywintypes.com_error

    try:
        import win32com.client
    except ImportError as err:
        _DISPATCH = None
        _DISPATCH_BASE_CLASS = None
        warnings.warn(f"Failed to import `win32com.client`. ControlDesk automation support disabled. :: {err}")
    else:
        _DISPATCH = win32com.client.Dispatch
        _DISPATCH_BASE_CLASS = win32com.client.DispatchBaseClass

else:
    _COM_ERROR = None
    _DISPATCH = None
    _DISPATCH_BASE_CLASS = None


class ControlDeskAutomationError(Exception):
    """
    Common Exception for all functions in `controldesk` module.

    The exception message aims to be user friendly and providing as much informatio as possible.
    If any COM error occured during the desired action,
    the message contains a descriptiove part from openta view and
    separated by two collons the com error raised by controldesk or the com engine itself.
    """

    def __init__(self, message: str, hint: str | None = None, error: str | None = None):
        msg = message
        if hint is not None:
            msg += f" {hint}"
        if error is not None:
            msg += f" :: {error}"

        super().__init__(msg)


def _get_hresult_as_hex(hr: int):
    """
    Get the COM HResult as formatted hey number, which is common style for such COM error numbers.

    Note the integer number provided by pywintypes results in a negative number in python,
    which is not the desired representation.

    Args:
        hr (int): the integer number retrieved from the pywintypes.com_error

    Returns:
        str: the correct HResult number formatted as hex
    """
    # We need to interpret the negative number as a 32 bit signed integer,
    # then interpret that as an unsigned integer:
    return "0x%x" % struct.unpack("L", struct.pack("l", hr))[0]


def _format_com_error(error: typing.Any) -> str:
    """
    Get formatted string from com_error

    The returned string consists of three parts:
    - hresult number, formatted ashex
    - the source of the error if provided
    - a description of the error provided by the source

    Args:
        error (pywintypes.com_error): the error to format.

    Returns:
        str: a formmatted string representation of the given error
    """
    try:
        hr, ename, details, _ = error.args
    except Exception:
        return str(error)

    try:
        if details:
            # entpacke das tupel
            (_, source, description, _, _, errorhr) = details

            message = f"COM Error {_get_hresult_as_hex(errorhr)}"

            # if Source is provided by ErrorInfo, add it at first to the Message
            if source is not None:
                message += ": %s" % source

            # and if provided description
            if isinstance(description, str):
                description = description.rstrip()
                message += ": %s" % " ".join([line.strip() for line in description.split("\n")])
            return message
        else:
            return f"{_get_hresult_as_hex(hr)}: {ename}"
    except Exception:
        return str(error)


def get_application() -> typing.Any:
    """
    Create and return a win32com client object dispatched to `ControlDeskNG.Application`.

    Returns:
        win32com COM object: The ControlDesk application object

    Raises:
        ControlDeskAutomationError: If any com errors occured
    """
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            return _DISPATCH("ControlDeskNG.Application")
        except _COM_ERROR as err:
            raise ControlDeskAutomationError("Failed to dispatch ControlDesk.", error=_format_com_error(err)) from err
    else:
        if platform.system() != "Windows":
            raise ControlDeskAutomationError(
                f"ControlDesk automation not uspported on {platform.system()} systems. Cannot dispatch ControlDesk via COM."
            )
        else:
            raise ControlDeskAutomationError(
                f"Failed to dispatch ControlDesk. Required python modules `pywintypes` and `win32com` failed to import."
            )


def open_experiment(project_path: str | os.PathLike[str], experiment_name: str | None = None) -> typing.Any:
    """
    Open the project specified by `project_path` and activates the a specified contained experiment.
    The active experiment is returned.

    The `experment_name` can be omitted or None, if only a single experiment exists in the project.
    In that case it is activated, otherwise a ControlDeskAutomationError is raised.

    Args:
        project_path (str): full path to the projects CDP file.
        experiment_name (str | None): The experiment's display name. The argument can be omitted.

    Returns:
        win23com COM object: The opened experiment, which is now active.

    Raises:
        ControlDeskAutomationError: If experiment is omitted and cannot be determined as described.
        ControlDeskAutomationError: If any com errors occured
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        filename = os.fspath(project_path)
        try:
            if experiment_name is not None:
                return app.OpenExperiment(filename, experiment_name)
            else:
                project = app.OpenProject(filename)
                if project.Experiments.Count == 1:
                    project.Experiments[0].Activate()
                else:
                    try:
                        hint = "The following experiments are available: %s" % ", ".join(
                            [f'"{e.Name}"' for e in project.Experiments]
                        )
                    except Exception:
                        hint = None

                    raise ControlDeskAutomationError(
                        "Failed to open unspecified experiment from project '{filename}'.", hint=hint
                    )
        except _COM_ERROR as err:
            msg = f"Failed to open '{experiment_name}' experiment from project '{filename}'."
            raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err


def get_active_experiment() -> typing.Any:
    """
    Get the currently active experiment in ControlDesk if any.

    Returns:
        win32com COM object: The currently active ControlDesk experiment.

    Raises:
        ControlDeskAutomationError: If no experiment is currently active
        ControlDeskAutomationError: If any com errors occured
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if app.ActiveExperiment is None:
                raise ControlDeskAutomationError(
                    "Failed to get Active Experiment.", "No Experiment is currently Active"
                )
            else:
                return app.ActiveExperiment
        except _COM_ERROR as err:
            raise ControlDeskAutomationError("Failed to get Active Experiment.", error=_format_com_error(err)) from err


def get_platform(platform: str | int | None = None) -> typing.Any:
    """
    Get the specified platform from active experiment.

    Function assumes an active experiment, from which the platform shall be retrieved.
    The platform can be a platform name, an index or being omitted.
    If the platform is omitted and exactly only exists in the experiment it is returned.
    If the platform is a string and no such platform is not available,
    but a port of that name is mapped to a platform, then the mapped platform name is used instead.

    Args:
        platform (str | int | None): Platform name or index or port name. The argument can be ommitted.

    Returns:
        win32com COM object: The specified platform from active experiment.
    """
    exp = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if platform is None:
                try:
                    if exp.Platforms.Count == 1:
                        platform = 0
                except _COM_ERROR as err:
                    raise ControlDeskAutomationError(
                        "Failed to get Platform without specified key.", error=_format_com_error(err)
                    ) from err

            if isinstance(platform, int):
                return exp.Platforms.Item(platform)

            if exp.Platforms.Contains(platform):
                return exp.Platforms.Item(platform)

            try:
                if exp.Mappings.PortIdMappings.Contains(platform):
                    platform_name = exp.Mappings.PortIdMappings.Item(platform).PlatformName
                    return exp.Platforms.Item(platform_name)
                else:
                    msg = f"Failed to get Platform by name '{platform}'. The platform does not exists nor is such a port known."
                    raise ControlDeskAutomationError(msg)
            except _COM_ERROR as err:
                msg = f"Failed to get Platform by name '{platform}'. The platform does not exists and we ran into error using PortIdMappings."
                raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err

        except _COM_ERROR as err:
            msg = f"Failed to get Platform {repr(platform)}."
            hint = None
            if isinstance(platform, str):
                msg = "Failed to get Platform by name '{platform}'."
                try:
                    hint = "The following platforms are available: %s" % ", ".join(
                        [f'"{p.Name}"' for p in exp.Platforms]
                    )
                except Exception:
                    hint = None
            elif isinstance(platform, int):
                msg = "Failed to get Platform by index {platform}."
                try:
                    hint = "There are %i platforms available" % exp.Platforms.Count
                except Exception:
                    hint = None

            raise ControlDeskAutomationError(msg, hint=hint, error=_format_com_error(err)) from err


def get_active_variable_description(platform_or_key: str | int | None | typing.Any = None) -> typing.Any:
    """
    Get the active variable description from specified platform in active experiment.

    `platform_or_key` can be either:
    - a valid ControlDesk platform win32com COM object
    - a platform name or index, by which the platform is retrieved from active experiment.
    - None if only a single platform exists in active experiment.

    Args:
        platform_or_key (str | int| None | win32com COM object): the platform from which the variable description is retrieved.

    Returns:
        win32com COM object: the currently active variable description of specified platform in active experiment.

    Raises:
        ControlDeskAutomationError: If no variable description is currently active
        ControlDeskAutomationError: If any com errors occured
    """
    if _DISPATCH_BASE_CLASS is not None and not isinstance(platform_or_key, _DISPATCH_BASE_CLASS):
        platform = get_platform(platform_or_key)
    else:
        platform: typing.Any = platform_or_key
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if platform.ActiveVariableDescription is None:
                raise ControlDeskAutomationError(
                    "Failed to get Active Variable Description.", "No Variable Description is currently active"
                )
            else:
                return platform.ActiveVariableDescription
        except _COM_ERROR as err:
            raise ControlDeskAutomationError(
                "Failed to get Active Variable Description.", error=_format_com_error(err)
            ) from err


def get_variable(
    variable: FrameworkVariable | PortVariable | str, platform_or_key: str | int | None | typing.Any = None
) -> typing.Any:
    """
    Get a variable by specified `variable` from active variable description of specified platform.
    If a `PortVariable` is specified, its `port_id` is used as platform name and the `platform_or_key` should be omitted.
    If the port_id is not a valid platform identifier in ControlDesk experiment a `PortIdMapping` in ControlDesk must exist.

    Args:
        variable (FrameworkVariable | PortVariable | str): a variable path by which the variable is unique identified in the active variable description.
        platform_or_key (str | int| None | win32com COM object): platform to retrieve the variable description from.

    Returns:
        win32com COM object: The specified variable.

    Raises:
        ControlDeskAutomationError: If any com errors occured, or expected ControlDesk items are not active or retrievable.

    See also:
        :func:`get_active_variable_description()`
    """
    if isinstance(variable, FrameworkVariable):
        pv = Registry().get_port_variable(variable)
        variable_path, platform_or_key = pv.id, pv.port_id
    elif isinstance(variable, PortVariable):
        variable_path, platform_or_key = variable.id, variable.port_id
    else:
        variable_path = variable
    vardesc = get_active_variable_description(platform_or_key)
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            return vardesc.Variables.ItemByPath(variable_path)
        except _COM_ERROR as err:
            msg = f"Failed to get Variable by path '{variable_path}'."
            raise ControlDeskAutomationError(msg, _format_com_error(err)) from err


def read_variable(
    variable_path: FrameworkVariable | PortVariable | str, platform_or_key: str | int | None | typing.Any = None
) -> typing.Any:
    """
    Read the _converted_ value of variable specified by `variable_path`.

    Currently only the converted value is available for reading by this function

    Args:
        variable_path (FrameworkVariable | PortVariable | str): a variable path by which the variable is unique identified in the active variable description.
        platform_or_key (str | int| None | win32com COM object): platform to retrieve the variable description from.

    Returns:
        any: the converted value of specified variable.

    Raises:
        ControlDeskAutomationError: If any com errors occured, or expected ControlDesk items are not active or retrievable.

    See also:
        :func:`get_variable()`
    """
    variable = get_variable(variable_path, platform_or_key)
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            return variable.ValueConverted
        except _COM_ERROR as err:
            msg = f"Failed to read variable '{variable_path}'."
            raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err


def write_variable(
    variable_path: FrameworkVariable | PortVariable | str,
    value: typing.Any,
    platform_or_key: str | int | None | typing.Any = None,
) -> typing.Any:
    """
    Write the specified `value` as _converted_ value to the variable specified by `variable_path`.

    Currently only the converted value is written by this function.

    Args:
        variable_path (FrameworkVariable | PortVariable| str): a variable path by which the variable is unique identified in the active variable description.
        platform_or_key (str | int| None | win32com COM object): platform to retrieve the variable description from.

    Returns:
        any: the converted value of specified variable.

    Raises:
        ControlDeskAutomationError: If any com errors occured, or expected ControlDesk items are not active or retrievable.

    See also:
        :func:`get_variable()`
    """
    variable = get_variable(variable_path, platform_or_key)
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            variable.ValueConverted = value
        except _COM_ERROR as err:
            msg = f"Failed to write variable '{variable_path}'."
            raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err


def create_recorder(signals: typing.Iterable[FrameworkVariable | PortVariable]) -> typing.Any:
    """
    Create a new Recorder with specified signals.
    Signals can be specified as iterable of `FrameworkVariable` and/or `PortVariable`s,
    similar to the `get_variable()` function.

    This function creates a new recorder with unique name and configures it.
    The returned ControlDesk COM object can beused as input argument for `start_recording()` and
    `stop_recording()` functions.

    Note, that also a `Recorder` context manager exists, which combines all these three functions.

    Args:
        signals: iterable of signals to record.

    Returns:
        win32com COM object: The created and configured ControlDesk recorder.

    Raises:
        ControlDeskAutomationError: If any com errors occured, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            recorder_id = str(uuid.uuid4())
            recorder = app.MeasurementDataManagement.Recorders.Add(recorder_id)
            recorder.BaseFileName = f"{recorder_id}.mf4"

            measurement_conf_signals = app.MeasurementDataManagement.MeasurementConfiguration.Signals
            for sig in signals:
                try:
                    var = get_variable(sig)
                    measurement_signal = measurement_conf_signals.Add(var.Identifier.Path)
                    recorder.Signals.Insert(measurement_signal)
                except _COM_ERROR as err:
                    msg = f"Failed to add signal {sig} to recorder."
                    raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err

            return recorder
        except _COM_ERROR as err:
            msg = "Failed to create recorder."
            raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err


def start_recorder(recorder: typing.Any) -> None:
    """
    Start the specified recorder.
    If ControlDesk is not yet in Online or Measuring mode, they are started respectively,
    before starting the recorder.

    Note, that also a `Recorder` context manager exists.

    Args:
        recorder (win32com COM object): The ControlDesk recorder to start.

    Raises:
        ControlDeskAutomationError: If any com errors occured, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            app.CalibrationManagement.StartOnlineCalibration()
            app.MeasurementDataManagement.Start()
            recorder.Start()
        except _COM_ERROR as err:
            msg = f"Failed to start recorder '{recorder.Name}'."
            raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err


def stop_recorder(recorder: typing.Any) -> None:
    """
    Stop the specified recorder.
    The Measerement and Online modes are stopped as well.

    Note, that also a `Recorder` context manager exists.

    Args:
        recorder (win32com COM object): The ControlDesk recorder to start.

    Raises:
        ControlDeskAutomationError: If any com errors occured, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            recorder.Stop()
            app.MeasurementDataManagement.Stop()
            app.CalibrationManagement.StopOnlineCalibration()
        except _COM_ERROR as err:
            msg = f"Failed to stop recorder '{recorder.Name}'."
            raise ControlDeskAutomationError(msg, error=_format_com_error(err)) from err


class Recorder:
    def __init__(self, signals: typing.Iterable[FrameworkVariable | PortVariable]):
        self._recorder = create_recorder(signals)

    def __enter__(self):
        start_recorder(self._recorder)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> bool | None:
        stop_recorder(self._recorder)

    @property
    def recorded_file(self) -> str:
        """
        Get the full filename of recorderd MF4 file.

        Returns:
            str: the full filename of recorded MF4 file.
        Raises:
            ControlDeskAutomationError: If none or an ambiguous number of files was recorded.
        """
        if len(self._recorder.LastRecordedFiles) != 1:
            raise ControlDeskAutomationError(
                "Failed to retrieve recorded data.",
                "Recording has %i recorded files." % len(self._recorder.LastRecordedFiles),
            )
        return self._recorder.LastRecordedFiles[0]
