import typing

from openta.common.exceptions import AlreadyExistsError, NotFoundError, RegistryError

if typing.TYPE_CHECKING:
    from openta.common.ports import AbstractPort, PortVariable
    from openta.common.variables import FrameworkVariable


class Registry:
    """
    *intern*

    This is the global registry for all objects and items
    known to the openta.
    This is the very heart of dynamic access of variables and ports.
    Access from various collections provided to the user for the ease of use,
    are routed through this registry
    """

    _openta_registry_instance: typing.Optional["Registry"] = None

    def __new__(cls) -> "Registry":
        if cls._openta_registry_instance is None:
            cls._openta_registry_instance = super().__new__(cls)
            cls._openta_registry_instance._initialized = False
        return cls._openta_registry_instance

    def __init__(self):
        if not self._initialized:
            self._initialized = True
            self._ports: dict[str, "AbstractPort"] = {}
            self._variable_mapping: dict[str, tuple[str, str]] = {}
            self._framework_variables: dict[str, FrameworkVariable] = {}
            self._port_variables: dict[tuple[str, str], PortVariable] = {}

    def add_port(self, port_object: "AbstractPort"):
        """
        Add the given `port_object` to the registry.
        The `port_object.name` is used as unique key.

        raise: AlreadyExistsError
        """
        key = port_object.name
        if key not in self._ports:
            self._ports[key] = port_object
            return port_object
        raise AlreadyExistsError(key, "port", self._ports[key], port_object)

    def get_port(self, key: str) -> "AbstractPort":
        """
        Get the port associated with given `key`.
        """
        if key in self._ports:
            return self._ports[key]
        raise NotFoundError(key, "port")

    def get_port_count(self) -> int:
        return len(self._ports)

    def get_ports(self) -> list["AbstractPort"]:
        """
        Return the ports due to their order
        """
        return sorted(self._ports.values(), key=lambda port: port.get_option("order", default=0))

    def add_mapping_item(self, alias: "FrameworkVariable", port_variable: "PortVariable") -> None:
        fw_var_id = alias.id
        port_var_id = (port_variable.port_id, port_variable.id)
        port_id = port_variable.port_id
        try:
            # first some checks...
            if fw_var_id in self._framework_variables:
                raise AlreadyExistsError(fw_var_id, "alias", self._framework_variables[fw_var_id], alias)
            if port_var_id in self._port_variables:
                if self._port_variables[port_var_id] != port_variable:
                    raise AlreadyExistsError(
                        str(port_var_id),
                        "port variable",
                        self._port_variables[port_var_id],
                        alias,
                    )
            if port_id not in self._ports:
                raise NotFoundError(port_id, "port")

            # and then add the items to their respective collections
            self._framework_variables[fw_var_id] = alias
            self._port_variables[port_var_id] = port_variable
            self._variable_mapping[fw_var_id] = port_var_id

        except Exception as err:
            raise RegistryError(f"Failed to add variable mapping {alias} -> {port_variable}.") from err

    def get_port_variable(self, alias: typing.Union["FrameworkVariable", str]) -> "PortVariable":
        key = alias.id if not isinstance(alias, str) else alias
        port_var_id = self._variable_mapping[key]
        return self._port_variables[port_var_id]

    def get_framework_variable(self, alias: str) -> "FrameworkVariable":
        return self._framework_variables[alias]

    def get_framework_variable_count(self):
        return len(self._framework_variables)

    def get_framework_variables(self) -> typing.ValuesView["FrameworkVariable"]:
        return self._framework_variables.values()
