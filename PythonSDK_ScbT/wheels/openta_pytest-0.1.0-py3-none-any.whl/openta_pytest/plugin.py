import typing

import allure
import pytest

from openta.common.testenv import TestEnvironmentAccess
from openta.config.testenv_reader import TestEnvironmentConfigReader
from openta.xil.framework_reader import FrameworkReader


def pytest_addoption(parser: typing.Any) -> None:
    """
    Implements a pytest hook to add custom options to pytest.
    Adds option `--openta-xilframework-config` to specify a XIL API framework configuration xml file.
    """
    parser.addoption(
        "--openta-testenv-config",
        action="store",
        help="Path to the openta test environment configuration yaml file",
    )
    parser.addoption(
        "--openta-xilframework-config",
        action="store",
        help="Path to the XIL API Framework configuration XML file",
    )


def pytest_configure(config: typing.Any) -> None:
    """
    Implements a pytest hook to consume custom options to pytest.
    We check for the `--openta-xilframework-config` option,
    and if present, read the framework config, add ports and mapping information to the registry.
    """

    # TEMPORARILY CHANGE LOGGING OPTIONS
    config.option.log_cli = True
    config.option.log_cli_level = "INFO"  # Set the desired log level

    testenv_config = config.getoption("--openta-testenv-config")
    xil_framework_config = config.getoption("--openta-xilframework-config")

    if testenv_config and xil_framework_config:
        raise Exception("Either provide a openta test environment config or a xil api framework config. NOT BOTH.")

    if testenv_config:
        reader = TestEnvironmentConfigReader(testenv_config)
        reader.add_to_registry()
    elif xil_framework_config:
        reader = FrameworkReader(xil_framework_config)
        reader.add_to_registry()
    # No longer raising exception if no config is provided - this will be handled in the ta fixture
    # This enables the execution of pytest tests without the fixture


@pytest.hookimpl
def pytest_assertion_pass(item: typing.Any, lineno: int, orig: str, expl: str) -> None:
    """
    This pytest hook is called for passed assertions.
    Due to pytests assertion rewriting, the original assertion text (sourcecode) `orig`
    as well as the full explanation `expl` as for failed exceptions is provided.

    TODO: Here we use CURRENTLY an allure step for reporting the passed assertion.
    and an allure attachment for the full explanation.
    """
    msg = f"Assertion passed at line {lineno} in {item.nodeid}: {orig}"
    with allure.step("Passed: " + str(orig)):
        # attached text is formatted monospaced, providing better readability
        allure.attach(
            f"assert {orig}\n" + expl,
            name=orig,
            attachment_type=allure.attachment_type.TEXT,
        )

        # TODO: print /logging /nuscht ;)
        print(msg)


@pytest.hookimpl
def pytest_assertrepr_compare(config: object, op: str, left: object, right: object) -> list[str] | None:
    #
    # This pytest hook is called to format comparison expressions
    # in the full assert explanation.
    # By using this it is currently NOT possible to use something like
    # Framework variables variant or quantity property.

    # lhs = repr(left) if not isinstance(left, openta.xil.framework_variable.FrameworkVariable) else str(left)
    # rhs = repr(right) if not isinstance(right, openta.xil.framework_variable.FrameworkVariable) else str(right)
    # return [f"<{lhs} {op} {rhs}>"]

    # HERE: returning None yields the original formatting of pytest
    return None


@pytest.fixture(scope="session")
def ta(request: pytest.FixtureRequest) -> typing.Generator[TestEnvironmentAccess, None, None]:
    """
    Session scoped pytest fixture setting up the XIL API Framework.

    Requires either --openta-testenv-config or --openta-xilframework-config option.
    """
    # Check if config options were provided when fixture is used in a test
    testenv_config = request.config.getoption("--openta-testenv-config")
    xil_framework_config = request.config.getoption("--openta-xilframework-config")

    if not testenv_config and not xil_framework_config:
        raise pytest.UsageError(
            "The 'ta' fixture requires either --openta-testenv-config or --openta-xilframework-config option",
        )

    root = TestEnvironmentAccess()

    # ensure create/release lifecycle of ports by TestEnvironmentAccess
    with root:
        yield root
