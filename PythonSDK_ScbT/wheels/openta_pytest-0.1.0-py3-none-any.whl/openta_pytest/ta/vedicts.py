import contextlib
import traceback
from collections.abc import Generator
from typing import Any

import pytest


@contextlib.contextmanager
def skip_if_assert_failed() -> Generator[Any, Any, Any]:
    """
    Skip a pytest test instead of failing due to AssertionErrors.
    Use this context manager to ensure preconditions during the test.
    It is better to use `pytest.mark.SkipIf` if the condition can be checked in advance.
    """
    try:
        yield
    except AssertionError as err:
        pytest.skip("\n".join(traceback.format_exception_only(err)))
