import pytest

pytest.register_assert_rewrite("openta.ta.assertions")
