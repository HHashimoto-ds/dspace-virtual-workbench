# -*- coding: cp1252 -*-
"""
File:           EventHelper.py

Description:    This script contains helper functions for project and experiment events.

Preconditions:  -

Tip/Remarks:    -

Limitations:    -

Version:        1.3

Date:           Sep 2016

                dSPACE GmbH shall not be liable for errors contained herein or
                direct, indirect, special, incidental, or consequential damages
                in connection with the furnishing, performance, or use of this
                file.
                Brand names or product names are trademarks or registered
                trademarks of their respective companies or organizations.

� 2016, dSPACE GmbH. All rights reserved.
"""


#----------------------------------------------------------------------------------------------
# Function : SelectSignalFormReference
#      This function selects the corresponding signal form reference.
#----------------------------------------------------------------------------------------------
def SelectSignalFormReference(Application, Signal):
    """This function selects the corresponding signal form reference.
    
    Syntax      : SelectSignalFormReference(Application)
    
    Parameters  : Application   - object - The application object.
    
    Description : This function selects the corresponding signal form reference.
    
    Return Value: -
    """
    import pythoncom
    try:
        Mapping = {3 : 0, 4 : 1}
        
        # Get current signal form
        if Application.ActiveExperiment.Platforms[0].ActiveVariableDescription.Variables.Contains(Signal):
            SignalFormValue = Application.ActiveExperiment.Platforms[0].ActiveVariableDescription.Variables.Item(Signal).ValueSource
            if SignalFormValue in Mapping:
                # Activate corresponding signal form reference tab
                if Application.LayoutManagement.Layouts.Contains("signal generator"):
                    Application.LayoutManagement.Layouts["signal generator"].Instruments.Item("Signal Form").SubInstruments[Mapping[SignalFormValue]].Select()
                else:
                    print("Signal reference curve cannot be selected - Layout <signal generator> is not available!")
        else:
            print("Signal reference curve cannot be selected - Parameter <SignalForm> is not available!")
    except pythoncom.error as ex:
        print((ex.message, ex.args))
        print("Error selecting SignalForm reference curve!")    

#----------------------------------------------------------------------------------------------
# Function : SelectSignalForm
#      This function increments/decrements the parameter <Signal>.
#----------------------------------------------------------------------------------------------
def SelectSignalForm(Application, Signal, Mode):
    """This function increments/decrements the parameter <Signal>.
    
    Syntax      : SelectSignalForm(Application, Signal, Mode)
    
    Parameters  : Application - object - The application object.
                  Signal      - string - Parameter to be incremented.
                  Mode        - string - Defines the change mode (Increment or Decrement) 
    
    Description : This function increments/decrements the parameter <Signal>.
    
    Return Value: -
    """
    import pythoncom
    try:
        # Increment or Decrement the parameter <Signal>
        if Application.ActiveExperiment.Platforms[0].ActiveVariableDescription.Variables.Contains(Signal):
            CurrentSignal = Application.ActiveExperiment.Platforms[0].ActiveVariableDescription.Variables.Item(Signal)
            CurrentSignalForm = CurrentSignal.ValueSource
            
            if Mode == "Increment":
                # Increment the parameter <Signal>
                CurrentSignalForm += 1
            elif Mode == "Decrement":
                CurrentSignalForm -= 1
                
            # Handle overflow and set value
            if CurrentSignalForm > 4:
                CurrentSignal.ValueSource = 1
            elif CurrentSignalForm < 1:
                CurrentSignal.ValueSource = 4
            else:
                # Set new signal form value     
                CurrentSignal.ValueSource = CurrentSignalForm
            print(("%s %s selected" % (Signal, CurrentSignal.ValueConverted)))

            SelectSignalFormReference(Application, Signal)
        else:
            print(("Signal form cannot be selected - Parameter <%s> is not available!" % (Signal)))
    except pythoncom.error as ex:
        print((ex.message, ex.args))
        print("Error selecting signal form!")