"""
Design of Experiments (DoE) module.

This module contains functions related to Design of Experiments (DoE) methodologies
for creating efficient test designs. DoE is a systematic approach to determine the
relationship between factors affecting a process and the output of that process.
"""

from typing import Any

import pytest

from openta.testing.doe.ofat import ofat_variation


def ofat_variation_parametrize(
    param_dict: dict[str, list[Any]],
    defaults: dict[str, Any] | None = None,
    include_all_defaults: bool = True,  # noqa: FBT001, FBT002
) -> pytest.MarkDecorator:
    """
    Custom parametrize decorator that implements One-Factor-At-a-Time (OFAT) testing.
    Varies one parameter at a time while keeping others at default values.

    Args:
        param_dict: dictionary mapping parameter names to lists of values to test
        defaults: dictionary mapping parameter names to default values.
                 If None, uses the first value from each parameter's list
        include_all_defaults: Whether to include a test case with all defaults

    Returns:
        pytest.mark.parametrize decorator

    Example:
        ```python
        @ofat_variation_parametrize({
            'x': [1, 2, 3],
            'y': ['a', 'b'],
            'z': [True, False]
        })
        def test_example(x, y, z):
            assert isinstance(x, int)
            assert isinstance(y, str)
            assert isinstance(z, bool)
        ```
    """

    param_names, unique_cases = ofat_variation(
        param_dict=param_dict,
        defaults=defaults,
        include_all_defaults=include_all_defaults,
    )

    return pytest.mark.parametrize(",".join(param_names), unique_cases)
