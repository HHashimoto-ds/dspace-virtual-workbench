import pytest

pytest.register_assert_rewrite("openta.testing.assertions")
