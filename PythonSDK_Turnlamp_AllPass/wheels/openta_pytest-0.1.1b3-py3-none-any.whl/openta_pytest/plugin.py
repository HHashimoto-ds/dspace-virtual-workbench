import sys
import typing

import allure
import pytest

from openta.common.config.testenv_reader import TestEnvironmentConfigReader
from openta.testing.testenv import TestEnvironmentAccess


def pytest_addoption(parser: pytest.Parser) -> None:
    """
    Implements a pytest hook to add custom options to pytest.
    Adds option `--openta-xilframework-config` to specify a XIL API framework configuration xml file.
    """
    parser.addoption(
        "--openta-testenv-config",
        action="store",
        help="Path to the openta test environment configuration yaml file",
    )


@pytest.hookimpl
def pytest_assertion_pass(item: pytest.Item, lineno: int, orig: str, expl: str) -> None:
    """
    This pytest hook is called for passed assertions.
    Due to pytests assertion rewriting, the original assertion text (sourcecode) `orig`
    as well as the full explanation `expl` as for failed exceptions is provided.

    TODO: Here we use CURRENTLY an allure step for reporting the passed assertion.
    and an allure attachment for the full explanation.
    """
    msg = f"Assertion passed at line {lineno} in {item.nodeid}: {orig}"
    with allure.step("Passed: " + str(orig)):
        # attached text is formatted monospaced, providing better readability
        allure.attach(
            f"assert {orig}\n" + expl,
            name=orig,
            attachment_type=allure.attachment_type.TEXT,
        )

        # TODO: print /logging /nuscht ;)
        print(msg)


@pytest.fixture(scope="session")
def ta(request: pytest.FixtureRequest) -> typing.Generator[TestEnvironmentAccess, None, None]:
    """
    Session scoped pytest fixture setting up the XIL API Framework.

    Requires either --openta-testenv-config or --openta-xilframework-config option.
    """

    if "--collect-only" not in sys.argv:
        # Check if config options were provided when fixture is used in a test
        testenv_config = request.config.getoption("--openta-testenv-config")

        # but only one of them, they are mutual exclusive
        if not testenv_config:
            raise pytest.UsageError(
                "The `ta` fixture requires `--openta-testenv-config` pytest option.",
            )

        # Read the test environment configuration
        reader = TestEnvironmentConfigReader(testenv_config)  # pyright: ignore[reportArgumentType] : if it is not None, it is str
        reader.add_to_registry()

        # and instantiate the TestEnvironmentAccess, which is returned by this fixture,
        # but used as contextmanager, to setup and teardown configured ports.
        root = TestEnvironmentAccess()

        # ensure create/release lifecycle of ports by TestEnvironmentAccess
        with root:
            yield root

    else:
        # If pytest is run with `--collect-only` command line arguments, it is expected to not run tests,
        # however it may lead to execution/evaluation of session scoped fixtures,
        # if they are:
        # - marked with `autouse=True (not the case)
        # - referenced in `conftest.py` or any test modules (This is for sure the case)
        # In that case we simply yield None
        yield None  # pyright: ignore[reportReturnType] : in "--collect-only" mode return None
