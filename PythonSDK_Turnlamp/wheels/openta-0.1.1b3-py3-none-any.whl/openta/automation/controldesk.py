import contextlib
import os
import pathlib
import platform
import shutil
import types
import typing
import uuid
import warnings

from openta.common import exceptions, utils
from openta.common.config.registry import Registry
from openta.common.variables import FrameworkVariable, PortVariable
from openta.ports.abc import AbstractCapture, AbstractPort, CaptureState
from pandas import DataFrame, Series

# pyright: reportConstantRedefinition=false
if platform.system() == "Windows":
    try:
        import pywintypes
    except ImportError as err:
        _COM_ERROR = None
        warnings.warn(f"Failed to import `pywintypes`. ControlDesk automation support disabled. :: {err}", stacklevel=2)
    else:
        _COM_ERROR = pywintypes.com_error

    try:
        import win32com.client
    except ImportError as err:
        _DISPATCH = None
        _DISPATCH_BASE_CLASS = None
        warnings.warn(
            f"Failed to import `win32com.client`. ControlDesk automation support disabled. :: {err}",
            stacklevel=2,
        )
    else:
        _DISPATCH = win32com.client.Dispatch
        _DISPATCH_BASE_CLASS = win32com.client.DispatchBaseClass

else:
    _COM_ERROR = None
    _DISPATCH = None
    _DISPATCH_BASE_CLASS = None


try:
    from evaluationlib.data.mf4access import MF4Access
except ImportError:
    MF4Access = None
    warnings.warn(
        "Failed to import dSPACE `evaluationlib` python package. Retrieving data from MF4 files is not supported.",
        stacklevel=1,
    )


# Used to memoize a provided prog_id if divergent from "ControlDeskNG.Application"
# Currently the 'prog_id' can be provided by the ControlDesk port configuration,
# and if so it has to be used throughout the process.
# Problem is currently that intermediate methods may dispatch the application again,
# and in that case have to use the same already provided prog_id...
__PROG_ID = None


class ControlDeskAutomationError(exceptions.AutomationError):
    """
    Specialized `AutomationError` fixed to `ControlDesk`.
    """

    def __init__(self, message: str, origin: Exception | None = None) -> None:
        super().__init__("ControlDesk", message, origin)


def get_application(prog_id: str | None = None) -> typing.Any:
    """
    Create and return a win32com client object dispatched to provided `prog_id`,
    or if omitted to "ControlDeskNG.Application".

    Args:
        prog_id (str): The COM ProgId of the desired ControlDesk.
            If omitted ""ControlDeskNG.Application" is used.

    Returns:
        out (win32com COM object): The ControlDesk application.

    Raises:
        AutomationError: If any com errors occurred
    """
    global __PROG_ID
    if _DISPATCH is not None and _COM_ERROR is not None:
        if prog_id is None:
            # no prog_id provided: use previous or default
            prog_id = __PROG_ID if __PROG_ID is not None else "ControlDeskNG.Application"
        elif __PROG_ID is None:
            # prog_id provided, but not memoized from previous. memoize it
            __PROG_ID = prog_id
        elif prog_id != __PROG_ID:
            # prog_id is provided but different from previous: we have a situation
            raise ControlDeskAutomationError(
                f"Internal Error. Refused to dispatch '{prog_id}'. Within the same session another prog_id was used previously: '{__PROG_ID}'.",
            )

        try:
            return _DISPATCH(prog_id)
        except _COM_ERROR as err:
            raise ControlDeskAutomationError(f"Failed to dispatch '{prog_id}'.", origin=err) from err
    elif platform.system() != "Windows":
        raise ControlDeskAutomationError(
            f"ControlDesk automation not uspported on {platform.system()} systems. Cannot dispatch '{prog_id}' via COM.",
        )
    else:
        raise ControlDeskAutomationError(
            f"Failed to dispatch '{prog_id}'. Required python modules `pywintypes` and `win32com` failed to import.",
        )


def open_experiment(project_path: str | os.PathLike[str], experiment_name: str | None = None) -> typing.Any:
    """
    Open the project specified by `project_path` and activates the specified by `experiment_name` contained experiment.
    The active experiment is returned.

    The `experiment_name` can be omitted or None, if only a single experiment exists in the project.
    In that case it is activated, otherwise a ControlDeskAutomationError is raised.

    Args:
        project_path (str): full path to the projects CDP file.
        experiment_name (str | None): The experiment's display name. The argument can be omitted.

    Returns:
        out (win32com COM object): The opened experiment, which is now active.

    Raises:
        AutomationError: If experiment is omitted and cannot be determined as described.
        AutomationError: If any com errors occurred
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        filename = os.fspath(project_path)
        try:
            if experiment_name is not None:
                return app.OpenExperiment(filename, experiment_name)
            project = app.OpenProject(filename)
            if project.Experiments.Count == 1:
                project.Experiments[0].Activate()
                return app.ActiveExperiment
            msg = "Failed to open unspecified experiment from project '{filename}'."
            with contextlib.suppress(Exception):
                msg += " The following experiments are available: {}".format(
                    ", ".join(
                        [f'"{e.Name}"' for e in project.Experiments],
                    ),
                )

            raise ControlDeskAutomationError(msg)

        except _COM_ERROR as err:
            msg = f"Failed to open '{experiment_name}' experiment from project '{filename}'."
            raise ControlDeskAutomationError(msg, origin=err) from err
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError("Internal Error: Unexpected behaviour in `open_experiment`.")


def get_active_experiment() -> typing.Any:
    """
    Get the currently active experiment in ControlDesk if any.

    Returns:
        out (win32com COM object): The currently active ControlDesk experiment.

    Raises:
        AutomationError: If no experiment is currently active
        AutomationError: If any com errors occurred
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if app.ActiveExperiment is None:
                raise ControlDeskAutomationError(
                    "Failed to get Active Experiment. No Experiment is currently Active",
                )
            return app.ActiveExperiment  # noqa: TRY300
        except _COM_ERROR as err:
            raise ControlDeskAutomationError("Failed to get Active Experiment.", origin=err) from err
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError("Internal Error: Unexpected behaviour in `get_active_experiment`.")


def get_platform(platform: str | int | None = None) -> typing.Any:
    """
    Get the specified platform from active experiment.

    Function assumes an active experiment, from which the platform shall be retrieved.
    The platform can be a platform name, an index or being omitted.
    If the platform is omitted and exactly only exists in the experiment, it is returned.
    If the platform is a string and no such platform is available,
    but a port of that name is mapped to a platform, then the mapped platform name is used instead.

    Args:
        platform (str | int | None): Platform name or index or port name. The argument can be ommitted.

    Returns:
        out (win32com COM object): The specified platform from active experiment.
    """
    exp = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if platform is None:
                try:
                    if exp.Platforms.Count == 1:
                        platform = 0
                except _COM_ERROR as err:
                    raise ControlDeskAutomationError(
                        "Failed to get Platform without specified key.",
                        origin=err,
                    ) from err

            if isinstance(platform, int):
                return exp.Platforms.Item(platform)

            if exp.Platforms.Contains(platform):
                return exp.Platforms.Item(platform)

            try:
                if exp.Mappings.PortIdMappings.Contains(platform):
                    platform_name = exp.Mappings.PortIdMappings.Item(platform).PlatformName
                    return exp.Platforms.Item(platform_name)
                msg = f"Failed to get Platform by name '{platform}'. The platform does not exists nor is such a port known."
                raise ControlDeskAutomationError(msg)
            except _COM_ERROR as err:
                msg = f"Failed to get Platform by name '{platform}'. The platform does not exists and we ran into error using PortIdMappings."
                raise ControlDeskAutomationError(msg, origin=err) from err

        except _COM_ERROR as err:
            msg = f"Failed to get Platform {platform!r}."

            if isinstance(platform, str):
                msg = "Failed to get Platform by name '{platform}'."
                with contextlib.suppress(Exception):
                    msg += " The following platforms are available: {}".format(
                        ", ".join(
                            [f'"{p.Name}"' for p in exp.Platforms],
                        ),
                    )

            elif isinstance(platform, int):
                msg = "Failed to get Platform by index {platform}."
                with contextlib.suppress(Exception):
                    msg += f" There are {exp.Platforms.Count} platforms available"

            raise ControlDeskAutomationError(msg, origin=err) from err
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError("Internal Error: Unexpected behaviour in `get_platform`.")


def get_active_variable_description(platform_or_key: str | int | None | typing.Any = None) -> typing.Any:
    """
    Get the active variable description from specified platform in active experiment.

    `platform_or_key` can be either:
    - a valid ControlDesk platform win32com COM object
    - a platform name or index, by which the platform is retrieved from active experiment.
    - None if only a single platform exists in active experiment.

    Args:
        platform_or_key (str | int| None | win32com COM object): the platform from which the variable description is retrieved.

    Returns:
        out (win32com COM object): the currently active variable description of specified platform in active experiment.

    Raises:
        AutomationError: If no variable description is currently active
        AutomationError: If any com errors occurred
    """
    if _DISPATCH_BASE_CLASS is not None and not isinstance(platform_or_key, _DISPATCH_BASE_CLASS):
        platform = get_platform(platform_or_key)
    else:
        platform: typing.Any = platform_or_key
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if platform.ActiveVariableDescription is None:
                raise ControlDeskAutomationError(
                    "Failed to get Active Variable Description. No Variable Description is currently active",
                )
            return platform.ActiveVariableDescription  # noqa: TRY300
        except _COM_ERROR as err:
            raise ControlDeskAutomationError(
                "Failed to get Active Variable Description.",
                origin=err,
            ) from err
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError(
        "Internal Error: Unexpected behaviour in `get_active_variable_description`.",
    )


def get_variable(
    variable: FrameworkVariable | PortVariable | str,
    platform_or_key: str | int | None | typing.Any = None,
) -> typing.Any:
    """
    Get a variable by specified `variable` from active variable description of specified platform.
    If a `PortVariable` or `FrameworkVariable` is specified, its `port_id` is used as platform name and the `platform_or_key` should be omitted.
    If the port_id is not a valid platform identifier in ControlDesk experiment a `PortIdMapping` in ControlDesk must exist.

    Args:
        variable (FrameworkVariable | PortVariable | str): a variable path by which the variable is unique identified in the active variable description.
        platform_or_key (str | int| None | win32com COM object): platform to retrieve the variable description from.

    Returns:
        out (win32com COM object): The specified variable.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.

    See also:
        :func:`get_active_variable_description()`
    """
    if isinstance(variable, FrameworkVariable):
        pv = Registry().get_port_variable(variable)
        variable_path, platform_or_key = pv.id, pv.port_id
    elif isinstance(variable, PortVariable):
        variable_path, platform_or_key = variable.id, variable.port_id
    else:
        variable_path = variable
    vardesc = get_active_variable_description(platform_or_key)
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            return vardesc.Variables.ItemByPath(variable_path)
        except _COM_ERROR as err:
            msg = f"Failed to get Variable by path '{variable_path}'."
            raise ControlDeskAutomationError(msg, origin=err) from err
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError("Internal Error: Unexpected behaviour in `get_variable`.")


def read_variable(
    variable_path: FrameworkVariable | PortVariable | str,
    platform_or_key: str | int | None | typing.Any = None,
) -> typing.Any:
    """
    Read the _converted_ value of variable specified by `variable_path`.

    Currently only the converted value is available for reading by this function

    Args:
        variable_path (FrameworkVariable | PortVariable | str): a variable path by which the variable is unique identified in the active variable description.
        platform_or_key (str | int| None | win32com COM object): platform to retrieve the variable description from.

    Returns:
        out (any): the converted value of specified variable.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.

    See also:
        :func:`get_variable()`
    """
    variable = get_variable(variable_path, platform_or_key)
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            return variable.ValueConverted
        except _COM_ERROR as err:
            msg = f"Failed to read variable '{variable_path}'."
            raise ControlDeskAutomationError(msg, origin=err) from err
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError("Internal Error: Unexpected behaviour in `read_variable`.")


def write_variable(
    variable_path: FrameworkVariable | PortVariable | str,
    value: typing.Any,
    platform_or_key: str | int | None | typing.Any = None,
) -> typing.Any:
    """
    Write the specified `value` as _converted_ value to the variable specified by `variable_path`.

    Currently only the converted value is written by this function.

    Args:
        variable_path (FrameworkVariable | PortVariable| str): a variable path by which the variable is unique identified in the active variable description.
        platform_or_key (str | int| None | win32com COM object): platform to retrieve the variable description from.

    Returns:
        out (any): the converted value of specified variable.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.

    See also:
        :func:`get_variable()`
    """
    variable = get_variable(variable_path, platform_or_key)
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            variable.ValueConverted = value
        except _COM_ERROR as err:
            msg = f"Failed to write variable '{variable_path}'."
            raise ControlDeskAutomationError(msg, origin=err) from err


def create_recorder(
    signals: typing.Iterable[FrameworkVariable | PortVariable | str],
    raster_name: str | None = None,
) -> typing.Any:
    """
    Create a new Recorder with specified signals.
    Signals can be specified as iterable of `FrameworkVariable` and/or `PortVariable`s,
    similar to the `get_variable()` function.

    This function creates a new recorder with unique name and configures it.
    The returned ControlDesk COM object can be used as input argument for `start_recording()` and
    `stop_recording()` functions.

    Args:
        signals: iterable of signals to record.
        raster_name (str, optional): the raster_name for signals which are added. Defaults to what is chosen by ControlDesk

    Returns:
        out (win32com COM object): The created and configured ControlDesk recorder.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            recorder_id = str(uuid.uuid4())
            recorder = app.MeasurementDataManagement.Recorders.Add(recorder_id)

            # Add signals to recorder
            for signal in signals:
                measurement_signal = add_measurement_configuration_signal(signal, raster_name=raster_name)
                recorder.Signals.Insert(measurement_signal)
        except _COM_ERROR as err:
            msg = "Failed to create recorder."
            raise ControlDeskAutomationError(msg, origin=err) from err
        else:
            return recorder
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError("Internal Error: Unexpected behaviour in `create_recorder`.")


def add_measurement_configuration_signal(
    variable: FrameworkVariable | PortVariable | str,
    platform_or_key: str | int | None | typing.Any = None,
    raster_name: str | None = None,
) -> typing.Any:
    """
    Add a signal to `MeasurementConfiguration.Signals` corresponding to the specified `variable`.
    If a `PortVariable` or `FrameworkVariable` is specified, its `port_id` is used as platform name and the `platform_or_key` should be omitted.
    If the port_id is not a valid platform identifier in ControlDesk experiment, a `PortIdMapping` in ControlDesk must exist.

    The ControlDesk variable is then added to the ControlDesk `MeasurementDataManagement.MeasurementConfiguration.Signals` collection.
    The resulting measurement signal is returned and can be added to ControlDesk Recorder.

    An optional `raster_name` is assigned only if provided. Otherwise ControlDesk chooses a default.

    Args:
        variable_path (FrameworkVariable | PortVariable| str): a variable path by which the variable is unique identified in the active variable description.
        platform_or_key (str | int| None | win32com COM object): platform to retrieve the variable description from.

     Returns:
        out (win32com COM object): The created measurement signal, which can be added to Recorders.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            measurement_conf_signals = app.MeasurementDataManagement.MeasurementConfiguration.Signals
            var = get_variable(variable, platform_or_key)
            measurement_signal = measurement_conf_signals.Add(var.Identifier.Path)
            if raster_name is not None:
                try:
                    measurement_signal.RasterName = raster_name
                except _COM_ERROR as err:
                    warnings.warn(
                        f"Raster '{raster_name}' not valid for MeasurementConfiguration.Signal for '{variable}'."
                        f" :: {exceptions.format_com_error(err)}",
                        stacklevel=2,
                    )
        except _COM_ERROR as err:
            msg = f"Failed to add '{variable}' to MeasurementConfiguration.Signals."
            raise ControlDeskAutomationError(msg, origin=err) from err
        else:
            return measurement_signal
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError(
        "Internal Error: Unexpected behaviour in `add_measurement_configuration_signal`.",
    )


def add_measurement_configuration_trigger(condition: str, trigger_name: str) -> typing.Any:
    """
    Create a ControlDesk TriggerRule based on specified condition string.
    Identifiers used in condition must be defined as FrameworkVariables in the mapping
    and `MeasurementConfiguration.Signals` are added for them and assigned to the TriggerRule.Mapping.

    The returned TriggerRule, can then be added to Recorder StartCondition or StopCondition.

    Args:
        condition (str): a trigger condition in ControlDesk syntax. Identifier are expected to be defined in mapping.
        trigger_name (str): a name for the trigger definition.

     Returns:
        out (win32com COM object): The created ControlDesk TriggerRule, which can be added to StartCondition and StopCondition of Recorders.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            trigger = app.MeasurementDataManagement.TriggerRules.Add(trigger_name)
            trigger.Enabled = True

            # add mapping of alias to ControlDesk measurement signal
            aliases = utils.get_identifier_from_controldesk_trigger_rule(condition)
            reg = Registry()
            for alias in aliases:
                # first determine opent FrameworkVariable for alias
                variable = reg.get_framework_variable(alias)
                trigger.Mappings.Add(alias, add_measurement_configuration_signal(variable))

            trigger.Definition = condition
        except _COM_ERROR as err:
            msg = f'Failed to create "{trigger_name}" for condition: "{condition}".'
            raise ControlDeskAutomationError(msg, origin=err) from err
        else:
            return trigger
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ControlDeskAutomationError(
        "Internal Error: Unexpected behaviour in `add_measurement_configuration_trigger`.",
    )


def start_recorder(recorder: typing.Any) -> None:
    """
    Start the specified recorder.
    If ControlDesk is not yet in Online or Measuring mode, they are started respectively,
    before starting the recorder.

    Note, that also a `Recorder` context manager exists.

    Args:
        recorder (win32com COM object): The ControlDesk recorder to start.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            app.CalibrationManagement.StartOnlineCalibration()
            app.MeasurementDataManagement.Start()
            # Start with triggers enabled
            recorder.Start(True, True)  # noqa: FBT003
        except _COM_ERROR as err:
            msg = f"Failed to start recorder '{recorder.Name}'."
            raise ControlDeskAutomationError(msg, origin=err) from err


def stop_recorder(recorder: typing.Any) -> None:
    """
    Stop the specified recorder.
    The Measurement and Online modes are stopped as well.

    Note, that also a `Recorder` context manager exists.

    Args:
        recorder (win32com COM object): The ControlDesk recorder to start.

    Raises:
        AutomationError: If any com errors occurred, or expected ControlDesk items are not active or retrievable.
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            recorder.Stop()
            app.MeasurementDataManagement.Stop()
        except _COM_ERROR as err:
            msg = f"Failed to stop recorder '{recorder.Name}'."
            raise ControlDeskAutomationError(msg, origin=err) from err


class Recorder(AbstractCapture):
    """
    Contextmanager for a configuration and start/stop of a ControlDesk recorder.
    The ControlDesk recorder COM object is created on __init__, but also be configured partly afterwards.

    Note, that the Recorder implements the AbstractCapture, but does not have any port reference,
    thus it will raise an exception if the port is accessed.

    And unlike the standard AbstractCapture interface, it supports the context manager protocol.
    """

    def __init__(
        self,
        signals: typing.Iterable[FrameworkVariable | PortVariable | str] | None = None,
        raster_name: str | None = None,
    ) -> None:
        """
        Initialize the capture.
        If a raster_name is provided, it is used as raster for all added signals,
        otherwise the default raster will be chosen by ControlDesk.
        """
        super().__init__()
        self._raster_name = raster_name
        self._mf4_filepath = None

        self._recorder_variables: list[FrameworkVariable] = []
        self._recorder: typing.Any = create_recorder([], raster_name)
        if signals is not None:
            self.variables = signals

    def __enter__(self) -> typing.Self:
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> bool | None:
        #
        #   TODO: according to ControlDEsk Docu
        #   Stops the recording immediately.
        #   What about triggers ??
        #
        self.stop()

    @property
    def origin(self) -> typing.Any | None:
        """
        Get the underlying ControlDesk Recorder COM object.
        """
        return self._recorder

    @property
    def port(self) -> AbstractPort:
        """
        Note that the Recorder context manager does not have a port associated with it,
        and will always raise an exception
        """
        raise NotImplementedError("The ControlDesk Recorder does not have an associated port object.")

    @property
    def state(self) -> CaptureState:
        # NOTE: controldesk recorders RecordingState has no state for CaptureState.FINISHED...
        if self._recorder is None:
            return CaptureState.RELEASED

        state = self._recorder.State
        if state == 0:
            return CaptureState.CONFIGURED
        if state == 1:
            return CaptureState.ACTIVATED
        if state == 2:
            return CaptureState.RUNNING
        raise exceptions.CaptureStateError(
            f"Cannot determine Capture state. Retrieved unexpected state ({state}) from dSPACE ControlDesk recorder.",
        )

    @property
    def datafile_path(self) -> pathlib.Path | None:
        """
        Returns the configured path to the mf4 capture data file.
        None if not configured.
        """
        return self._mf4_filepath

    @datafile_path.setter
    def datafile_path(self, value: os.PathLike[str] | str) -> None:
        """
        Path of capture result mf4 file (optional)
        """
        p = pathlib.Path(value)
        if not p.suffixes:
            p = p.with_suffix(".mf4")
        elif p.suffix.lower() != ".mf4":
            raise exceptions.CaptureError("Expect a filename with .mf4 suffix.")
        self._mf4_filepath = p

    def start(self) -> None:
        """
        Start the capture process
        """
        start_recorder(self._recorder)

    def stop(self) -> None:
        """
        Stop the capture process
        """
        stop_recorder(self._recorder)
        if len(self._recorder.LastRecordedFiles) != 1:
            raise exceptions.CaptureError(
                "Failed to retrieve recorded data. "  # noqa: ISC003
                + f"Recording has {len(self._recorder.LastRecordedFiles)} recorded files.",
            )
        if self._mf4_filepath is None:
            self._mf4_filepath = pathlib.Path(self._recorder.LastRecordedFiles[0])
        else:
            if self._mf4_filepath.exists():
                raise exceptions.CaptureError("mf4 file already exists")
            if not self._mf4_filepath.parent.exists():
                self._mf4_filepath.parent.mkdir(parents=True, exist_ok=True)

            # copy the file, from ControlDesk project to specified datafile_path
            shutil.copy2(self._recorder.LastRecordedFiles[0], self._mf4_filepath)

    def release(self) -> None:
        """
        Call dispose of XIL capture and release member
        """
        self._recorder.Remove()

    @property
    def variables(self) -> typing.Iterable[FrameworkVariable]:
        """
        Collection of alias identifer to capture
        """
        return iter(self._recorder_variables)

    @variables.setter
    def variables(self, value: typing.Iterable[FrameworkVariable | PortVariable | str]) -> None:
        """
        Collection of alias identifier to be captured.
        """
        reg = Registry()
        for variable in value:
            measurement_signal = add_measurement_configuration_signal(variable, raster_name=self.raster_name)
            self._recorder.Signals.Insert(measurement_signal)
            if isinstance(variable, FrameworkVariable):
                self._recorder_variables.append(variable)
            elif isinstance(variable, str):
                self._recorder_variables.append(reg.get_framework_variable(variable))
            else:
                raise NotImplementedError("Adding PortVariables to a ControlDesk Recorder is currently not supported")

    @property
    def raster_name(self) -> str | None:
        """
        Task name for capture process (optional).
        If not set ControlDesk chooses the raster, presumably `onChange`.
        """
        return self._raster_name

    @raster_name.setter
    def raster_name(self, value: str) -> None:
        """
        Configure capture task
        """
        self._raster_name = value

    def set_start_trigger(self, condition: str, delay: float | None = None) -> None:
        """
        Configure the start trigger condition of this capture.
        Only ConditionWatcher supported.
        """
        try:
            # Note, order is crucial, first Enable trigger, then specify properties,
            # otherwise definitions might get overwritten, when enabling the condition
            self._recorder.StartCondition.Enabled = True

            trigger_rule = add_measurement_configuration_trigger(condition, f"start-{self._recorder.Name}")
            self._recorder.StartCondition.Trigger = trigger_rule

            if delay is not None:
                self._recorder.StartCondition.TriggerDelay = delay
        except _COM_ERROR as err:  # type: ignore
            msg = f"Failed set start trigger for ControlDesk recorder '{self._recorder.Name}'."
            raise ControlDeskAutomationError(msg, origin=err) from err

    def set_stop_trigger(self, condition_or_duration: str | float, delay: float | None = None) -> None:
        try:
            # Note, order is crucial, first Enable trigger, then specify properties,
            # otherwise definitions might get overwritten, when enabling the condition
            self._recorder.StopCondition.Enabled = True

            if isinstance(condition_or_duration, str):
                trigger_rule = add_measurement_configuration_trigger(
                    condition_or_duration,
                    f"stop-{self._recorder.Name}",
                )
                self._recorder.StopCondition.Type = 1  # 1 == StopConditionType.Trigger; 0 == TimeLimit is default
                self._recorder.StopCondition.Trigger = trigger_rule

                if delay is not None:
                    self._recorder.StopCondition.TriggerDelay = delay
            elif isinstance(condition_or_duration, float):
                self._recorder.StopCondition.Type = 0  # 0 == TimeLimit is default
                self._recorder.StopCondition.TimeLimit = condition_or_duration

        except _COM_ERROR as err:  # type: ignore
            msg = f"Failed set start trigger for ControlDesk recorder '{self._recorder.Name}'."
            raise ControlDeskAutomationError(msg, origin=err) from err

    def get_signal(self, variable: str | FrameworkVariable) -> Series:
        testbench_id = ""

        if isinstance(variable, str):
            testbench_id = variable
        elif isinstance(variable, FrameworkVariable):
            testbench_id = Registry().get_port_variable(variable).id
        else:
            raise exceptions.CaptureError(
                f"Cannot extract signal {variable} with unsupported type '{type(variable)}'.",
            )

        if MF4Access is not None:
            with MF4Access(self._mf4_filepath.as_posix()) as mf4:
                matching_channels = [chn for chn in mf4.Channels if chn[3] == testbench_id]
                if len(matching_channels) != 1:
                    raise exceptions.CaptureError(
                        f"Cannot extract signal from mf4 file. Found {len(matching_channels)} entries for requested signal ({variable}).",
                    )

                data_arrays = mf4.ReadChannel(*(matching_channels[0]))
                return Series(data_arrays[1], index=data_arrays[0])
        else:
            raise exceptions.CaptureError(
                f"Cannot extract signal '{variable}', because dSPACE evaluationlib python package is not installed.",
            )

    def get_data_frame(self) -> DataFrame:
        """
        Get all captured data as pandas.DataFrame.
        """
        data_frame = DataFrame({str(fw_var): self.get_signal(fw_var) for fw_var in self.variables})
        if self.raster_name:
            data_frame.index.name = self.raster_name
        return data_frame
