import contextlib
import logging
import os
import time
import typing
from http import HTTPStatus
from urllib.parse import quote

import requests

import openta.automation.aurelion.clients.baseclient
from openta.automation.aurelion.clients import exceptions
from openta.automation.aurelion.clients.acclient import ACClient

_logger = logging.getLogger(__name__)


class AMClient(openta.automation.aurelion.clients.baseclient.BaseClient):
    instance = None

    def __init__(self, url: str) -> None:
        super().__init__(url)

    @classmethod
    def get_instance(cls, url: str) -> "AMClient":
        if cls.instance is None:
            cls.instance = AMClient(url)
        return cls.instance

    def _should_we_retry(self, response: requests.Response, retry_counter: int) -> tuple[bool, float]:
        max_retries = 5
        if (
            response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR
            and "Internal Server Error" in response.text
            and retry_counter < max_retries
        ):
            _logger.info("AurelionManager: Retry after 10s because of 'Internal Server Error'.")
            _logger.info(response.text)
            return True, 10
        if response.status_code == HTTPStatus.PRECONDITION_FAILED and retry_counter < max_retries:
            _logger.info("AurelionManager: Retry after 10s because of error 412 (Some dependency is not available).")
            _logger.info(response.text)
            return True, 10
        return False, 0

    # Section "General"

    def get_general_version(self) -> tuple[int, int, int]:
        return self.request_json("GET", "general/version")

    def delete_general_exit(self) -> None:
        self.request("DELETE", "general/exit")

    # Convenience for "General"

    def exit_and_wait(self) -> None:
        for _ in range(30):
            try:
                self.delete_general_exit()
                time.sleep(5)
            except requests.exceptions.ConnectionError:
                # This is expected, we want the Manager to shut down.
                # Wait another 5s to make sure everything is really down before
                # continuing.
                time.sleep(5)
                return
        raise exceptions.AurelionApiException(
            "Failed to shut down aurelion manager. Despite calling exit REST API stayed available.",
        )

    def am_version(self) -> tuple[int, ...]:
        response = self.request("GET", "general/version")
        return tuple(int(x) for x in response.json().split("."))

    def am_version_matches_or_later(self, a: int, b: int, c: int) -> bool:
        """Returns true if current Version is at least a.b.c"""
        return (a, b, c) <= self.am_version()

    # Section "Projects"

    def put_projects_open_project(self, path: str) -> None:
        head, tail = os.path.split(path)
        if tail.lower() == "project.json":
            path = head
        self.request("PUT", f"projects/openProject/{quote(path, safe=[])}")

    def get_projects_current_project(self) -> dict[str, typing.Any] | None:
        res = self.request(
            "GET",
            "projects/currentProject",
            okay={HTTPStatus.PRECONDITION_FAILED: "No open project. Open a project first."},
        )
        if res.status_code == HTTPStatus.PRECONDITION_FAILED:
            return None
        return res.json()

    # Section "Scenarios"

    def get_scenarios(self) -> list[typing.Any]:
        "Calls GET /scenarios."
        return self.request_json("GET", "scenarios")

    # Section "Simulation"

    def get_simulation_state(self) -> dict[typing.Any, typing.Any]:
        "Calls GET simulation/state"
        return self.request_json("GET", "simulation/state")

    def put_simulation_reset(self) -> None:
        if self.am_version_matches_or_later(23, 3, 0):
            self.request(
                "PUT",
                "simulation/reset",
                okay={
                    HTTPStatus.NOT_FOUND: 'Aurelion Manager: Got a HTTP-Code 404 "No simulation active." when calling simulation/reset.',
                },
            )
        else:
            self.request(
                "PUT",
                "simulation/reset",
                okay={
                    HTTPStatus.INTERNAL_SERVER_ERROR: (
                        "Aurelion Manager: Got a HTTP-Code 500 when calling simulation/reset. "
                        "This is likely because no simulation is running, continue without error."
                    ),
                },
            )

    def put_simulation_synchronize(self, systemid: str, scenarioid: str) -> None:
        """calls PUT simulation/synchronize/{systemid}/{scenarioid}.
        Most likely you want to use c_synchronize instead which takes names as arguments."""
        _logger.info("Synchronizing AURELION, this may take several minutes...")
        self.request("PUT", f"simulation/synchronize/{systemid}/{scenarioid}")
        _logger.info("Finished synchronizing AURELION")

    # Convenience for "Simulation"

    def synchronize(self, systemname: str, scenarioname: str) -> None:
        """Synchronizes a system and scenario.

        Args:
            systemname (str): name of the system. System names have to be unique.
            scenarioname (str): name of the 3d scenario. Scenario names have to be unique.

        Raises:
            exceptions.AurelionManagerConfigurationError: when System or Scenario is not found.
        """
        # check scenario first because of #1021383
        scenario_lst = self.get_scenarios()
        sys_lst = self.get_systems()

        for system in sys_lst:
            if system["name"] == systemname:
                sysid = system["id"]
                break
        else:
            raise exceptions.AurelionManagerConfigurationError(f"System {systemname} not found")
        for scenario in scenario_lst:
            if scenario["name"] == scenarioname:
                scenarioid = scenario["id"]
                break
        else:
            raise exceptions.AurelionManagerConfigurationError(f"Scenario {scenarioname} not found")
        self.put_simulation_synchronize(sysid, scenarioid)

    # Section "Systems"

    def get_systems(self) -> list[typing.Any]:
        "Calls GET /systems"
        return self.request_json("GET", "systems")

    # Added Toolchain functionality

    def get_ac_instances(self) -> list[ACClient]:
        """Returns all aurelion control instances"""
        state = self.get_simulation_state()
        all_instances = [x["basePath"] for x in state["config"]["aurelion"]["instances"]]
        return [ACClient.get_instance(base) for base in all_instances]

    def get_rsg_scenario_name(self) -> str:
        """Returns the scenario name for using the Road Scene Generator(RSG). This is typically
        "Active road from ModelDesk" which has the option "Use road to generate environment" configured.
        Exactly one Scenario with selected 3D enviornment "Use road to generate environment" is expected, otherwise an exception is raised.

        Returns:
            str: name of the RSG scenario
        """
        scenarios = self.get_scenarios()
        rsg = [s for s in scenarios if s["scenery"]["selection"] == "rsg"]
        if len(rsg) > 1:
            raise exceptions.AurelionApiException(
                """More than one Road Scene Generator Scenario is configured in the AurelionManager. Unclear which one use for synchronisation. Exactly one Scenario with selected 3D enviornment "Use road to generate environment" is expected.""",
            )
        if len(rsg) == 0:
            raise exceptions.AurelionApiException(
                """No Road Scene Generator Scenario is configured in the AurelionManager. Exactly one Scenario with selected 3D enviornment "Use road to generate environment" is expected.""",
            )
        return rsg[0]["name"]

    def _raise_error(self, response: requests.Response) -> None:
        if response.request.method == "PUT" and "projects/openProject" in response.url:
            if response.status_code == HTTPStatus.NOT_FOUND:
                raise exceptions.AurelionManagerProjectNotFound
            if response.status_code == HTTPStatus.UPGRADE_REQUIRED:
                raise exceptions.AurelionManagerProjectMigrationRequired

        if response.status_code == HTTPStatus.NOT_FOUND and "No open project. Open a project first." in response.text:
            # 404 is used for no simulation running and project not open. Raise
            # only in case project is not open.
            raise exceptions.AurelionNoSimulationRunning

        if response.status_code == HTTPStatus.PRECONDITION_FAILED:
            # Introduced with Aurelion 23.3
            text = response.text
            with contextlib.suppress(Exception):
                text = response.json()["additionalData"]
            raise exceptions.AurelionManager412DependencyNotAvailable(text)
        if (
            response.status_code == HTTPStatus.NO_CONTENT
            and response.request.method == "GET"
            and "simulation/state" in response.url
        ):
            # Up to 23.2 simulation/state returned 204 if no simulation is
            # running
            raise exceptions.AurelionNoSimulationRunning
        super()._raise_error(response)
