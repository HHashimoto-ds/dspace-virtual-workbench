class AurelionApiException(Exception):
    pass


class AurelionConfugurationError(Exception):
    pass


class AurelonPropertyOutOfRange(AurelionApiException):
    pass


class AurelonClientStuckBusy(AurelionApiException):
    pass


class AurelionApiUnexpected204NoContent(AurelionApiException):
    pass


class AurelionNoSimulationRunning(AurelionApiException):
    pass


class AurelionManager412DependencyNotAvailable(AurelionApiException):
    pass


class AurelionManagerConfigurationError(AurelionApiException):
    pass


class AurelionManagerProjectNotFound(AurelionApiException):
    pass


class AurelionManagerProjectMigrationRequired(AurelionApiException):
    pass
