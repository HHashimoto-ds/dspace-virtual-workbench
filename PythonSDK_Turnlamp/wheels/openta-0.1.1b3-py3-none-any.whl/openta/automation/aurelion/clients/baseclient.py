import logging
import time
import typing
from abc import ABC, abstractmethod
from collections.abc import Mapping
from http import HTTPStatus

import requests

from openta.automation.aurelion.clients import exceptions
from openta.automation.aurelion.clients.utils import try_prettify_json

_logger = logging.getLogger(__name__)


class BaseClient(ABC):
    def __init__(self, base: str) -> None:
        self.base: str = base

    def request(
        self,
        method: str,
        url: str,
        json: typing.Any | None = None,
        params: Mapping[str, str | int | float | bool] | None = None,
        okay: dict[int, str] | None = None,
    ) -> requests.Response:
        max_retry = 10
        for retry_counter in range(max_retry):
            fullurl = self.base + "/" + url
            response = requests.request(method, fullurl, json=json, params=params, timeout=600)
            if okay is not None and response.status_code in okay:
                # Certain status >=400 are not to be raised as an error
                pass
            else:
                retry, backoff = self._should_we_retry(response, retry_counter)
                if retry:
                    _logger.info(f"Retry after {backoff}")
                    time.sleep(backoff)
                    continue
                self._raise_error(response)
                self._raise_error(response)

            return response
        raise exceptions.AurelionApiException("Retry failed")

    def request_json(
        self,
        method: str,
        url: str,
        json: typing.Any | None = None,
        params: Mapping[str, str | float | bool] | None = None,
    ) -> typing.Any:
        response = self.request(method, url, json=json, params=params, okay=None)

        if response.status_code == HTTPStatus.NO_CONTENT:
            # Response code 204 is a problem when we expect payload
            raise exceptions.AurelionApiUnexpected204NoContent
        return response.json()

    @abstractmethod
    def _should_we_retry(self, response: requests.Response, retry_counter: int) -> tuple[bool, float]:
        pass

    def _raise_error(self, response: requests.Response) -> None:
        try:
            response.raise_for_status()
        except Exception:
            txt = try_prettify_json(response.text)
            _logger.warning(
                f"Aurelion: {response.status_code} with payload {txt} when calling "
                "{response.request.method} {response.url}",
            )
            raise
