import logging
import time
import typing
from http import HTTPStatus

import openta.automation.aurelion.clients.baseclient
from openta.automation.aurelion.clients import exceptions, utils

if typing.TYPE_CHECKING:  # pragma: no cover
    import requests

_logger = logging.getLogger(__name__)


class ACClient(openta.automation.aurelion.clients.baseclient.BaseClient):
    instances: typing.ClassVar[dict[str, "ACClient"]] = {}

    @classmethod
    def get_instance(cls, base: str) -> "ACClient":
        if base not in cls.instances:
            cls.instances[base] = ACClient(base)
        if not cls.instances[base].base == base:
            raise exceptions.AurelionApiException(
                f"Internal error, insonsistent base {cls.instances[base].base} vs {base}",
            )
        return cls.instances[base]

    def _should_we_retry(self, response: "requests.Response", retry_counter: int) -> tuple[bool, int]:
        max_retries = 10
        if response.status_code == HTTPStatus.SERVICE_UNAVAILABLE and retry_counter < max_retries:
            return True, 10
        return False, 0

    def get_simulation(self) -> dict[str, typing.Any]:
        return self.request_json("GET", "api/Aurelion/v2/Simulation")

    def get_aurelion_state(self) -> dict[str, typing.Any]:
        return self.request_json("GET", "api/Aurelion/v2/AurelionState")

    def put_simulation(self, simulate: bool, view_mode: str) -> None:  # noqa: FBT001
        self.request("PUT", "api/Aurelion/v2/Simulation", json={"simulate": simulate, "viewMode": view_mode})

    def get_scene_assets(
        self,
        scene_asset_type: str,
        without_properties: bool,  # noqa: FBT001
        without_bounding_box: bool,  # noqa: FBT001
        rubric: str | None = None,
    ) -> dict[str, typing.Any]:
        """Gets all assets from the current scene."""
        params = {
            "type": scene_asset_type,
            "withoutProperties": without_properties,
            "withoutBoundingBox": without_bounding_box,
        }
        if rubric is not None:
            params["rubric"] = rubric
        return self.request_json("GET", "api/Aurelion/v2/SceneAssets", params=params)

    def put_scene_assets(self, data: list[dict[str, typing.Any]]) -> None:
        """Updates assets based on the given information."""
        self.request("PUT", "api/Aurelion/v2/SceneAssets", data)

    def update_scene_asset(
        self,
        assettype: str,
        rubric: str,
        parameter: dict[str, typing.Any],
    ) -> dict[str, typing.Any]:
        # Get all assets. Rubric is not an exact match, so multiple values might be returned.
        data = self.get_scene_assets(assettype, without_properties=False, without_bounding_box=True, rubric=rubric)
        # Identify right asset exactly matching the name
        right_asset = utils.r_get_by_name(data, [rubric])
        if not (isinstance(right_asset, dict)):
            raise exceptions.AurelionApiException("Unexpected datastructure from Aurelion")

        # Store current properties
        properties = right_asset["properties"]

        # Empty list of properties, we only send out the changed properties.
        right_asset["properties"] = []

        # Build list of changed properties. Use output of "get" as a template.
        for asset_property, value in parameter.items():
            prop = utils.r_get_by_name(properties, [asset_property])
            if not (isinstance(prop, dict)):
                raise exceptions.AurelionApiException("Unexpected datastructure from Aurelion")
            prop["value"] = value
            right_asset["properties"].append(prop)

        self.put_scene_assets([right_asset])
        return data

    def wait_not_busy(self) -> None:
        message_after = 10
        timeout = 60
        for t in range(timeout):
            state = self.get_aurelion_state()
            if not state["isBusy"]:
                break
            if t == message_after:
                _logger.warning("Aurelion Control still busy after {t} seconds. Waiting for up to {timeout} seconds")
            time.sleep(1)
        state = self.get_aurelion_state()
        if state["isBusy"]:
            raise exceptions.AurelonClientStuckBusy

    def _raise_error(self, response: "requests.Response") -> None:
        if (
            response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR
            and "Given value for" in response.text
            and "not in the allowed range" in response.text
        ):
            raise exceptions.AurelonPropertyOutOfRange(response.text)
        super()._raise_error(response)
