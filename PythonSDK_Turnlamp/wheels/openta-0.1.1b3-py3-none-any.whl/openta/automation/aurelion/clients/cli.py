import logging
import os
import pathlib
import subprocess
import time
from http import HTTPStatus

import requests

import openta.automation.aurelion.clients.exceptions
import openta.automation.installationmanager
from openta.automation.aurelion.clients import exceptions

_logger = logging.getLogger(__name__)


def _get_active_aur_installation() -> openta.automation.installationmanager.Installation:
    infos_from_im = openta.automation.installationmanager.get_product_dir(
        "AURELION Manager",
        skip_inactive=True,
    )
    if len(infos_from_im) == 0:
        raise openta.automation.aurelion.clients.exceptions.AurelionConfugurationError(
            "No active Aurelion installation found",
        )
    # drop unsupported versions (no activate deactivate)
    infos_from_im = [i for i in infos_from_im if i.version_as_touple > (25, 0, 0)]
    if len(infos_from_im) == 0:
        raise openta.automation.aurelion.clients.exceptions.AurelionConfugurationError(
            "No supported Aurelion installation found",
        )

    if len(infos_from_im) > 1:
        raise openta.automation.aurelion.clients.exceptions.AurelionConfugurationError(
            "Multiple Aurelion installations found, this block is incompartible",
        )

    return infos_from_im[0]


def _am_test_request(url: str) -> requests.Response:
    return requests.get(rf"{url}/scenarios", timeout=10)


def wait_am_finished_loading_project(
    url: str,
    projectpath: str | None = None,
    process: subprocess.Popen[bytes] | None = None,
) -> None:
    okay = False
    _logger.info("Waiting for Manager to initialize API")
    progress = 0
    for _ in range(0, 100, 1):
        if process is not None:
            code = process.poll()
            if code is not None:
                raise exceptions.AurelionApiException(
                    f"AurelionManager terminated immedtately after launcing. Code {code}",
                )
        try:
            r = _am_test_request(url)
            if projectpath is None:
                # not checking for an actual project, just for presence of
                # service
                okay = True
                _logger.info("Manager API available")
                break
            if r.status_code == HTTPStatus.OK:
                okay = True
                _logger.info(f"Aurelion Project {projectpath} opened")
                break
            if r.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.PRECONDITION_FAILED} and progress < 2:
                progress = max(progress, 2)
            time.sleep(1)
        except requests.exceptions.ConnectionError:
            time.sleep(1)
    if not okay:
        raise exceptions.AurelionApiException("Failed to connect to aurelion manager")
    time.sleep(10)


def launch_aurelion_manager(url: str) -> None:
    path = pathlib.Path(_get_active_aur_installation().path)

    working_dir = path / "Aurelionmanager" / "bin"
    exe_path = working_dir / "AURELIONManager.exe"
    try:
        _am_test_request(url)
        running = True
    except requests.exceptions.ConnectionError:
        running = False

    if not (running):
        e = dict(os.environ).copy()
        # We can't launch AUR with this variable set
        removed = [
            "DEBUGPY_RUNNING",
            "PYTEST_VERSION",
            "PYTEST_CURRENT_TEST",
            "PYDEVD_USE_FRAME_EVAL",
            "_OLD_VIRTUAL_PATH",
            "VIRTUAL_ENV",
            "TEST_RUN_PIPE",
            "VIRTUAL_ENV_PROMPT",
            "PROMPT",
            "ELECTRON_RUN_AS_NODE",
        ]

        for v in removed:
            if v in e:
                e.pop(v)
        # Remove all vs code environment variables
        for k in list(e.keys()):
            if k.startswith("VSCODE"):
                e.pop(k)

        process = subprocess.Popen([exe_path, "--disableSplash"], cwd=working_dir, env=e)  # noqa: S603
        wait_am_finished_loading_project(url, projectpath=None, process=process)
