import contextlib
import json as json_module
import typing


def get_by_name(lst: list[typing.Any], name: str) -> list[typing.Any] | dict[str, typing.Any]:
    filtered = [d for d in lst if d["name"] == name]
    if len(filtered) != 1:
        raise Exception("Filtering failed")
    return filtered[0]


def r_get_by_name(
    lst: list[typing.Any] | dict[str, typing.Any],
    names: list[str],
) -> list[typing.Any] | dict[str, typing.Any]:
    """
    Helper function to index Aurelion data structures.
    Instead of dictionaries, often lists are used which contain dictionaries.
    For each of the elements, there is a "name".
    """
    if len(names) == 0:
        return lst

    if isinstance(lst, list):
        lst = get_by_name(lst, names[0])
    elif isinstance(lst, dict):
        lst = lst[names[0]]
    return r_get_by_name(lst, names[1:])


def try_prettify_json(txt: str) -> str:
    """Helper function trying to fromat content. If it's not a json, input is not changed."""

    # don't care about exceptions, json just to format nice
    with contextlib.suppress(json_module.decoder.JSONDecodeError):
        txt = json_module.dumps(json_module.loads(txt), indent=3)
    return txt
