import contextlib
import os
import platform
import typing
import warnings

from openta.common import exceptions

# pyright: reportConstantRedefinition=false
if platform.system() == "Windows":
    try:
        import pywintypes
    except ImportError as err:
        _COM_ERROR = None
        warnings.warn(f"Failed to import `pywintypes`. ModelDesk automation support disabled. :: {err}", stacklevel=2)
    else:
        _COM_ERROR = pywintypes.com_error

    try:
        import win32com.client
    except ImportError as err:
        _DISPATCH = None
        warnings.warn(
            f"Failed to import `win32com.client`. ModelDesk automation support disabled. :: {err}",
            stacklevel=2,
        )
    else:
        _DISPATCH = win32com.client.Dispatch

else:
    _COM_ERROR = None
    _DISPATCH = None


class ModelDeskAutomationError(exceptions.AutomationError):
    """
    Specialized `AutomationError` fixed to `ModelDesk`.
    """

    def __init__(self, message: str, origin: Exception | None = None) -> None:
        super().__init__("ModelDesk", message, origin)


def get_application(prog_id: str | None = None) -> typing.Any:
    """
    Create and return a win32com client object dispatched to `ModelDesk.Application`.

    Returns:
        win32com COM object: The ModelDesk application object

    Raises:
        ModelDeskAutomationError: If any com errors occured
    """
    if prog_id not in [None, "ModelDesk.Application"]:
        # TODO
        raise NotImplementedError("prog_id not yet supported")

    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            return _DISPATCH("ModelDesk.Application")
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to dispatch ModelDesk.", origin=err) from err
    elif platform.system() != "Windows":
        raise ModelDeskAutomationError(
            f"ModelDesk automation not uspported on {platform.system()} systems. Cannot dispatch ModelDesk via COM.",
        )
    else:
        raise ModelDeskAutomationError(
            "Failed to dispatch ModelDesk. Required python modules `pywintypes` and `win32com` failed to import.",
        )


def open_experiment(project_path: str | os.PathLike[str], experiment_name: str | None = None) -> typing.Any:
    """
    Open the project specified by `project_path` and activates the a specified contained experiment.
    The active experiment is returned.

    The `experment_name` can be omitted or None, if only a single experiment exists in the project.
    In that case it is activated, otherwise a ModelDeskAutomationError is raised.

    Args:
        project_path (str): full path to the projects CDP file.
        experiment_name (str | None): The experiment's display name. The argument can be omitted.

    Returns:
        win23com COM object: The opened experiment, which is now active.

    Raises:
        ModelDeskAutomationError: If experiment is omitted and cannot be determined as described.
        ModelDeskAutomationError: If any com errors occured
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        filename = os.fspath(project_path)

        try:
            if app.ActiveProject is not None and os.path.realpath(filename) == os.path.realpath(
                app.ActiveProject.FullName,
            ):
                project = app.ActiveProject
            else:
                project = app.OpenProject(filename, "", 0)

            if experiment_name is not None:
                active_exp = project.ActiveExperiment
                if active_exp is not None and active_exp.Name == experiment_name:
                    return  # Experiment already opened
                project.Experiments[experiment_name].Activate(False)
            elif project.Experiments.Count == 1:
                if (
                    app.ActiveProject.ActiveExperiment is None
                    or app.ActiveProject.ActiveExperiment.Name != project.Experiments[0].Name
                ):
                    project.Experiments[0].Activate(False)
            else:
                msg = "Failed to open unspecified experiment from project '{filename}'."
                with contextlib.suppress(Exception):
                    msg += "The following experiments are available: {}".format(
                        ", ".join(
                            [f'"{e.Name}"' for e in project.Experiments],
                        )
                    )

                raise ModelDeskAutomationError(msg)
        except _COM_ERROR as err:
            msg = f"Failed to open '{experiment_name}' experiment from project '{filename}'."
            raise ModelDeskAutomationError(msg, origin=err) from err


def get_active_experiment() -> typing.Any:
    """
    Get the currently active experiment in ModelDesk if any.

    Returns:
        win32com COM object: The currently active ModelDesk experiment.

    Raises:
        ModelDeskAutomationError: If no experiment is currently active
        ModelDeskAutomationError: If any com errors occured
    """
    app = get_application()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if app.ActiveProject.ActiveExperiment is None:
                raise ModelDeskAutomationError(
                    "Failed to get Active Experiment. No Experiment is currently Active",
                )
            return app.ActiveProject.ActiveExperiment  # noqa: TRY300
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to get Active Experiment.", origin=err) from err
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ModelDeskAutomationError("Internal Error: Unexpected behaviour in `open_experiment`.")


def activate_road(road: str) -> None:
    active_experiment = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            active_experiment.ActivateRoad(road)
            # Dummy call to make sure road is open
            active_experiment.Road.Routes  # noqa: B018
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to activate road.", origin=err) from err


def activate_scenario(scenario: str) -> None:
    activate_experiment = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            activate_experiment.ActivateTrafficScenario(scenario)
            # Dummy call to make sure scenario is open
            activate_experiment.TrafficScenario.Fellows  # noqa: B018
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to activate traffic scenario.", origin=err) from err


def activate_parameter_set(parameterset: str) -> None:
    activate_experiment = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            activate_experiment.ActiveParameterSet(parameterset)
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to activate parameter set.", origin=err) from err


def download_all(save: bool = True) -> None:
    activate_experiment = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            if save:
                activate_experiment.TrafficScenario.Save()
                activate_experiment.Road.Save()
            activate_experiment.Download()
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to download experiment set.", origin=err) from err


def maneuver_start() -> None:
    activate_experiment = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            succ = activate_experiment.ManeuverControl.Start(False)  # noqa: FBT003
            if not (succ):
                raise ModelDeskAutomationError("Failed to start maneuver. Return was false")
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to start maneuver.", origin=err) from err


def maneuver_stop() -> None:
    activate_experiment = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            succ = activate_experiment.ManeuverControl.Stop()
            if not (succ):
                raise ModelDeskAutomationError("Failed to stop maneuver. Return was false")
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to stop maneuver.", origin=err) from err


def maneuver_reset() -> None:
    activate_experiment = get_active_experiment()
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            succ = activate_experiment.ManeuverControl.Reset()
            if not (succ):
                raise ModelDeskAutomationError("Failed to reset maneuver. Return was false")
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to reset maneuver.", origin=err) from err


def get_alias_list() -> list[str] | None:
    activate_experiment = get_active_experiment()
    aliases: list[str] = []
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            for group in activate_experiment.Aliases.Lists:
                for variable in group.Variables:
                    if variable.Name not in aliases:
                        aliases.append(variable.Name)
        except _COM_ERROR as err:
            raise ModelDeskAutomationError("Failed to get aliases.", origin=err) from err
        else:
            return aliases
    # If we get here, something went completely wrong. This is also to satisfy the linter
    raise ModelDeskAutomationError("Internal Error: Unexpected behaviour in `get_alias_list`.")


def set_alias(name: str, value: float) -> None:
    activate_experiment = get_active_experiment()
    found = False
    if _DISPATCH is not None and _COM_ERROR is not None:
        try:
            for group in activate_experiment.Aliases.Lists:
                for variable in group.Variables:
                    if variable.Name == name:
                        variable.SetValue(value)
                        found = True
            if not found:
                raise ModelDeskAutomationError(
                    f"Failed to set '{name}' Alias. Alias not found in active experiment.",
                )
        except _COM_ERROR as err:
            raise ModelDeskAutomationError(
                "Failed to set '{name}'  alias to value: {value}.",
                origin=err,
            ) from err
