import os
import pathlib
import platform
import sys
import typing
from dataclasses import dataclass

if platform.system() == "Windows":
    import clr

    # "new" way to import the installation manager API as explained in the current documentation.
    common_program_files_path = pathlib.Path(os.environ["COMMONPROGRAMFILES"])
    installation_manager_folder = common_program_files_path / "dSPACE" / "InstallationManager" / "bin"
    installation_manager_dll = installation_manager_folder / "dSPACE.InstallationManager.API.dll"
    if installation_manager_dll.exists():
        # True in case of recent installation manager versions like 24A
        sys.path.append(installation_manager_folder.resolve().as_posix())

        clr.AddReference(installation_manager_dll.resolve().as_posix())
    else:
        # Fallback for legacy versions.
        clr.AddReference(
            "dSPACE.InstallationManager.API, Version=2.0.0.0, Culture=neutral, PublicKeyToken=f9604847d8afbfbb",
        )
    import dSPACE.InstallationManager.API


@dataclass
class Installation:
    path: str
    version_as_string: str
    active: bool

    def __post_init__(self) -> None:
        self.version_as_touple = tuple(map(int, self.version_as_string.split(".")))


def get_product_dir(pronduct_name: str, *, skip_inactive: bool = True) -> list[Installation]:
    if platform.system() == "Windows":
        lst: list[Installation] = []
        info: typing.Any = dSPACE.InstallationManager.API.ConfigurationInfo()
        for installation in info.Installations:
            if skip_inactive and not installation.get_IsActive():
                continue
            for product in installation.Products:
                if product.DisplayName == pronduct_name:
                    lst.extend(
                        [
                            Installation(
                                path=str(installation.RootPath),
                                version_as_string=str(product.Version),
                                active=bool(installation.get_IsActive()),
                            ),
                        ],
                    )
        return lst
    raise NotImplementedError("Platform windows required")
