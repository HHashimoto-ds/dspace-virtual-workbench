"""
This module initializes platform-specific dependencies and sets up the environment for accessing MF4 data files
and .NET assemblies required for dSPACE XIL Mapping handler.

Platform-specific behavior:
- On Linux:
    - Loads the .NET Core runtime using pythonnet and clr_loader.
    - Sets the runtime configuration from a local 'pythonnet.runtimeconfig.json'.

After platform-specific setup, the module:
- Imports the 'clr' module to enable interoperability with .NET assemblies.
- Adds references to required .NET assemblies:
    - dSPACE.Common.XilMappingHandler.dll
    - dSPACE.Common.XilMappingHandlerInterfaces.dll
    - System.Collections

If the optional `evaluationlib` is installed:
- configures the `CmnDSMF4Access` binary path depending on platform
"""

import importlib.resources
import sys

# pyright: reportMissingTypeStubs=false
# pyright: reportUnknownMemberType=false
# pyright: reportAttributeAccessIssue=false

#
#   In case of linux, ensure that core clr is used by pythonnet
#
if sys.platform == "linux":
    import pythonnet

    pythonnet.load(
        "coreclr",
        runtime_config=importlib.resources.files("openta.data").joinpath("pythonnet.runtimeconfig.json"),
    )

#
#   import the clr namespace and add references to used assemblies
#
import clr

clr.AddReference(
    str(importlib.resources.files("openta.data.bin").joinpath("dSPACE.Common.XilMappingHandlerInterfaces.dll")),
)
clr.AddReference(str(importlib.resources.files("openta.data.bin").joinpath("dSPACE.Common.XilMappingHandler.dll")))

clr.AddReference("System.Collections")  # pyright: ignore[reportUnknownMemberType,reportAttributeAccessIssue]


#
#   If `evaluationlib` is installed
#   set the dll path according to the system
#
try:
    from evaluationlib.data.mf4access import _mf4access_api
except ImportError:
    pass
else:
    dll_name = "libCmnDSMF4AccessU.so" if sys.platform == "linux" else "CmnDSMF4AccessU.dll"
    _mf4access_api.DLL.set_dllpath(
        str(importlib.resources.files("evaluationlib.data").joinpath(dll_name)),
    )
