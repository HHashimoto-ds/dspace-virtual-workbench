import math
import os
import time
import typing
import warnings
import xml.etree.ElementTree as ET

import allure
import numpy as np
import numpy.typing as npt

from openta.common import exceptions
from openta.common.config.registry import Registry
from openta.common.exceptions import ScenarioConfigError, ScenarioError
from openta.common.scenario import AbstractScenario, ManeuverState, ScenarioParameter, ScenarioParametersList
from openta.common.variables import PortVariable
from openta.ports.abc import PortState
from openta.ports.xilapi_modelaccess import XilModelAccessPort

from .md_scenario_reader import MAPortConfigHandler, ModelDeskScenarioReader


class ModelDeskScenarioParameter(ScenarioParameter, PortVariable):
    """
    Objects of this class provide access to Parameters of a Scenario,
    as defined in the Scenario files.
    ModelDeskScenarioParameter are created by the `ModelDeskScenario` and exposed in its `vars` collection.
    Thus scenario parameters can be accessed similar as framework variables,
    which are defined in the XIL MApping and are available as `ta.vars`.
    """

    def __init__(self, identifier: str, port_id: str, dtype: npt.DTypeLike) -> None:
        super().__init__(identifier, port_id, dtype)

    @property
    def description(self) -> str:
        raise NotImplementedError("ModelDeskScenarioParameter.description property.")

    @property
    def value(self) -> np.generic:
        return Registry().get_port(self._port_id).read(self)

    @value.setter
    def value(self, value: np.generic | float | bool | str) -> None:
        """
        Read/Write access of the named ScenarioParameter as plain value.
        """
        with allure.step(f"{self} = {value}"):
            return Registry().get_port(self._port_id).write(self, value)

    def __str__(self) -> str:
        return self.id

    def __repr__(self) -> str:
        return str(self)


class AsmScenario(AbstractScenario):
    """
    Scenario and maneuver control for ModelDesk Scenarios.
    """

    _MANEUVER_START = "ManeuverStart"
    """FrameworkVariable name, which maps to port specific testbench identifier to start the maneuver."""

    _MANEUVER_STOP = "ManeuverStop"
    """FrameworkVariable name, which maps to port specific testbench identifier to stop the maneuver."""

    _MANEUVER_RESET = "Reset"
    """FrameworkVariable name, which maps to port specific testbench identifier to reset the maneuver."""

    _MANEUVER_STATE = "ManeuverState"
    """FrameworkVariable name, which maps to port specific testbench identifier to read the maneuver state."""

    def __init__(self, scenario: str | os.PathLike[str], **kwargs: typing.Any) -> None:
        reg = Registry()
        self._scenario_name = scenario
        self._road_name = kwargs.get("road")

        self._port_id = self._determine_port_id()
        self._port = reg.get_port(self._port_id)

        self._maportconfig = MAPortConfigHandler(self._port_id)
        self._pool_directory = self._maportconfig.get_pool_directory()

        # this is currently unused, because the model pathes in `EnvironmentPathes.xml`
        # lack the part application if, in case of MP systems.
        # Thus we consume the ModelPathes for scenario and maneuver control from XIL API Mapping
        self._environment_paths = self._built_environment_path_mapping()

        try:
            # Currently we expect the framework labels 'ManeuverStart', 'ManeuverStop', 'Reset' and 'ManeuverState'
            # to exist in XIL mapping
            self._maneuver_start = reg.get_port_variable(self._MANEUVER_START)
            self._maneuver_stop = reg.get_port_variable(self._MANEUVER_STOP)
            self._maneuver_reset = reg.get_port_variable(self._MANEUVER_RESET)
            self._maneuver_state = reg.get_port_variable(self._MANEUVER_STATE)

            # There was also the idea to consume them from `EnvironmentPaths.xml` directly,
            # but lead to error in vase of MP systems, because they lack the part application name.
            # The following might also be benefitial, but is skipped for now to be explicit.
            # try:
            #    self._maneuver_state = reg.get_port_variable(self._MANEUVER_STATE)
            # except:
            #    self._maneuver_state = self._environment_paths[f"MDLDManCtrl_{self._MANEUVER_STATE}"]
        except Exception as err:
            raise ScenarioError(
                f"Unable to create `ModelDeskScenario`. For controlling the maneuver the following framework labels must exist in XIL Mapping: 'ManeuverStart', 'ManeuverStop', 'Reset', 'ManeuverState'. :: {err}",
            ) from err

        self._alias_mapping = self._built_alias_mapping()

    def download(self, **kwargs: typing.Any) -> None:
        """
        Download specified ModelDesk traffic scenario and road by determined dSPACE MAPort.

        For the dSPACE MAPort,
        the MAPort config xml file is rewritten with changes to scenario and road to a temporary file.
        The port is stopped and disconnected.
        The port is connected again, but with the temporary MAPort config file.
        """
        with allure.step(f"Load '{self._scenario_name}' scenario"):
            # rewrite current MAPort config xml file with specified scenario and road
            # into temp folder.
            temp_file = self._maportconfig.create_temporary(self._scenario_name, self._road_name)

            if self._port.state == PortState.STARTED:
                self._port.stop()
            if self._port.state >= PortState.CONNECTED:
                self._port.disconnect()

            # and configure the port (Do not force config)
            self._port.connect(port_config_file=temp_file.as_posix(), ForceConfig=False)
            self._port.start()
        if kwargs:
            with allure.step("Apply scenario parameter"):
                self.apply_parameters(parameters=kwargs)

    def start(self) -> None:
        """
        start the maneuver
        """
        with allure.step("Start maneuver"):
            # wait if currently initializing
            while self.maneuver_state == ManeuverState.INIT:
                time.sleep(0.01)

            # STOP the maneuver
            self._port.write(self._maneuver_stop, 0)
            time.sleep(0.1)
            self._port.write(self._maneuver_stop, 1)
            time.sleep(0.1)
            while self.maneuver_state == ManeuverState.STOPPING:
                time.sleep(0.01)
            self._port.write(self._maneuver_stop, 0)

            # RESET the maneuver
            self._port.write(self._maneuver_reset, 0)
            time.sleep(0.1)
            self._port.write(self._maneuver_reset, 1)
            time.sleep(0.1)
            self._port.write(self._maneuver_reset, 0)

            # Start Maneuver, It starts if posedge is encountered
            # port.write(self._environment_paths[self._MANEUVER_STOP], 0)
            self._port.write(self._maneuver_start, 0)
            time.sleep(0.1)
            self._port.write(self._maneuver_start, 1)
            time.sleep(0.1)
            self._port.write(self._maneuver_start, 0)

    def stop(self) -> None:
        """
        stop the maneuver
        """
        with allure.step("Stop maneuver"):
            # wait if currently initializing
            while self.maneuver_state == ManeuverState.INIT:
                time.sleep(0.01)

            # STOP the maneuver
            self._port.write(self._maneuver_stop, 0)
            time.sleep(0.1)
            self._port.write(self._maneuver_stop, 1)
            time.sleep(0.1)
            while self.maneuver_state == ManeuverState.STOPPING:
                time.sleep(0.01)
            self._port.write(self._maneuver_stop, 0)

    def reset(self) -> None:
        """
        reset the maneuver
        """
        with allure.step("Reset maneuver"):
            # wait if currently initializing
            while self.maneuver_state == ManeuverState.INIT:
                time.sleep(0.01)

            # STOP the maneuver
            self._port.write(self._maneuver_stop, 0)
            time.sleep(0.1)
            self._port.write(self._maneuver_stop, 1)
            time.sleep(0.1)
            while self.maneuver_state == ManeuverState.STOPPING:
                time.sleep(0.01)
            self._port.write(self._maneuver_stop, 0)

            # RESET the maneuver
            self._port.write(self._maneuver_reset, 0)
            time.sleep(0.1)
            self._port.write(self._maneuver_reset, 1)
            time.sleep(0.1)
            self._port.write(self._maneuver_reset, 0)

    def wait_for_maneuver_finished(self, timeout: float | None = None) -> None:
        with allure.step("Wait for maneuver finished"):
            endtime = time.time() + timeout if timeout is not None else math.inf
            while self.maneuver_state <= ManeuverState.RUN:
                if time.time() > endtime:
                    raise ScenarioError(
                        f"Timeout of {timeout} seconds exceeded while waiting for the maneuver to finish",
                    )

    def wait_for_maneuver_state(self, state: ManeuverState, timeout: float | None = None) -> None:
        """
        wait for a specific maneuver state.
        An optional timeout in seconds of host time can be defined.
        If that timeout is exceeded a ScenarioError is raised.

        Args:
            state (ManeuverState): The desired maneuver state to wait for.
            timeout (float|None): Optional timeout. The timeout is resolved in seconds of test exection time on the host.

        Raises:
            ScenarioError: If timeout is exceeded
        """
        endtime = time.time() + timeout if timeout is not None else math.inf
        while self.maneuver_state == state:
            if time.time() > endtime:
                raise ScenarioError(
                    f"Timeout of {timeout} seconds exceeded while waiting for the maneuver state {state}.",
                )

    @property
    def maneuver_state(self) -> ManeuverState:
        """
        determine the maneuver state
        """
        value = self._port.read(self._maneuver_state)
        return ManeuverState(int(value))

    @property
    def vars(self) -> ScenarioParametersList:
        """
        Access the collection of aliases defined in current Scenario.
        Aliases are not devided into Maneuver and Traffic aliases, but
        all aliases are available directly in the returned collection.
        """
        return self._alias_mapping

    def _built_alias_mapping(self) -> ScenarioParametersList:
        """
        Read in the specified Scenario file and determine all
        maneuver and traffic aliases from that Scenario file.

        This method builds and returns a ready to use `ScenarioParametersList`.
        The created `ScenarioParameters` are bound to current determined port id and assumed to be of floating point type.
        """
        reader = ModelDeskScenarioReader(self._pool_directory, self._scenario_name)
        reader.load()

        # Build collection of ScenarioParameters.
        # The model path for dSPACE MAPort Scenario API is based on location in scenario: traffic or maneuver alias.
        return ScenarioParametersList(
            [
                ModelDeskScenarioParameter(f"Scenario://Traffic/{alias}", self._port_id, np.float64)
                for alias in reader.get_traffic_aliases()
            ]
            + [
                ModelDeskScenarioParameter(f"Scenario://Maneuver/{alias}", self._port_id, np.float64)
                for alias in reader.get_maneuver_aliases()
            ],
        )

    def _determine_port_id(self) -> str:
        """
        Find a suitable dSPACE Model Access port in Registry,
        and return its Name.
        """
        reg = Registry()
        maports = [p for p in reg.get_ports() if isinstance(p, XilModelAccessPort)]

        if not maports:
            raise ScenarioConfigError(
                "Cannot initialize ModelDesk scenario. At least one dSPACE MAPort has to be configured in test environment config yaml or XIL API framework config xml file.",
            )
        if len(maports) > 1:
            warnings.warn(
                f"On configuration of ModelDesk scenario more than one defined dSPACE MAPort are found. The first will be further used for scenario access: '{maports[0].name}'.",
                stacklevel=2,
            )
        return maports[0].name

    def _built_environment_path_mapping(self) -> dict[str, PortVariable]:
        """
        Read the `EnvironmentPaths` xml ModelDesk file,
        which defines MAPort model pathes for various ModelDesk actions, like starting and stopping the maneuver.
        That file is determined from the associated dSPACE MAPort config file.

        The functions returns a mapping, which maps ModelDesk ParameterNames to their model pathes respectively.
        The returned mapping is later used for controlling maneuver.
        The `ModelDeskScenario` class defines class constants like `_MANEUVER_START`, which is a key in the returned mapping.
        and `ModelDeskScenario.start()` looks up that model path and writes to it via the determined dSPACE MAPort.
        """
        env_path_file = self._maportconfig.get_environment_paths_file()
        env_root = None
        try:
            env_root = ET.parse(env_path_file).getroot()  # noqa: S314
        except Exception as err:
            raise ScenarioConfigError(
                f"Failed to load or parse dSPACE ModelDesk EnvironmentPaths xml file: '{env_path_file}'. :: {exceptions.format_exc(err)}",
            ) from err

        return {
            str(env_path.get("ParameterName")): PortVariable(str(env_path.text), self._port_id, np.float64)
            for env_path in env_root.iterfind(
                ".//ns:EnvironmentPath",
                {"ns": "http://www.dspace.com/XMLSchema/ScenarioAccess/EnvironmentPaths/V10"},
            )
        }
