import collections.abc
import math
import os
import time
import typing
import warnings
from typing import TypeVar

import allure

from openta.automation import modeldesk
from openta.common.config.registry import Registry
from openta.common.exceptions import ScenarioConfigError, ScenarioError
from openta.common.scenario import AbstractScenario, ManeuverState, ScenarioParametersList
from openta.ports.abc import AbstractPort
from openta.ports.aurelion import AurelionPort
from openta.ports.modeldesk import ModelDeskPort
from openta.ports.xilapi_modelaccess import XilModelAccessPort


class AsmModelDeskScenario(AbstractScenario):
    """
    Scenario and maneuver control for ModelDesk Scenarios.
    """

    def __init__(self, scenario: str | os.PathLike[str], **kwargs: typing.Any) -> None:
        self._scenario_name = scenario
        self._road_name = kwargs.get("road")
        self._mdport: ModelDeskPort = self._port_by_type(ModelDeskPort)

    def download(self, **kwargs) -> None:
        """
        Download specified ModelDesk traffic scenario and road by determined dSPACE MAPort.

        For the dSPACE MAPort,
        the MAPort config xml file is rewritten with changes to scenario and road to a temporary file.
        The port is stopped and disconnected.
        The port is connected again, but with the temporary MAPort config file.
        """
        with allure.step(f"Load '{self._scenario_name}' scenario"):
            # rewrite current MAPort config xml file with specified scenario and road
            # into temp folder.
            if isinstance(self._road_name, str):
                modeldesk.activate_road(self._road_name)
            else:
                raise NotImplementedError("Can not load road from file")
            if isinstance(self._scenario_name, str):
                modeldesk.activate_scenario(self._scenario_name)
            else:
                raise NotImplementedError("Can not load road from file")

        if kwargs:
            with allure.step("Apply scenario parameter"):
                self.apply_parameters(parameters=kwargs)

        modeldesk.download_all()

    def start(self) -> None:
        """
        start the maneuver
        """
        modeldesk.maneuver_start()

    def stop(self) -> None:
        """
        stop the maneuver
        """
        modeldesk.maneuver_stop()

    def reset(self) -> None:
        """
        reset the maneuver
        """
        modeldesk.maneuver_stop()
        modeldesk.maneuver_reset()

    @property
    def vars(self) -> ScenarioParametersList:
        raise NotImplementedError("Not supported by this type of scenarios")

    def wait_for_maneuver_finished(self, timeout: float | None = None) -> None:
        with allure.step("Wait for maneuver finished"):
            endtime = time.time() + timeout if timeout is not None else math.inf
            while self.maneuver_state <= ManeuverState.RUN:
                if time.time() > endtime:
                    raise ScenarioError(
                        f"Timeout of {timeout} seconds exceeded while waiting for the maneuver to finish",
                    )

    def wait_for_maneuver_state(self, state: ManeuverState, timeout: float | None = None) -> None:
        """
        wait for a specific maneuver state.
        An optional timeout in seconds of host time can be defined.
        If that timeout is exceeded a ScenarioError is raised.

        Args:
            state (ManeuverState): The desired maneuver state to wait for.
            timeout (float|None): Optional timeout. The timeout is resolved in seconds of test exection time on the host.

        Raises:
            ScenarioError: If timeout is exceeded
        """
        endtime = time.time() + timeout if timeout is not None else math.inf
        while self.maneuver_state == state:
            if time.time() > endtime:
                raise ScenarioError(
                    f"Timeout of {timeout} seconds exceeded while waiting for the maneuver state {state}.",
                )

    @property
    def maneuver_state(self) -> ManeuverState:
        """
        determine the maneuver state
        """
        value = modeldesk.get_active_experiment().ManeuverControl.ManeuverState
        return ManeuverState(int(value))

    def apply_parameters(self, parameters: dict[str, typing.Any] | os.PathLike[str]) -> None:
        """
        Apply all values from given `parameters` dict to Scenario parameters.
        The key has to be the parameters name and the coresponding value is the value to set for that key.
        """
        if isinstance(parameters, collections.abc.Mapping):
            for name, value in parameters.items():
                modeldesk.set_alias(name, value)
        else:
            raise NotImplementedError("loading and applying scenario parameters from file s not yet supported")

    def _determine_port_id(self) -> str:
        """
        Find a suitable dSPACE Model Access port in Registry,
        and return its Name.
        """
        reg = Registry()
        maports = [p for p in reg.get_ports() if isinstance(p, XilModelAccessPort)]

        if not maports:
            raise ScenarioConfigError(
                "Cannot initialize ModelDesk scenario. At least one dSPACE MAPort has to be configured in test environment config yaml or XIL API framework config xml file.",
            )
        if len(maports) > 1:
            warnings.warn(
                f"On configuration of ModelDesk scenario more than one defined dSPACE MAPort are found. The first will be further used for scenario access: '{maports[0].name}'.",
                stacklevel=2,
            )
        return maports[0].name

    Port = TypeVar("Port", bound=AbstractPort)

    def _port_by_type(self, porttype: type[Port]) -> Port:
        """
        Find a suitable dSPACE Model Access port in Registry,
        and return its Name.
        """
        reg = Registry()
        modeldeskport = [p for p in reg.get_ports() if isinstance(p, porttype)]

        if not modeldeskport:
            raise ScenarioConfigError(
                "Cannot initialize ModelDesk scenario. At least one dSPACE MAPort has to be configured in test environment config yaml or XIL API framework config xml file.",
            )
        if len(modeldeskport) > 1:
            warnings.warn(
                f"On configuration of ModelDesk scenario more than one defined dSPACE MAPort are found. The first will be further used for scenario access: '{modeldeskport[0].name}'.",
                stacklevel=2,
            )
        return modeldeskport[0]


class AsmModelDeskAurelionScenario(AsmModelDeskScenario):
    def __init__(self, scenario: str | os.PathLike[str], **kwargs) -> None:
        super().__init__(scenario, **kwargs)
        self._aurport: AurelionPort = self._port_by_type(AurelionPort)

    def download(self, **kwargs):
        """First downloads via ModelDesk. Then the 3D Scene is synchronized.
        It is checked if there is an AURELION Scenario matching the ModelDesk Road Name.
        In case a matching Scenario is found, it is used. Oterwise the road scene generator is used."""
        super().download(**kwargs)
        aur_scenario = self._determine_3d_scenario()
        self._aurport.synchronize_scenario(aur_scenario)

    def _determine_3d_scenario(self) -> str:
        aur_scenario = None
        road = self._road_name
        for aur_road in self._aurport.origin.get_scenarios():
            if aur_road["name"] == road:
                aur_scenario = aur_road["name"]
                break
        # Use RSG as Fallback if matching scenario is not found in AUR.
        if aur_scenario is None:
            aur_scenario = self._aurport.origin.get_rsg_scenario_name()
        return aur_scenario
