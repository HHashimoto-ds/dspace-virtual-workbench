import os
import typing

from openta.common.config.registry import Registry
from openta.common.scenario import AbstractScenario, ManeuverState, ScenarioParametersList
from openta.ports.aurelion import AurelionPort
from openta.ports.modeldesk import ModelDeskPort

from .modeldesk_scenario import AsmModelDeskAurelionScenario, AsmModelDeskScenario
from .scenario_api import AsmScenario


class Scenario(AbstractScenario):
    """
    The Scenario object offers features for downloading, parameterizing and the controlling the scenario/maneuver.
    To start, the object is created with a appropriate reference to a scenario.

    Depending on the concrete scenario, further arguments may be valid.
    These can be defined as keyword arguments and passed to the `__init__` of created Scenario as keyword arguments.

    NOTE, that currently only ASM Traffic scenarios using ModelDesk or the Scenario API are supported.
    OpenX is currently not supported.

    ```python
    sc = Scenario("NCAP_AEB_CCRb")
    sc.download(v_EGO=80)
    st.start_maneuver()
    ```
    """

    def __new__(cls, scenario: str | os.PathLike[str], **kwargs: typing.Any) -> AbstractScenario:
        """Returns a suitable Scenario class based on the currently configured ports"""
        has_aur = len([e for e in Registry().get_ports() if isinstance(e, AurelionPort)]) > 0
        has_mod = len([e for e in Registry().get_ports() if isinstance(e, ModelDeskPort)]) > 0
        if has_aur:
            return AsmModelDeskAurelionScenario(scenario, **kwargs)
        if has_mod:
            return AsmModelDeskScenario(scenario, **kwargs)

        return AsmScenario(scenario, **kwargs)

    # The following "implementations" of the abstract methods,
    # are needed in order to instantiate this `Scenario`` class.
    # However due to the __new__ method concrete subclasses are instantiated,
    # such that these methods are overwritten by concrete implementations.

    def download(self, **kwargs) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def start(self) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def stop(self) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def reset(self) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def wait_for_maneuver_state(self, state: ManeuverState, timeout: float | None = None) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    def wait_for_maneuver_finished(self, timeout: float | None = None) -> None:
        raise NotImplementedError("Internal Error. This should have never been called.")

    @property
    def maneuver_state(self) -> ManeuverState:
        raise NotImplementedError("Internal Error. This should have never been called.")

    @property
    def vars(self) -> ScenarioParametersList:
        raise NotImplementedError("Internal Error. This should have never been called.")
