import typing

import allure

from openta.common.config.registry import Registry

from .variables_base import VariableDescription

if typing.TYPE_CHECKING:  # pragma: no cover
    import numpy as np
    import numpy.typing as npt


class FrameworkVariable(VariableDescription):
    """
    A FrameworkVariable is a global alias with a unique id.
    It maps is mapped to a corresponding PortVariable,
    which allows uniform acccess of Frameworkvariable while Environments may change.
    """

    def __init__(
        self,
        identifier: str,
        dtype: "npt.DTypeLike",
    ) -> None:
        super().__init__(identifier, dtype)

    @property
    def description(self) -> str:
        return "<description>"

    @property
    def value(self) -> "np.generic":
        port_var = Registry().get_port_variable(self)
        return Registry().get_port(port_var.port_id).read(port_var)

    @value.setter
    def value(self, value: typing.Union["np.generic", float, bool, str]) -> None:
        """
        Read/Write access of the named FrameworkVariable as plain value.
        """
        with allure.step(f"{self} = {value}"):
            port_var = Registry().get_port_variable(self)
            return Registry().get_port(port_var.port_id).write(port_var, value)

    def __str__(self) -> str:
        return self.id

    def __repr__(self) -> str:
        return f"FrameworkVariable('{self.id}', {self.dtype})"


class PortVariable(VariableDescription):
    """
    Common abstract definition of a port specific variable.
    It consist of a
    - `id`: port specific identifier, which is only meaningful for a specific port, this variable is used to access
    - `dtype`: which is the dtype definitio from numpy
    """

    def __init__(
        self,
        identifier: str,
        port_id: str,
        dtype: "npt.DTypeLike",
    ) -> None:
        super().__init__(identifier, dtype)
        self._port_id = port_id

    @property
    def port_id(self) -> str:
        """
        The port identifier of current PortVariable
        """
        return self._port_id

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PortVariable):
            return self.id == other.id and self.port_id == other.port_id and self.dtype == other.dtype
        return False

    def __hash__(self) -> int:
        return hash((self.id, self.port_id, self._dtype))

    def __repr__(self) -> str:
        return f"PortVariable('{self.id}', '{self.port_id}', {self.dtype})"
