import importlib.util
import struct
import traceback
import typing

# import pywintypes, Note only available for windows
# pyright: reportConstantRedefinition=false
if importlib.util.find_spec("pywintypes"):
    from pywintypes import com_error as COM_ERROR
else:
    COM_ERROR = None


class AutomationError(Exception):
    """
    Raised when automation of external tools results in an error.
    The associated error message is computed from constructor arguments
    aims to be comprehensive and readable.

    Attributes:
        tool (str): Name of the automated application or tool, which runs into issues.
        origin (str): Formatted origin exception, if any.
            In case of COM errors, the origin text is formatted for improved readability.
    """

    def __init__(self, tool: str, message: str, origin: Exception | None = None) -> None:
        """
        Args:
            tool (str): Name of the automated application or tool. Available as `tool` property.
            origin (Exception, optional): The origin exception. This is used for formatting purposes only and exception object is _not_ stored.
        """
        self.tool = tool

        msg = f"[{tool}]: {message}"

        if origin is not None:
            if COM_ERROR is not None and isinstance(origin, COM_ERROR):
                self.origin = format_com_error(origin)
            else:
                self.origin = format_exc(origin)
            msg += " :: " + self.origin

        # SUPER INIT
        super().__init__(msg)


class ConfigurationError(Exception):
    pass


class RegistryError(Exception):
    pass


class AlreadyExistsError(RegistryError):
    """
    An item of given `kind` cannot be registered with given `key`,
    because another item is already registered with that key.
    """

    def __init__(self, key: str, kind: str, existing: object, new: object) -> None:
        super().__init__(f"Cannot register given {kind} as '{key}'. An item with that associated key already exists.")
        self.key = key
        self.kind = kind
        self.existing_repr = repr(existing)
        self.new_repr = repr(new)


class NotFoundError(RegistryError):
    """
    An item of `kind` cannot be found in registry.
    """

    def __init__(self, key: str, kind: str) -> None:
        super().__init__(f"A {kind} item with key '{key}' is not registered.")
        self.key = key
        self.kind = kind


class PortError(Exception):
    pass


class PortTypeError(PortError):
    pass


class PortConfigError(PortError):
    pass


class PortStateError(PortError):
    pass


class CaptureError(Exception):
    pass


class CaptureStateError(CaptureError):
    pass


class ScenarioError(Exception):
    pass


class ScenarioConfigError(ScenarioError):
    pass


class AsmVariableError(Exception):
    pass


class XilMappingError(Exception):
    pass


def format_exc(exc: Exception) -> str:
    """
    Return formatted Exception without traceback.
    Currently this is a shortcut for `("\u2424".join(traceback.format_exception_only(exc))).strip()`,
    such that the string consists of a single line.
    Note, that the unicode codepoint 2424 is the `SYMBOL FOR NEWLINE` (␤)

    Args:
        exc (Exception): the exception to format
    Returns:
        str: short formatted message based on exception
    """
    return ("\u2424".join(traceback.format_exception_only(exc))).strip()


def _get_hresult_as_hex(hr: int) -> str:
    """
    Get the COM HResult as formatted hey number, which is common style for such COM error numbers.

    Note the integer number provided by pywintypes results in a negative number in python,
    which is not the desired representation.

    Args:
        hr (int): the integer number retrieved from the pywintypes.com_error

    Returns:
        str: the correct HResult number formatted as hex
    """
    # We need to interpret the negative number as a 32 bit signed integer,
    # then interpret that as an unsigned integer:
    return "0x{:x}".format(struct.unpack("L", struct.pack("l", hr))[0])


def format_com_error(error: typing.Any) -> str:
    """
    Get formatted string from `pywintypoes.com_error`

    The returned string consists of three parts:
    - hresult number, formatted ashex
    - the source of the error if provided
    - a description of the error provided by the source

    Args:
        error (pywintypes.com_error): the error to format.

    Returns:
        str: a formmatted string representation of the given error
    """
    if COM_ERROR is not None and isinstance(error, COM_ERROR):
        try:
            hr, ename, details, _ = error.args
        except ValueError:
            return str(error)
    else:
        return str(error)

    try:
        if details:
            # entpacke das tupel
            (_, source, description, _, _, errorhr) = details

            message = f"COM Error {_get_hresult_as_hex(errorhr)}"

            # if Source is provided by ErrorInfo, add it at first to the Message
            if source is not None:
                message += f": {source}"

            # and if provided description
            if isinstance(description, str):
                description = description.rstrip()
                message += ": {}".format(" ".join([line.strip() for line in description.split("\n")]))
            return message
        return f"{_get_hresult_as_hex(hr)}: {ename}"
    except Exception:  # noqa: BLE001
        return str(error)
