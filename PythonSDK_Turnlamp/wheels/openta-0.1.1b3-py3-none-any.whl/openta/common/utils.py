"""
Description: This module implements helper function to handle ASAM Global Expression Syntax.
"""

import re

GES_FUNCTION_IDENTIFIER = frozenset(
    (
        "sin",
        "cos",
        "tan",
        "asin",
        "acos",
        "atan",
        "sinh",
        "cosh",
        "tanh",
        "log",
        "log10",
        "exp",
        "pow",
        "sqrt",
        "abs",
        "sgn",
        "round",
        "ceil",
        "floor",
        "min",
        "max",
        "posedge",
        "negedge",
        "strictposedge",
        "strictnegedge",
        "changed",
        "hwtrigger",
        "mantrigger",
        "changedneg",
        "changedpos",
    ),
)

CONTROLDESK_TRIGGER_OPERATORS = frozenset(("BIT", "HIGHLOW", "POS", "NEG", "EDGE", "CHANGE"))

# Regular Exporession that matches Identifiers, consist only of
# alphanumeric characters but do not start with digit
IDENTIFIER_REGEX = re.compile("([^\\d\\W]\\w*)", re.UNICODE | re.MULTILINE)


def get_identifier_from_ges_condition(condition: str) -> list[str]:
    """
    Extract all identifiers from given `condition` and
    filter them, such that no ASAM GES Expression function names are included.
    Return the resulting identifiers as list of strings.
    """
    return [link for link in re.findall(IDENTIFIER_REGEX, condition) if link not in GES_FUNCTION_IDENTIFIER]


def get_identifier_from_controldesk_trigger_rule(condition: str) -> list[str]:
    """
    Extract all identifiers from given `condition` and
    filter them, such that no ControlDesk Trigger operator names are included.
    Return the resulting identifiers as list of strings.

    **ATTENTION**,
    ControlDesk Trigger operators may also contain whitespaces like "POS EDGE",
    and the current implementation returns all identifiers which are not partly! these operators.
    That means a signal named "EDGE" may not be returned, if that would be a valid controldesk trigger.
    """
    return [link for link in re.findall(IDENTIFIER_REGEX, condition) if link not in CONTROLDESK_TRIGGER_OPERATORS]
