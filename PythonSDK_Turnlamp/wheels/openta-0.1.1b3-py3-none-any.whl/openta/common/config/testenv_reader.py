import json
import logging
import os
import pathlib
import typing
from importlib import resources

import yaml
from jsonschema import ValidationError, validate

from openta.common.config.plugins import PluginProvider
from openta.common.config.registry import Registry
from openta.common.config.xil_mapping_generator import XilMappingGenerator
from openta.common.config.xil_mapping_reader import XilMappingReader
from openta.common.exceptions import ConfigurationError
from openta.ports.abc import PortState
from openta.ports.aurelion import AurelionPort
from openta.ports.controldesk import ControlDeskPort
from openta.ports.modeldesk import ModelDeskPort
from openta.ports.xilapi_dspace_ecu import DsEcuPort
from openta.ports.xilapi_modelaccess import XilModelAccessPort

_logger = logging.getLogger(__name__)


class TestEnvironmentConfigReader:
    __test__ = False  # Prevent pytest from collecting this as a test class

    def __init__(self, config_file_name: os.PathLike[str]) -> None:
        self._filename = os.fspath(config_file_name)
        self._configpath = pathlib.Path(self._filename).parent
        if not self._configpath.is_absolute():
            self._configpath = pathlib.Path.cwd() / self._configpath

    def load(self) -> typing.Any:
        # load the schema from resource file
        with resources.files("openta.data").joinpath("testenv_schema.json").open() as schema_file:
            schema = json.load(schema_file)

        # Load YAML file
        _logger.info("Load test environment configuration: '%s'", self._filename)
        with open(self._filename) as yaml_file:
            yaml_data = yaml.safe_load(yaml_file)

        # Validate YAML data against the schema
        try:
            validate(instance=yaml_data, schema=schema)
        except ValidationError as err:
            raise ConfigurationError(
                "Failed to load provided openta test environment configuration file: {self._filename}",
            ) from err

        return yaml_data

    def add_to_registry(self) -> None:
        config = self.load()

        if "plugins" in config:
            _logger.debug("Analyzing plugins ...")
            self._add_plugins(config["plugins"])
        else:
            _logger.debug("no plugins specified")

        if "ports" in config:
            _logger.info("Analyze ports ...")
            self._add_ports(config["ports"])
        else:
            _logger.warning("no ports specified")

        if "mappings" in config:
            _logger.info("Analyze mappings ...")
            self._add_mappings(config["mappings"])
        else:
            _logger.warning("no mappings specified")

    def _add_ports(self, port_specs: typing.Any) -> None:
        for port_spec in port_specs:
            ptype: str = port_spec["type"]
            name: str = port_spec["name"]
            order: int = port_spec["order"]
            target_state = self._get_target_state(port_spec)
            config = self._get_flattened_port_config_with_resolved_files(port_spec)

            _logger.info("Register '%s' %s port.", name, ptype)

            if ptype == "XIL API MAPort":
                port_type = XilModelAccessPort
            elif ptype == "XIL API dSPACE ECUPort":
                port_type = DsEcuPort
            elif ptype == "ControlDesk":
                port_type = ControlDeskPort
            elif ptype == "ModelDesk":
                port_type = ModelDeskPort
            elif ptype == "AURELION":
                port_type = AurelionPort
            elif ptype == "Custom":
                port_type = PluginProvider().get_port_type(port_spec["class_name"])
            else:
                raise ConfigurationError(f"""Unable to understand port type {port_spec["type"]}""")

            # Instantiate the determined Port class with configuration properties
            port = port_type(name, order, target_state, config)
            Registry().add_port(port)

    def _add_mappings(self, mapping_specs: typing.Any) -> None:
        for mapping_spec in mapping_specs:
            _logger.info("Process %s file '%s' .", mapping_spec["type"], mapping_spec["file"])
            if mapping_spec["type"] == "XIL API Mapping":
                reader = XilMappingReader(self._resolve_filename(mapping_spec["file"]))
                reader.add_to_registry()
            elif mapping_spec["type"] == "ASM":
                mapping_generator = XilMappingGenerator(self._resolve_filename(mapping_spec["file"]))
                mapping_filename = mapping_generator.generate()
                reader = XilMappingReader(mapping_filename)
                reader.add_to_registry()
            else:
                _logger.warning("Skip unknown mapping file: %s", repr(mapping_spec))

    def _add_plugins(self, plugin_specs: typing.Any) -> None:
        for plugin_spec in plugin_specs:
            PluginProvider().load_plugins_from_folder(self._resolve_filename(plugin_spec["folder"]))

    def _get_target_state(self, port_spec: dict[str, typing.Any]) -> PortState:
        """
        get the `target_state` property from yaml port_spec and convert it to PortState enum.
        """
        target_state = port_spec["target_state"].upper()
        match target_state:
            case "RELEASED":
                return PortState.RELEASED
            case "CREATED":
                return PortState.CREATED
            case "CONNECTED":
                return PortState.CONNECTED
            case "STARTED":
                return PortState.STARTED
            case _:
                raise ConfigurationError(f'Invalid target_state "{target_state}" for port "{port_spec["name"]}".')

    def _resolve_filename(self, filename: str) -> str:
        """
        resolve the specified filename relative to the yaml directory if not absolute.

        Returns:
            str: absolute path to filename resolved relative to config yaml folder.
        """
        path = pathlib.Path(filename)
        if not path.is_absolute():
            return (self._configpath / path).resolve().as_posix()
        return filename

    def _get_flattened_port_config_with_resolved_files(self, port_spec: dict[str, typing.Any]) -> dict[str, typing.Any]:
        """
        Get the `config` dict from yaml port_spec, if any.

        The specified dict is flattened, meaning that nested dictionaries are combined into one flat dictionary,
        and the keys are joined by dot, so the resulting key uses dot notation to adress originally nested dictionaries.

        All contained properties ending with "file" their value is resolved as filename relative to the yaml file.
        If an absolute file is specified it is unchanged.
        """

        def flatten_dict(d: dict[str, typing.Any], parent_key: str = "") -> dict[str, typing.Any]:
            flattened: dict[str, typing.Any] = {}
            for key, value in d.items():
                new_key = f"{parent_key}.{key}" if parent_key else key
                if isinstance(value, dict):
                    flattened.update(flatten_dict(value, new_key))
                elif isinstance(value, str) and key.endswith("file"):
                    flattened[new_key] = self._resolve_filename(value)
                else:
                    flattened[new_key] = value
            return flattened

        if "config" in port_spec:
            return flatten_dict(port_spec["config"])
        return {}
