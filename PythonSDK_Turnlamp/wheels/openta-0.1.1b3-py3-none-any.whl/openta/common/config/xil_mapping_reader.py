import os

import numpy as np
from dSPACE.Common.XilMappingHandler import XilMapping
from dSPACE.Common.XilMappingHandlerInterfaces import ValueType, VariableType

from openta.common import exceptions
from openta.common.config.registry import Registry
from openta.common.variables import FrameworkVariable, PortVariable

# TODO : save import stuff


MAP_VALUETYPE_TO_DTYPE = {
    int(ValueType.FloatValue): np.dtype("float64"),
    int(ValueType.IntValue): np.dtype("int64"),
    int(ValueType.UintValue): np.dtype("uint64"),
    int(ValueType.StringValue): np.dtype("str"),
    int(ValueType.BooleanValue): np.dtype("bool"),
    int(ValueType.IntVectorValue): np.dtype("int64"),
    int(ValueType.FloatVectorValue): np.dtype("float64"),
    int(ValueType.UintVectorValue): np.dtype("uint64"),
    int(ValueType.StringVectorValue): np.dtype("str"),
    int(ValueType.BooleanVectorValue): np.dtype("bool"),
    int(ValueType.IntMatrixValue): np.dtype("int64"),
    int(ValueType.UintMatrixValue): np.dtype("uint64"),
    int(ValueType.FloatMatrixValue): np.dtype("float64"),
    int(ValueType.StringMatrixValue): np.dtype("str"),
    int(ValueType.BooleanMatrixValue): np.dtype("bool"),
}


MAP_VARIABLETYPE_TO_DTYPE = {
    int(VariableType.UIntVariable): np.dtype("uint64"),
    int(VariableType.IntVariable): np.dtype("int64"),
    int(VariableType.FloatVariable): np.dtype("float64"),
    int(VariableType.BoolVariable): np.dtype("bool"),
    int(VariableType.StringVariable): np.dtype("str"),
    int(VariableType.UIntVectorVariable): np.dtype("uint64"),
    int(VariableType.IntVectorVariable): np.dtype("int64"),
    int(VariableType.FloatVectorVariable): np.dtype("float64"),
    int(VariableType.BoolVectorVariable): np.dtype("bool"),
    int(VariableType.StringVectorVariable): np.dtype("str"),
    # [ ... ]
}


class XilMappingReader:
    """
    A very simple reader for XIL API Mapping files,
    based on the `dSPACE.Common.XilMappingHandler`.

    No merge of mappings is applied,
    just the label mapping and the value types of both labels are considered
    and added to the Registry.
    """

    def __init__(self, file_name: os.PathLike[str] | str) -> None:
        self._filename = os.fspath(file_name)

    def add_to_registry(self) -> None:
        xil_mapping = XilMapping()

        # currently only one, So no merge needed, later possible
        xil_mapping.Load(self._filename)
        if xil_mapping.ErrorMessage:
            raise exceptions.ConfigurationError(f"Failed to read XIL API Mapping: {xil_mapping.ErrorMessage}")

        try:
            testbenchtype = {
                (item.PortId, item.Id): MAP_VALUETYPE_TO_DTYPE[int(item.SimpleType.Type)]
                for item in xil_mapping.TestbenchLabels
            }
        except KeyError as err:
            raise exceptions.ConfigurationError(
                f"Failed to read XIL Mapping. (Currently) Unsupported ValueType of. :: {exceptions.format_exc(err)}",
            ) from err

        try:
            frameworktype = {
                (item.Id): MAP_VARIABLETYPE_TO_DTYPE[int(item.Type)] for item in xil_mapping.FrameworkLabels
            }
        except KeyError as err:
            raise exceptions.ConfigurationError(
                f"Failed to read XIL Mapping. (Currently) Unsupported ValueType of. :: {exceptions.format_exc(err)}",
            ) from err

        registry = Registry()
        for item in xil_mapping.LabelMappings:
            fw_var = FrameworkVariable(
                str(item.FrameworkLabelReference.LabelId),
                frameworktype[item.FrameworkLabelReference.LabelId],
            )

            port_var = PortVariable(
                str(item.TestbenchLabelReference.LabelId),
                str(item.TestbenchLabelReference.PortId),
                testbenchtype[
                    (
                        item.TestbenchLabelReference.PortId,
                        item.TestbenchLabelReference.LabelId,
                    )
                ],
            )

            registry.add_mapping_item(fw_var, port_var)
