import importlib
import os
import pathlib
import re
import typing
import warnings
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import Element

from dSPACE.Common.XilMappingHandler import XilMapping
from dSPACE.Common.XilMappingHandlerInterfaces import (
    ElementExtractionInfo,
    FrameworkLabel,
    FrameworkLabelReference,
    LabelMapping,
    OneToOne,
    SimpleType,
    TestbenchLabel,
    TestbenchLabelReference,
    ValueType,
    VariableType,
)

from openta.common import exceptions
from openta.common.config.registry import Registry
from openta.common.exceptions import AsmVariableError, XilMappingError
from openta.ports import PortState
from openta.ports.xilapi_modelaccess import XilModelAccessPort


class XilMappingGenerator:
    """
    Generates XIL API mapping from an ASM_Traffic.xml file and saves the XIL API mapping to a given filepath.
    The alias are determined from the modelpath. The resulting mapping is similar to Scbt in SIMPHERA.

    Attributes:
        _filename (str): ASM_Traffic.xml file
        _port_id (str): MAPort name
        _port (AbstractPort): MAPort
        _xilmapping (XilMapping): generated XIL API mapping
    """

    def __init__(self, file_name: os.PathLike[str] | str) -> None:
        """
        Create XilMappingGenerator.
        The XilMappingGenerator can be used to read an ASM*.xml file and generate an XIL Mapping file from it.
        Alias names are generated from the signal names, with "invalid" characters replaced by underscores.

        Args:
            file_name (path-like): the ASM sourcefile to create mapping from.
        """
        self._source_path = pathlib.Path(os.fspath(file_name))

        # MA Port for variable infos
        self._port_id = self._determine_port_id()
        self._port = Registry().get_port(self._port_id)

        # Start with empty XIL mapping
        self._xilmapping = XilMapping()

        # set of already created aliases.
        # based on that, names are made unique
        self._known_signal_names: set[str] = set()

        # Mapping from ASAM XIL DataType enum to dSPACE XilMappingHandler VariableType
        # Created mapping is cached as object variable, see: _get_variable_type()
        self._datatype_to_variabletype: dict[typing.Any, VariableType] | None = None

    def generate(
        self,
        file_name: os.PathLike[str] | str | None = None,
        skip_if_target_newer: bool = True,  # noqa: FBT001, FBT002
    ) -> pathlib.Path:
        """
        Generate XIL API mapping and save it to file.
        If no `file_name` is provided, it is determined from the source file,
        by simply adding replacing the file suffix by `.xilmapping_generated.xml`

        Args:
            file_name (path-like, optional): Filename where to save the XIL API mapping
            skip_if_target_newer (bool, optional): Do not generate the target if it exists and is newer than source.
                Defaults to True.
        Returns:
            path-like: Filename where the XIL API mapping is saved
        """
        # Check for ASM .xml source file
        if not self._source_path.exists():
            raise exceptions.ConfigurationError(
                f"Cannot generate XIL Mapping based on ASM*.xml file. The specified source file does not exist: {self._source_path}",
            )

        target_path = (
            pathlib.Path(os.fspath(file_name))
            if file_name is not None
            else self._source_path.with_suffix(".xilmapping_generated.xml")
        )

        # check if we could skip generation
        if skip_if_target_newer and target_path.exists():
            target_mtime = target_path.stat(follow_symlinks=True).st_mtime_ns
            source_mtime = self._source_path.stat(follow_symlinks=True).st_mtime_ns

            if source_mtime < target_mtime:
                warnings.warn(
                    f"Skipped generation of XIL Mapping file based on ASM*.xml source. The target file already exists and is newer then its source. Source: '{self._source_path}'. Target: '{target_path}'",
                    stacklevel=2,
                )
                return target_path

        # create `XilMapping` by reading ASM file
        # and add framework labels,testbench labels and the mapping table based on that file
        self._create_mapping()

        # Validate XIL mapping
        is_mapping_valid = self._xilmapping.Validate()
        if not is_mapping_valid:
            raise XilMappingError("Failed to validate XIL API Mapping.")

        # Save to file
        self._xilmapping.Save(target_path.as_posix())
        return target_path

    def _create_mapping(self) -> None:
        """
        Add signals from ASM_Traffic.xml file to XIL API mapping
        """

        # Start MAPort for getting variable info
        if self._port.state <= PortState.RELEASED:
            self._port.create()
        if self._port.state <= PortState.CREATED:
            self._port.connect()

        try:
            # Parse ASM .xml file
            asm_traffic_xml_root = ET.parse(self._source_path).getroot()  # noqa: S314

            # Check whether it is a MPSystem
            is_mp_system = self._get_text("ModelTopology", asm_traffic_xml_root).lower() == "mpsystem"

            # Adjust prefix for MPSystem. Empty prefix for SingleSystem.
            rtpath_prefix = ""
            if is_mp_system:
                application_name_node = asm_traffic_xml_root.find(
                    "MainComponents/MainComponent/SubComponents/SubComponent/MPApplicationName",
                )
                rtpath_prefix = f"{application_name_node.text}/" if application_name_node is not None else rtpath_prefix

            # Add signals for maneuver control if EnvironmentPaths.xml was given

            # Add variable for maneuver start
            maneuver_node = self._get_xml_element(".//*[Name='MANEUVER_START']", asm_traffic_xml_root)
            rtpath_suffix = self._get_text("Parameters/Parameter/MaskVar", maneuver_node) + "[0|1]/Value"
            self._add_maneuver_ctrl_signal(
                "ManeuverStart",
                maneuver_node,
                rtpath_prefix,
                rtpath_suffix,
                is_mp_system,
            )

            # Add variable for maneuver stop
            maneuver_node = self._get_xml_element(".//*[Name='MANEUVER_STOP']", asm_traffic_xml_root)
            rtpath_suffix = self._get_text("Parameters/Parameter/MaskVar", maneuver_node) + "[0|1]/Value"
            self._add_maneuver_ctrl_signal(
                "ManeuverStop",
                maneuver_node,
                rtpath_prefix,
                rtpath_suffix,
                is_mp_system,
            )

            # Add variable for maneuver reset
            maneuver_node = self._get_xml_element(".//*[Name='RESET']", asm_traffic_xml_root)
            rtpath_suffix = self._get_text("Parameters/Parameter/MaskVar", maneuver_node) + "[0|1]/Value"
            self._add_maneuver_ctrl_signal(
                "Reset",
                maneuver_node,
                rtpath_prefix,
                rtpath_suffix,
                is_mp_system,
            )

            # Add variable for maneuver state
            maneuver_node = self._get_xml_element(".//*[Name='MANEUVER_STATE']", asm_traffic_xml_root)
            rtpath_suffix = "ManStateGain/Out1"
            self._add_maneuver_ctrl_signal(
                "ManeuverState",
                maneuver_node,
                rtpath_prefix,
                rtpath_suffix,
                is_mp_system,
            )

            # Signals that defined in ASM .xml file as "PlotSignals" are added to the registry recursively
            for collector_xml_root in asm_traffic_xml_root.findall("PlotSignals/Collector"):
                collector_name = self._get_text("Name", collector_xml_root)
                signals_xml_root = self._get_xml_element("Signals", collector_xml_root)
                original_rtpath = self._get_text("RTPath", collector_xml_root)
                if is_mp_system:
                    mp_application_name_xmlnodeode = collector_xml_root.find("MPApplicationName")
                    rtpath_prefix = (
                        f"{mp_application_name_xmlnodeode.text}/"
                        if mp_application_name_xmlnodeode is not None
                        else rtpath_prefix
                    )
                new_rtpath = "/".join(
                    (
                        f"{rtpath_prefix}Model Root",
                        original_rtpath.partition("/")[-1],
                        "signal_structure/SignalFilterGain/Out1",
                    ),
                )
                self._collect_signals(signals_xml_root, new_rtpath, collector_name)
        finally:
            # Close port
            if self._port.state >= PortState.CONNECTED:
                self._port.disconnect()
            self._port.release()

    def _add_maneuver_ctrl_signal(
        self,
        signal_name: str,
        node: Element,
        rtpath_prefix: str,
        rtpath_suffix: str,
        is_mp_system: bool,
    ) -> None:
        """
        Function to add maneuver control signal to xil mapping

        Args:
            signal_name The unique signal name
            node (Element): The xml node of the signal
            rtpath_prefix (str): Prefix to add to the signal's modelpath
            rtpath_suffix (str): Suffix to add to the signal's modelpath
            is_mp_system (bool): Is the system an MPSystem?
        """

        # Adjust prefix for MPSystem
        if is_mp_system:
            mp_application_name_node = node.find("MPApplicationName")
            rtpath_prefix = (
                f"{mp_application_name_node.text}/" if mp_application_name_node is not None else rtpath_prefix
            )
        # Get model path
        model_rtpath = self._get_text("ModelRTPath", node)
        new_rtpath = "/".join(
            (
                f"{rtpath_prefix}Model Root",
                model_rtpath.partition("/")[-1],
                rtpath_suffix,
            ),
        )
        # Add signal
        self._add_signal(signal_name, new_rtpath)

    def _collect_signals(
        self,
        signals_xmlroot: Element,
        new_rtpath: str,
        collector_name: str,
    ) -> None:
        """
        Function to recursively collect all signals from a given asm node.

        Args:
            signals_xmlroot (Element): The root of signal
            new_rtpath (str): The new real-time path
            collector_name (str): The collector name
        """

        child_nodes = signals_xmlroot.findall("Node")
        # Add signals from child nodes
        for child_node in child_nodes:
            self._collect_signals(child_node, new_rtpath, collector_name)

        # Add signals from current node
        for signal in signals_xmlroot.findall("Signal"):
            name, rtpath = self._format_name_and_path(new_rtpath, signal)

            self._add_signal(name, rtpath)

    def _add_signal(self, signal_name: str, rtpath: str) -> None:
        """
        Function to add signal to XIL API mapping

        Args:
            signal_name (str): The unique signal name
            rtpath (str): The signal's model path
        """

        # add alias name to known signals, for faster retrieval
        self._known_signal_names.add(signal_name)

        # Add framework label
        framework_label = FrameworkLabel(signal_name, self._get_variable_type(rtpath))
        self._xilmapping.AddFrameworkLabel(framework_label)

        # Create framework label reference
        framework_label_reference = FrameworkLabelReference(signal_name)

        # Add testbench label
        testbench_label = TestbenchLabel(rtpath, self._port_id)
        simple_type = SimpleType()
        simple_type.Type = ValueType.FloatValue
        testbench_label.SimpleType = simple_type
        self._xilmapping.AddTestbenchLabel(testbench_label)

        # Create testbench label reference
        testbench_label_reference = TestbenchLabelReference(rtpath, self._port_id)
        element_extraction_info = ElementExtractionInfo()
        element_extraction_info.OneToOne = OneToOne()
        testbench_label_reference.FromSimple = element_extraction_info

        # Add mapping label
        label_mapping = LabelMapping()
        label_mapping.TestbenchLabelReference = testbench_label_reference
        label_mapping.FrameworkLabelReference = framework_label_reference
        self._xilmapping.AddLabelMapping(label_mapping)

    def _get_variable_type(self, rtpath: str) -> VariableType:
        """Determine variable type from MAPort.

        Args:
            rtpath (str): The model path of the variable

        Returns:
            dSPACE.Common.XilMappingHandlerInterfaces.VariableType: The type of the variable
        """

        # Create Mapping from ASAM XIL DataType enum to dSPACE XilMappingHandler VariableType
        # we would like to have it at module level, but do not want to import the ASAM.XIL.Interfaces assembölies there
        if self._datatype_to_variabletype is None:
            # Import ASAM DataType
            en = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.ValueContainer.Enum")

            # Mapping from ASAM XIL DataType enum to dSPACE XilMappingHandler VariableType
            self._datatype_to_variabletype = {
                en.DataType.eBOOLEAN: VariableType.BoolVariable,
                en.DataType.eINT: VariableType.IntVariable,
                en.DataType.eUINT: VariableType.UIntVariable,
                en.DataType.eFLOAT: VariableType.FloatVariable,
                en.DataType.eSTRING: VariableType.StringVariable,
                en.DataType.eINT_VECTOR: VariableType.IntVectorVariable,
                en.DataType.eFLOAT_VECTOR: VariableType.FloatVectorVariable,
                en.DataType.eSTRING_VECTOR: VariableType.StringVectorVariable,
                en.DataType.eBOOLEAN_VECTOR: VariableType.BoolVectorVariable,
                en.DataType.eINT_MATRIX: VariableType.IntMatrixVariable,
                en.DataType.eFLOAT_MATRIX: VariableType.FloatMatrixVariable,
                en.DataType.eSTRING_MATRIX: VariableType.StringMatrixVariable,
                en.DataType.eBOOLEAN_MATRIX: VariableType.BoolMatrixVariable,
                en.DataType.eUINT_VECTOR: VariableType.UIntVectorVariable,
                en.DataType.eUINT_MATRIX: VariableType.UIntMatrixVariable,
            }

        # Get data type from MAPort
        variable_info = self._port.origin.GetVariableInfo(rtpath)
        try:
            return self._datatype_to_variabletype[variable_info.DataType]
        except KeyError as err:
            raise exceptions.ConfigurationError(
                f"Failed to generate XIL Mapping. (Currently) Unsupported DataType. :: {exceptions.format_exc(err)}",
            ) from err

    def _format_name_and_path(self, rtpath: str, signal: Element) -> tuple[str, str]:
        """Replacement of invalid characters. Ensure unique signal name.

        Args:
            rtpath (str): The new real-time path
            signal (Element): The signal xml object

        Returns:
            Tuple[str, str]: Unique signal name, modelpath
        """

        # example: TrafficObject_Type_Fellows[]{7,1}
        name = signal.attrib["Name"]
        postfix = ""
        unit = ""
        if name.count("[") > 0:
            unit = name.split("[")[-1].split("]")[0]
            unit = unit.replace("%", "percent").replace("|", "_")

            signal_name = name.split("[")[0]
            postfix_original = name.split("]")[-1]
            if postfix_original:
                postfix = "_" + "_".join(postfix_original.rstrip("}").lstrip("{").split(","))
        elif name.count("{") > 0:
            signal_name = name.split("{")[0]
            postfix = "_" + "_".join(name.split("{")[1].split("}")[0].split(","))
        else:
            signal_name = name

        if unit:
            signal_name = signal_name + "_" + unit
        if postfix:
            signal_name = signal_name + postfix

        # Convert display name
        signal_name = re.sub(re.compile("\\W"), "_", signal_name)  # replace special characters
        signal_name = re.sub(re.compile("_+"), "_", signal_name)  # remove multiple underscores
        if signal_name[-1] == "_":
            signal_name = signal_name[:-1]  # remove trailing underscore

        signal_name = self._avoid_duplicate_name(signal_name)

        idx = int(signal.attrib["Idx"])
        model_path = rtpath + f"[1,{idx + 1}]"

        return signal_name, model_path

    def _avoid_duplicate_name(self, name: str) -> str:
        """
        Checks if the given name is already contained in the given set and renames it if necessary.

        Args:
            name (str): The signal name

        Returns:
            str: Unique signal name
        """
        unique_signal_names = self._known_signal_names
        if name in unique_signal_names:
            digit = 2
            while f"{name}_{digit}" in unique_signal_names:
                digit += 1
            name = f"{name}_{digit}"

        return name

    def _get_xml_element(self, xpath: str, xmlroot: Element) -> Element:
        """
        Get the xml element of defined xpath from specified `xmlroot`.

        Args:
            xpath (str): The content to look for
            xmlroot (Element): The xml root element

        Returns:
            Element: The xml element matching xpath
        """

        xml_node = xmlroot.find(xpath)
        if xml_node is None or xml_node.text is None:
            raise AsmVariableError(
                f"Failed to generate variable mapping from ASM*.xml. Cannot read '{xpath}' from file '{self._source_path}'. Element not found or empty.",
            )
        return xml_node

    def _get_text(self, xpath: str, xmlroot: Element) -> str:
        """
        Get the text contents of defined xpath from specified `xmlroot`.

        Args:
            xpath (str): The content to look for
            xmlroot (Element): The xml root element

        Returns:
            str: The text contents of the xml element matching xpath
        """

        xml_node = self._get_xml_element(xpath, xmlroot)
        if xml_node.text is None or xml_node.text == "":
            raise AsmVariableError(
                f"Failed to generate variable mapping from ASM*.xml. Cannot read {xpath} from file '{self._source_path}'. Element not found or empty.",
            )
        return xml_node.text

    def _determine_port_id(self) -> str:
        """
        Find a suitable dSPACE Model Access port in Registry,
        and return its Name.

        Returns:
            str: Name of MAPort
        """

        reg = Registry()
        maports = [p for p in reg.get_ports() if isinstance(p, XilModelAccessPort)]

        if not maports:
            raise AsmVariableError(
                "Cannot get variables from ASM. At least one dSPACE MAPort has to be configured in test environment config yaml or XIL API framework config xml file.",
            )
        if len(maports) > 1:
            warnings.warn(
                f"On adding ASM variables more than one defined dSPACE MAPort are found. The first will be further used for ASm variables: '{maports[0].name}'.",
                stacklevel=2,
            )
        return maports[0].name
