import typing

from openta.common.exceptions import AlreadyExistsError, NotFoundError

if typing.TYPE_CHECKING:  # pragma: no cover
    from openta.common.variables import FrameworkVariable, PortVariable
    from openta.ports.abc import AbstractPort


class Registry:
    """
    *intern*

    This is the global registry for all objects and items
    known to the openta.
    This is the very heart of dynamic access of variables and ports.
    Access from various collections provided to the user for the ease of use,
    are routed through this registry
    """

    _openta_registry_instance: typing.Optional["Registry"] = None

    def __new__(cls) -> "Registry":
        if cls._openta_registry_instance is None:
            cls._openta_registry_instance = super().__new__(cls)
            cls._openta_registry_instance._initialized = False  # noqa: SLF001
        return cls._openta_registry_instance

    def __init__(self) -> None:
        if not self._initialized:
            self._initialized = True
            self._ports: dict[str, AbstractPort] = {}
            self._variable_mapping: dict[str, tuple[str, str]] = {}
            self._framework_variables: dict[str, FrameworkVariable] = {}
            self._port_variables: dict[tuple[str, str], PortVariable] = {}

    def add_port(self, port_object: "AbstractPort") -> "AbstractPort":
        """
        Add the given `port_object` to the registry.
        The `port_object.name` is used as unique key.

        raise: AlreadyExistsError
        """
        # TODO: break import cycle, such that we can import the AbstractPort
        if not (
            hasattr(port_object, "name") and hasattr(port_object, "order") and hasattr(port_object, "target_state")
        ):
            raise TypeError(f"Cannot add `{port_object!r}` as port.")
        key = port_object.name
        if key not in self._ports:
            self._ports[key] = port_object
            return port_object
        raise AlreadyExistsError(key, "port", self._ports[key], port_object)

    def get_port(self, key: str) -> "AbstractPort":
        """
        Get the port associated with given `key`.
        """
        if key in self._ports:
            return self._ports[key]
        raise NotFoundError(key, "port")

    def remove_port(self, port_or_name: typing.Union["AbstractPort", str]) -> None:
        """
        Remove the specified port, either by port instance or name
        """
        if isinstance(port_or_name, str):
            # its a string (port name) - delete by key
            if port_or_name in self._ports:
                del self._ports[port_or_name]
            else:
                raise NotFoundError(port_or_name, "port")
        elif hasattr(port_or_name, "name") and hasattr(port_or_name, "order") and hasattr(port_or_name, "target_state"):
            # we have to use duck typing here due to cyclic imports
            # search for specified object in values
            keys = [k for k, v in self._ports.items() if v is port_or_name]
            if len(keys) == 0:
                raise NotFoundError(port_or_name.name, "port")
            for key in keys:
                del self._ports[key]
        else:
            raise TypeError(f"Cannot remove `{port_or_name!r}` as port.")

    def get_port_count(self) -> int:
        return len(self._ports)

    def get_ports(self) -> list["AbstractPort"]:
        """
        Return the ports due to their order
        """
        return sorted(self._ports.values(), key=lambda port: port.order)

    def add_mapping_item(self, alias: "FrameworkVariable", port_variable: "PortVariable") -> None:
        # TODO: break import cycle, such that we can import FrameworkVariable and PortVariable
        if not (hasattr(alias, "id") and hasattr(alias, "dtype") and not hasattr(alias, "port_id")):
            raise TypeError(f"Cannot add `{alias!r}` as framework variable.")
        if not (hasattr(port_variable, "id") and hasattr(port_variable, "dtype") and hasattr(port_variable, "port_id")):
            raise TypeError(f"Cannot add `{port_variable!r}` as port variable.")

        fw_var_id = alias.id
        port_var_id = (port_variable.port_id, port_variable.id)
        port_id = port_variable.port_id
        try:
            # Framework Variable with given must not exist
            if fw_var_id in self._framework_variables:
                raise AlreadyExistsError(fw_var_id, "alias", self._framework_variables[fw_var_id], alias)
            # Port Variable with given id may exist, but must be equal in all properties (e.g. dtype)
            if port_var_id in self._port_variables and self._port_variables[port_var_id] != port_variable:
                raise AlreadyExistsError(
                    str(port_var_id),
                    "port variable",
                    self._port_variables[port_var_id],
                    alias,
                )
            if port_id not in self._ports:
                raise NotFoundError(port_id, "port")

            # and then add the items to their respective collections
            self._framework_variables[fw_var_id] = alias
            self._port_variables[port_var_id] = port_variable
            self._variable_mapping[fw_var_id] = port_var_id

        except Exception as err:
            err.add_note(f"Failed to add variable mapping: {alias!r} -> {port_variable!r}.")
            raise

    def get_port_variable(self, alias: typing.Union["FrameworkVariable", str]) -> "PortVariable":
        key = alias.id if not isinstance(alias, str) else alias
        port_var_id = self._variable_mapping[key]
        return self._port_variables[port_var_id]

    def get_framework_variable(self, key: str) -> "FrameworkVariable":
        if key in self._framework_variables:
            return self._framework_variables[key]
        raise NotFoundError(key, "framework variable")

    def get_framework_variable_count(self) -> int:
        return len(self._framework_variables)

    def get_framework_variables(self) -> typing.ValuesView["FrameworkVariable"]:
        return self._framework_variables.values()
