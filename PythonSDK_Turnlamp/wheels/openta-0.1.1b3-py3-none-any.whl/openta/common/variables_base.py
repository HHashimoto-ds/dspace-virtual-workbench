import typing

import numpy.typing as npt
from openta.common.config.registry import Registry

if typing.TYPE_CHECKING:  # pragma: no cover
    import numpy.typing as npt


class VariableDescription:
    """
    Common abstract definition of variable.

    Attributes:
        id (str): the unique id of this variable
        dtype (dtype): the data type of this variable, expressed as numpy dtype
    """

    def __init__(self, identifier: str, dtype: "npt.DTypeLike") -> None:
        self._identifier = identifier
        self._dtype = dtype

    @property
    def id(self) -> str:
        """
        the native port specific variable identifier.
        (currently string)
        """
        return self._identifier

    @property
    def dtype(self) -> "npt.DTypeLike":
        """
        The datatype of the Variable as specified by the configuration.
        """
        return self._dtype


class VariableReference:
    """
    A class simply for referencing a Framework variable and delegating all access.
    Class instances are generated for ease of use and more sophisticated documention.
    """

    def __init__(self, identifier: str) -> None:
        self._identifier = identifier

    @property
    def id(self) -> str:
        """
        the framework label identifier
        """
        return self._identifier

    def __getattr__(self, key: str) -> object:
        return getattr(Registry().get_framework_variable(self.id), key)
