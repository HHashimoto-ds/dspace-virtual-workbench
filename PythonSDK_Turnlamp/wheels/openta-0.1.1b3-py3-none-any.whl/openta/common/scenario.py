import collections.abc
import enum
import os
import typing
from abc import ABC, abstractmethod

from openta.common.variables_base import VariableDescription

if typing.TYPE_CHECKING:  # pragma: no cover
    import numpy as np


class ManeuverState(enum.IntEnum):
    """
    Enumeration of possible maneuver states of the scenario.
    Currently adapted to dSPACE ModelDesk maneuver states, so may still change.
    """

    START = 1

    INIT = 2
    """
    The maneuver is currently initialising.
    """

    RUN = 3
    """
    The maneuver is currently running.
    """

    STOPPING = 4
    """
    The maneuver is currently stopping.
    """

    WAIT = 5
    """
    The maneuver is currently waiting.
    """

    INIT_MANUAL = 6

    MANUAL = 7


class ScenarioParameter(ABC, VariableDescription):
    """
    Abstrtact Base Class for scenario parameters.
    """

    @property
    @abstractmethod
    def description(self) -> str:
        pass

    @property
    @abstractmethod
    def value(self) -> "np.generic":
        pass

    @value.setter
    @abstractmethod
    def value(self, value: typing.Union["np.generic", float, bool, str]) -> None:
        pass


class ScenarioParametersList(collections.abc.Mapping[str, ScenarioParameter]):
    """
    Collection scenario parameters, determined from specified scenario files of current scenario.
    ScenarioParameters can be accessed by name either by dotted (attribute) access or random access operator.
    If a name is not defined a KeyError is raised.
    """

    def __init__(self, params: typing.Iterable[ScenarioParameter]) -> None:
        self._internal = {p.id.rpartition("/")[-1]: p for p in params}

    def __repr__(self) -> str:
        return str(self)

    def __str__(self) -> str:
        return "ScenarioParameters"

    def __getattr__(self, key: str) -> ScenarioParameter:
        """
        Look up a ScenarioParameter by name in dotted access notation.
        """
        return self._internal[key]

    def __getitem__(self, key: str) -> ScenarioParameter:
        """
        Look up a ScenarioParameter by name.
        """
        return self._internal[key]

    def __setitem__(self, key: str, value: typing.Union["np.generic", float, bool, str]) -> None:
        raise TypeError(f"Cannot set attribute '{key}'. The ScenarioParametersList is read only")

    def __len__(self) -> int:
        # look up number of frameworklabels
        return len(self._internal)

    def __contains__(self, key: object) -> bool:
        if isinstance(key, ScenarioParameter):
            key = key.id
        elif not isinstance(key, str):
            raise TypeError(
                f"Containment check for ScenarioParametersList not supported for key of given type: {type(key)}",
            )
        return key in self._internal

    def __iter__(self) -> typing.Iterator[str]:
        return iter(self._internal)


class AbstractScenario(ABC):
    @abstractmethod
    def download(self, **kwargs: typing.Any) -> None:
        """
        Download the specifed scenario.
        """

    def apply_parameters(self, parameters: dict[str, typing.Any] | os.PathLike[str]) -> None:
        """
        Apply all values from given `parameters` dict to Scenario parameters.
        The key has to be the parameters name and the coresponding value is the value to set for that key.
        """
        if isinstance(parameters, collections.abc.Mapping):
            for name, value in parameters.items():
                self.vars[name].value = value
        else:
            raise NotImplementedError("loading and applying scenario parameters from file s not yet supported")

    @abstractmethod
    def start(self) -> None:
        """
        Start the maneuver.
        """

    @abstractmethod
    def stop(self) -> None:
        """
        Stop the maneuver.
        """

    @abstractmethod
    def reset(self) -> None:
        """
        Reset the maneuver.
        """

    @abstractmethod
    def wait_for_maneuver_state(self, state: ManeuverState, timeout: float | None = None) -> None:
        """
        Wait for the specified maneuver state.
        The function does not return until the specified ManeuverState is determined.
        An optional `timeout` in seconds can be specified, which leads to a ScenarioError exception if exceeded.

        Args:
            state (ManeuverState): The expected state.
            timeout (float | None): an optional timeout in seconds. Defaults to None: No timeout

        Raises:
            ScenarioError: If timeout is specified and exceeded
        """

    @abstractmethod
    def wait_for_maneuver_finished(self, timeout: float | None = None) -> None:
        """
        Wait for the maneuver to be finished.
        An optional `timeout` in seconds can be specified, which leads to a ScenarioError exception if exceeded.

        Args:
            timeout (float | None): an optional timeout in seconds. Defaults to None: No timeout

        Raises:
            ScenarioError: If timeout is specified and exceeded
        """

    @property
    @abstractmethod
    def maneuver_state(self) -> ManeuverState:
        """
        Get the state of maneuver
        """

    @property
    @abstractmethod
    def vars(self) -> ScenarioParametersList:
        """
        Access the collection of aliases defined in current Scenario.
        Aliases are not devided into Maneuver and Traffic aliases, but
        all aliases are available directly in the returned collection.
        """
