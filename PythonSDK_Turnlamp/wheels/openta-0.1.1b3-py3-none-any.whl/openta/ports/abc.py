import enum
import os
import pathlib
import typing
from abc import ABC, abstractmethod

from openta.common import exceptions
from openta.common.variables import FrameworkVariable, PortVariable

if typing.TYPE_CHECKING:  # pragma: no cover
    import numpy as np
    from pandas import DataFrame, Series


class CaptureState(enum.IntEnum):
    """
    Enumeration of possible states of a port specific capture object.

    The `AbstractCapture` and its subclasses wrap various port specific captures and
    abstracts over their creation, configuration and lifecycle.

    The meaning of the states is somewhat port specific.
    """

    RELEASED = 0
    """
    The wrapped port specific capture resource is already released.
    """

    CONFIGURED = 1
    """
    The wrapped capture resource is created and configured.
    """

    ACTIVATED = 2
    """
    The wrapped capture is started and waiting for an optional start trigger.
    """

    RUNNING = 3
    """
    The wrapped capture is running.
    """

    FINISHED = 4
    """
    The wrapped capture has finished and can be stopped.
    """


class PortState(enum.IntEnum):
    """
    Enumeration of possible (lifecycle) states of a port.

    The `AbstractPort` and its concrete subclasses wrap various third-party
    components of a test environment and abstracts over creation and release lifecycle.
    What resources are managed by the port is implementation specific and
    the `PortState` enumeration reflects stages of that lifecycle.

    Instances of concrete subclasses of AbstractPort are created
    based on the test environment .yaml file.
    """

    RELEASED = 0
    """
    The wrapped port resource is not yet created or already released.
    """

    CREATED = 1
    """
    The wrapped port resource is created but no yet configured or connected.
    """

    CONNECTED = 2
    """
    The wrapped port resource is connected.
    This means the wrapped port resource is fully configured, operatable and ready to use.
    """

    STARTED = 3
    """
    The wrapped port resource is started.
    The meanings depends on the port, but in general `STARTED` state is considered a substate of `CONNECTED`,
    and may not be meaningul for all port implementations.
    """


class AbstractCapture(ABC):
    """
    Abstract base class for openta captures that provides a common interface,
    that abstracts over port-specific or 3rd party related differences.
    """

    @property
    @abstractmethod
    def port(self) -> "AbstractPort":
        """
        Get the corresponding openta port instance.
        """

    @property
    @abstractmethod
    def state(self) -> CaptureState:
        """
        Get the current state of the capture.
        """

    @property
    @abstractmethod
    def origin(self) -> typing.Any | None:  # noqa: ANN401 # unknown 3rd party object
        """
        Get the underlying/wrapped (3rd party) port specific object.
        Returned value is implementation specific and may be None.
        """

    @property
    @abstractmethod
    def raster_name(self) -> str | None:
        """
        Get the defined measurement raster.
        The defined (or chosen by implementation) raster name for the capturing process.
        The return value is implementation specific, and may also be None to indicate that no raster_name was defined.
        """

    @raster_name.setter
    @abstractmethod
    def raster_name(self, value: str) -> None:
        """
        Set the measurement raster.
        The behaviour is implementation specific and may also not settable.
        """

    @property
    @abstractmethod
    def variables(self) -> typing.Iterable[FrameworkVariable]:
        """
        Get the defined variables as iterable of FrameworkVariables.
        The variables to capture cannot be changed by modifying the returned collection,
        but must be set as a whole.
        """

    @variables.setter
    @abstractmethod
    def variables(self, value: typing.Iterable[FrameworkVariable | str]) -> None:
        """
        Set the variables to capture.+
        Provided strings are treated as alises (names of FrameworkVariables) and looked up in the configured mapping.
        """

    @property
    @abstractmethod
    def datafile_path(self) -> pathlib.Path | None:
        """
        Teturn the specified path to a datafile, if any.
        """

    @datafile_path.setter
    @abstractmethod
    def datafile_path(self, value: str | os.PathLike[str]) -> None:
        """
        Set a file path to a datafile, which is created while capturing.
        The file type may be determined from the suffix.
        The implementation is port specific, but for XIL API ports
        it is assumed to be a single mf4 file.
        """

    @abstractmethod
    def set_start_trigger(self, condition: str, delay: float | None = None) -> None:
        """
        Set an optional start trigger.
        After `start()` the capturing then waits for the condition to be satisfied.
        """

    @abstractmethod
    def set_stop_trigger(self, condition_or_duration: str | float, delay: float | None = None) -> None:
        """
        Set an optional stop trigger.
        If the capturing is in `RUNNING` state it waits for the condition to be fulfilled.
        """

    @abstractmethod
    def start(self) -> None:
        """
        Start the capture process.
        """

    @abstractmethod
    def stop(self) -> None:
        """
        Stop the capture process.
        """

    @abstractmethod
    def release(self) -> None:
        """
        Release the wrapped (3rd party) port specific capture object
        """

    @abstractmethod
    def get_signal(self, variable: FrameworkVariable | str) -> "Series":
        """
        Get the captured values as pandas.Series object.
        To retrieve the signal, the capture has to be in `FINISHED` state.
        """

    @abstractmethod
    def get_data_frame(self) -> "DataFrame":
        """
        Get all measured data as pandas.dataframe
        """


class AbstractPort(ABC):
    """
    Abstract base class for a Port.
    Concrete subclasses act as wrapper around third-party resources
    for accessing hardware or software components
    and abstract over their creation and release lifecycle.

    A port currently features two main aspects:
    1) Lifecylce management: For that concrete ports have to implement
       `create`, `connect`, `start`, `stop`, `disconnect` and `release`
       methods and their `state` property accordingly.
       Of course, all implementations are port specific and may vary in behaviour
       or not even meaningful.
    2) Data access: (Currently) A port must implement, the `read`, `write` and `create_capture`
       methods, to support accessing and capturing port specific variables.
       If the a test uses the `ta` fixture or `TestEnvironmentAccess`,
       to read or write `FrameworkVariables` these are translated to `PortVariable` by means
       of configured (XIL API) Mapping files and used as arguments for the `read` and `write` methods.
    """

    def __init__(
        self,
        name: str,
        order: int,
        target_state: PortState,
        config: dict[str, typing.Any],
    ) -> None:
        """
        Initialize the port.
        This merely creates this wrapping port instance.
        The creation of the wrapped port resource should be deferred to `create()`.
        """
        self._name = name
        self._order = order
        self._target_state = target_state
        self.config = config

    @property
    def name(self) -> str:
        """
        The name of the port as defined by the configuration.
        This is a read only property.
        """
        return self._name

    @property
    def order(self) -> int:
        """
        The `order` as defined by the configuration.
        This is a read only propety.

        This is the ordering property in which the configured ports are set up.
        Ports are setup up to their `target_state` in ascending order.
        """
        return self._order

    @property
    def target_state(self) -> PortState:
        """
        The `target_state` as defined by the configuration.
        This is a read only propety.

        This is the desired target state of the port during setup of the test environment.
        During setup of ports all lifecycle methods are invoked to bring the port to desired state.

        """
        return self._target_state

    def get_option(
        self,
        key: str | typing.Iterable[str],
        config: dict[str, typing.Any] | None = None,
        raise_error: bool = False,  # noqa: FBT001, FBT002
        default: typing.Any | None = None,  # noqa: ANN401 # any built-in Python data type
    ) -> typing.Any:  # noqa: ANN401 # any built-in Python data type
        """
        Get a keyword argument from specified `config` or the `config` provided to the ports `__init__()`.
        If the key is not existent in at least one config object, either an exception is raised if `raise_error` is true
        or the `default` is returned.

        Args:
            key (str | Iterable[str]): The configuration key to look up. It is possible to specifiy an iterable of keys,
                if several spellings or names for that key are valid or in use. (e.g. `["force_config", "ForceConfig"]`).
                In that case the value of first match is returned.
            config (dict[str, typing.Any], optional): An additional configuration dictionary to look up first,
                before looking up the key in the configuration dictionary provided to the port on creation.
                This can be used for overwriting certain configurations at runtime.
            raise_error (bool, optional): Wether an exception shall be raised if the key is not found
                in any of the specified configurations. Defaults to false.
            default (Any, optional): the to be returned default if the key is not found. Defaults to `None`.
        Returns:
            Any: whatever is found under the provided key or the specified default
        """
        if isinstance(key, str):
            key = (key,)
        if config is not None:
            for k in key:
                if k in config:
                    return config[k]
        for k in key:
            if k in self.config:
                return self.config[k]
        if raise_error:
            keys = list(key)
            if len(keys) == 1:
                raise exceptions.PortConfigError(
                    f"{self.__class__.__name__} '{self.name}': Missing mandatory configuration '{keys[0]}'.",
                )
            formatted_keys = ", ".join([f"{k}" for k in keys])
            raise exceptions.PortConfigError(
                f"{self.__class__.__name__} '{self.name}': Missing mandatory configuration for one of the following similar keys: {formatted_keys}",
            )
        return default

    @property
    @abstractmethod
    def state(self) -> PortState:
        """
        Get the current state of port.
        The state should be determined from the wrapped port resource.
        """

    @property
    @abstractmethod
    def origin(self) -> typing.Any:  # noqa: ANN401 # unknown 3rd party object
        """
        Get the wrapped port resource, whatever it may be.
        Implementations have to raise `PortStateError` if that object
        is not available because the port is already in RELEASED state.
        """

    @abstractmethod
    def create(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Create the wrapped port resource.
        Concrete implementations are port specific and may vary,
        but in general a wrapped resource should be aquired by the call to `create()`.
        """

    @abstractmethod
    def connect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Configure the wrapped port resource and connect it.
        """

    @abstractmethod
    def start(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Start the wrapped port resource.
        The implementation is port specific and may be a NOP.
        """

    @abstractmethod
    def stop(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Stop the wrapped port resource.
        This is the counterpart of stop, and may be a NOP.
        A stopped port is considered to be startable again.
        """

    @abstractmethod
    def disconnect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Disconnect the wrapped port resource, if possible.
        The implementation is püort specific.
        """

    @abstractmethod
    def release(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Release the wrapped port resource.
        This function is considered to release the wrapped port resource aquired by `create()`.
        """

    @abstractmethod
    def read(self, variable: PortVariable) -> "np.generic":
        """
        Read the given variable from the port.
        Reading should yield a numpy generic, according to the configured `dtype` if specified `PortVariable`.
        """

    @abstractmethod
    def write(self, variable: PortVariable, value: typing.Union["np.generic", float, bool, str]) -> None:
        """
        Write the given value value to the port.
        """

    @abstractmethod
    def create_capture(self, **kwargs: typing.Any) -> "AbstractCapture":  # noqa: ANN401 # unknown keyword args by design
        """
        Create a port specific instance of a concrete subclass of `AbstractCapture`.
        Provided keyword arguments should be passed to the created object.
        """

    def __str__(self) -> str:
        return f"'{self.name}' {self.__class__.__name__}"
