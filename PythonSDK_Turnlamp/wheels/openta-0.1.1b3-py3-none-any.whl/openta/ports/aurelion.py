import logging
import typing

from openta.automation.aurelion.clients import amclient
from openta.automation.aurelion.clients.cli import launch_aurelion_manager
from openta.common import exceptions
from openta.common.variables import PortVariable
from openta.ports.abc import AbstractCapture, AbstractPort, PortState
from openta.ports.logging import log_port_action_debug, log_port_lifecycle

if typing.TYPE_CHECKING:
    import numpy as np

_logger = logging.getLogger(__name__)


class AurelionPort(AbstractPort):
    """
    A basic Port implementation for dSPACE Aurelion.
    NOTE, that the port does not support read, write and capturing of variables,
    but only implements the "life cycle" interface, such that it possible to
    start and configure dSPACE Aurelion via the test environment yaml file.
    """

    def __init__(
        self,
        name: str,
        order: int,
        target_state: PortState,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, order, target_state, config)
        self._url: str = config["url"]
        self._system_name: str = config["system_name"]
        self._aurelion: amclient.AMClient | None = None

    @property
    def state(self) -> PortState:
        if self._aurelion is None:
            return PortState.RELEASED
        if self._aurelion.get_projects_current_project() is None:
            return PortState.CREATED
        return PortState.CONNECTED

    @property
    def origin(self) -> amclient.AMClient:
        """
        Get the underlying Aurelion client object.
        """
        if self._aurelion is None:
            raise exceptions.PortStateError(
                f"Cannot provide Aurelion '{self.name}'. Port is not yet created.",
            )
        return self._aurelion

    def create(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Launch the Aurelion Manager, and create an appropriate client object.
        """
        with log_port_lifecycle(_logger, self, "create", "Launch AURELION Manager and create client."):
            launch_aurelion_manager(self._url)
            self._aurelion = amclient.AMClient.get_instance(self._url)

    def connect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Load a project and activate an experiment.
        The `port_config_file` is currently used as project file and
        the to be activated experiment is `experiment` from keyword arguments
        """
        with log_port_lifecycle(_logger, self, "connect", "Open specified project."):
            if self.state < PortState.CREATED:
                raise ValueError(
                    f"AurelionPort({self.name}): Cannot connect. Port has to be at least CREATED ({PortState.CREATED}) state, but is {self.state}.",
                )
            if self._aurelion is None:
                raise NotImplementedError("How did you get here?")

            project_file = self.get_option("project_file", kwargs, raise_error=True)
            _logger.debug("connect %s: project_file := '%s'.", self, project_file)

            self._aurelion.put_projects_open_project(project_file)

    def start(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Does nothing because port does not support "started"
        """
        with log_port_lifecycle(_logger, self, "start", "No Operation"):
            if self.state != PortState.CONNECTED:
                raise ValueError(
                    f"AurelionPort({self.name}): Cannot start. Port has to be in CONNECTED ({PortState.CONNECTED}) state, but is {self.state}.",
                )
        # No action on start

    def stop(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Does nothing because port does not support "started"
        """
        with log_port_lifecycle(_logger, self, "stop", "No Operation"):
            pass

    def disconnect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Does nothing because AURELION currently does not support closing projecs. Might close projects in the future.
        """
        with log_port_lifecycle(_logger, self, "disconnect", "No Operation"):
            if self.state != PortState.CONNECTED:
                raise ValueError(
                    f"AurelionPort({self.name}): Cannot disconnect. Port has to be in CONNECTED ({PortState.CONNECTED}) state, but is {self.state}.",
                )
            # Aurelion does not support closing projects

    def release(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Deletes the REST-API client
        """
        with log_port_lifecycle(_logger, self, "release", "No Operation"):
            if self.state not in [PortState.CREATED, PortState.CONNECTED]:
                raise ValueError(
                    f"AurelionPort({self.name}): Cannot release. Port has to be in CREATED ({PortState.CREATED}) state, but is {self.state}.",
                )
            self._aurelion = None

    def read(self, variable: PortVariable) -> "np.generic":
        """
        Reading variables via the Aurelion port is not supported
        """
        raise NotImplementedError("Aurelion Port does not support reading variables.")

    def write(self, variable: PortVariable, value: "np.generic | float | bool | str") -> None:
        """
        Writing variables via the Aurelion port is not supported
        """
        raise NotImplementedError("Aurelion Port does not support writing variables.")

    def create_capture(self, **kwargs: typing.Any) -> AbstractCapture:  # noqa: ANN401 # unknown keyword args by design
        """
        Capturing variables from the Aurelion port is not supported.
        """
        raise NotImplementedError("Aurelion Port does not support capturing of variables.")

    def synchronize_scenario(self, aurelion_scenario: str) -> None:
        """
        Synchronizes a 3D Scenery.

        Args:
            aurelion_scenario (str): aurelion scene name.
        """
        log_port_action_debug(_logger, self, "synchronize", "Synchronize the AURELION Scenario")
        self.origin.synchronize(self._system_name, aurelion_scenario)
