import importlib
import logging
import time
import typing

from System.Collections.Generic import Dictionary

from openta.common import exceptions, utils
from openta.common.config.registry import Registry
from openta.common.variables import PortVariable
from openta.ports.abc import CaptureState, PortState
from openta.ports.logging import log_port_lifecycle
from openta.ports.xilapi_base import XilApiBaseCapture, XilApiBasePort

if typing.TYPE_CHECKING:  # pragma: no cover
    import numpy as np

_logger = logging.getLogger(__name__)


class XilModelAccessCapture(XilApiBaseCapture):
    """
    An XIL API MAPort specific Capture object
    """

    def stop(self) -> None:
        """
        stop the capture and store capture result
        """
        if self.origin.StartTriggerWatcher is not None:
            # Waiting for StopTrigger -> Capture reach state FINISHED
            while self.state != CaptureState.FINISHED:
                time.sleep(0.1)

        super().stop()

    def _create_defines(self, condition_term: str) -> typing.Any:
        """
        Extract Frameworkvariable identifier from condition term and setup defines map.
        Return .NET dictionary
        """
        variable_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
        defines = Dictionary[str, variable_ref.IVariableRef]()
        for alias in utils.get_identifier_from_ges_condition(condition_term):
            try:
                test_bench_path = Registry().get_port_variable(alias).id
            except KeyError:
                _logger.warning("Unkown identifier %s in condition term %s.", alias, condition_term)
                continue

            # dSPACE Limitation: Only ValueRepresentation of type eRawValue supported
            # These are the defines for the trigger condition, evaluation on the platform,
            # so it makes sense to only support raw values here
            var_reference = self.port.testbench.VariableRefFactory.CreateGenericVariableRef(
                test_bench_path,
                variable_ref.Enum.ValueRepresentation.eRawValue,
            )
            defines.Add(alias, var_reference)
        return defines

    def set_start_trigger(self, condition: str, delay: float | None = None) -> None:
        """
        Configure the start trigger condition of this capture.
        Only ConditionWatcher supported.
        """
        defines = self._create_defines(condition)
        watcher = self.port.testbench.WatcherFactory.CreateConditionWatcher2(condition, defines)

        duration = self.port.testbench.DurationFactory.CreateTimeSpanDuration(delay if delay is not None else 0.0)
        self.origin.SetStartTrigger(watcher, duration)

    def set_stop_trigger(self, condition_or_duration: str | float, delay: float | None = None) -> None:
        """
        Configure the stop trigger condition of this capture.
        Condition and Duration Watcher supported.
        """
        if isinstance(condition_or_duration, str):
            defines = self._create_defines(condition_or_duration)
            watcher = self.port.testbench.WatcherFactory.CreateConditionWatcher2(condition_or_duration, defines)
        elif isinstance(condition_or_duration, float):
            watcher = self.port.testbench.WatcherFactory.CreateDurationWatcherByTimeSpan(condition_or_duration)
        else:
            raise Exception("Stop trigger condition must be a string or float value.")

        stop_delay = self.port.testbench.DurationFactory.CreateTimeSpanDuration(delay if delay is not None else 0.0)
        self.origin.SetStopTrigger(watcher, stop_delay)


class XilModelAccessPort(XilApiBasePort):
    """
    XIL API MAPort
    currently able to read and write
    """

    def __init__(
        self,
        name: str,
        order: int,
        target_state: PortState,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, order, target_state, config)

    @property
    def origin(self) -> typing.Any:
        """
        Get the underlying XIL API Port object.
        This returns the pythonnet object wrapped by this MAPort.
        """
        if self._port is None:
            raise exceptions.PortStateError("Cannot provide XIL MAPort. Port is not yet created.")
        return self._port

    @property
    def state(self) -> PortState:
        if self._port is None:
            return PortState.RELEASED

        # TODO: use xil api enums ???
        state = int(self._port.State)
        if state == 2:  # eDISCONNECTED
            return PortState.CREATED
        if state in {0, 3}:  # eSIMULATION_STOPPED | #eSIMULATION_PAUSED
            # simply not running is connected and can be started....
            return PortState.CONNECTED
        if state == 1:  # eSIMULATION_RUNNING
            return PortState.STARTED

        raise exceptions.PortStateError(f"Unable to determine MAPort state. retrieved state unknown: {state}")

    def create(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Create maport instance
        """
        with log_port_lifecycle(_logger, self, "create"):
            # call super create(), to create the testbench beforehand
            super().create()

            # create MAPort via testbenches factory
            self._port = self.testbench.MAPortFactory.CreateMAPort(self.name)

    def connect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Load port configuratio file and configure port.
        """
        with log_port_lifecycle(_logger, self, "connect"):
            port_config_file = self.get_option(["port_config_file", "PortConfigurationFile"], kwargs, raise_error=True)
            force_config = bool(self.get_option(["force_config", "ForceConfig"], kwargs, default=False))
            _logger.debug(
                "connect %s: config_file='%s', force_config=%r",
                self,
                port_config_file,
                force_config,
            )

            try:
                port_config = self.origin.LoadConfiguration(port_config_file)
            except Exception as err:
                raise exceptions.PortConfigError(
                    f"Cannot load config file '{port_config_file}'. :: {exceptions.format_exc(err)}",
                ) from err

            # Configure the XIL API MAPort
            try:
                self.origin.Configure(port_config, force_config)
            except Exception as err:
                raise exceptions.PortConfigError(
                    f"Cannot configure XIL MAPort. :: {exceptions.format_exc(err)}",
                ) from err

    def start(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        start the port in order to work with it.
        """
        with log_port_lifecycle(_logger, self, "start", "Start Simulation"):
            if self.state == PortState.STARTED:
                _logger.warning("start %s: Skipped! Port is already started.", self)
                return

        self.origin.StartSimulation()

    def stop(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        stop the port, this is the counterpart of stop.
        A stopped port can be started again
        """
        with log_port_lifecycle(_logger, self, "stop", "Stop Simulation"):
            if self.state != PortState.STARTED:
                _logger.warning("stop %s: Skipped! Port is not started.", self)
                return

            self.origin.StopSimulation()

    def read(self, variable: PortVariable) -> "np.generic":
        """
        Read the physical value from given variable.
        """
        value = self.origin.Read(variable.id)
        return self._create_numpy_value(value, variable.dtype)

    def write(self, variable: PortVariable, value: typing.Union["np.generic", float, bool, str]) -> None:
        """
        Write the given value to variable.
        The given value object is converted to a XIL API BaseValue according to dtype of PortVariable.
        """
        _logger.debug("write %s: '%s' := %s", self, variable, value)
        converted_value = self._create_base_value(value, variable.dtype)
        return self.origin.Write(variable.id, converted_value)

    def create_capture(self, **kwargs: typing.Any) -> XilModelAccessCapture:  # noqa: ANN401 # unknown keyword args by design
        """
        Create ModelCapture, all provided keyword arguments are passed to the cpature object.
        """
        return XilModelAccessCapture(self, **kwargs)

    def wait(self, duration_in_sec: float, timeout_factor: int = 50) -> None:
        """
        To wait for a specific period of time defined by given value.
        """
        if self.state < PortState.STARTED:
            raise exceptions.PortStateError("Cannot wait on MAPort DAQClock. Port is not started/running.")

        if not hasattr(self.origin, "DAQClock"):
            raise exceptions.PortTypeError("Cannot wait on MAPort DAQClock. Port seems not to have a `DAQClock`.")
        timeout_sys = 0
        stop_time = self.origin.DAQClock + duration_in_sec

        # Calculate timeout if desired
        if timeout_factor > 0:
            timeout_sys = time.time() + duration_in_sec * timeout_factor

        while stop_time >= self.origin.DAQClock:
            # if timeout should be enabled
            if timeout_factor > 0 and timeout_sys < time.time():
                raise TimeoutError(f"Wait step run into timeout after {timeout_sys} seconds (system clock).")

            time.sleep(0.01)
