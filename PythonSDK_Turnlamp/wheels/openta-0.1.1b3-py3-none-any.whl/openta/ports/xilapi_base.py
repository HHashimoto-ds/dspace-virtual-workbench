import importlib
import logging
import os
import pathlib
import sys
import typing
from importlib import resources

import clr
import numpy as np
import numpy.typing as npt
from pandas import DataFrame, Series
from System import Array

from openta.common import exceptions
from openta.common.config.registry import Registry
from openta.common.variables import FrameworkVariable
from openta.ports.abc import AbstractCapture, AbstractPort, CaptureState, PortState
from openta.ports.logging import log_port_lifecycle

_logger = logging.getLogger(__name__)


class XilApiBasePort(AbstractPort):
    """
    Comon base class for all XIL API Ports
    """

    def __init__(
        self,
        name: str,
        order: int,
        target_state: PortState,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, order, target_state, config)
        self._testbench = None
        self._port = None

    def _create_base_value(self, value: typing.Any, dtype: npt.DTypeLike) -> typing.Any:
        """
        Create a XIL API testbench specific base value according to given dtype.
        """
        dt = np.dtype(dtype)
        if dt.kind == "f":  # float
            return self.testbench.ValueFactory.CreateFloatValue(value)
        if dt.kind == "i":  # integers
            return self.testbench.ValueFactory.CreateIntegerValue(value)
        if dt.kind == "u":  # unsigned integers
            return self.testbench.ValueFactory.CreateUnsignedIntegerValue(value)
        if dt.kind == "b":  # boolean
            return self.testbench.ValueFactory.CreateIntegerValue(value)
        if dt.kind == "U":  # Unicode
            return self.testbench.ValueFactory.CreateStringValue(value)

        raise TypeError(f"Unknown dtype {dtype}. Failed to create XIL AI BaseValue from value {value}.")

    def _create_numpy_value(self, value: typing.Any, dtype: npt.DTypeLike) -> np.generic:
        """
        Create a scalar numpy value according to specified numpy dtype
        """
        #
        #   maybe check between asam datatype and expected numpy dtype... ?
        #
        dt = np.dtype(dtype)
        return dt.type(value.Value)

    def create(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        vendor_name = self.get_option("factory.vendor_name")
        product_name = self.get_option("factory.product_name")
        product_version = self.get_option("factory.product_version")
        self._testbench = TestbenchProvider().get_testbench(vendor_name, product_name, product_version)

    def disconnect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Disconnect the port
        """
        with log_port_lifecycle(_logger, self, "disconnect"):
            if self.origin is None:
                raise exceptions.PortStateError("Cannot disconnect XIL Port. Port is not yet created.")
            self.origin.Disconnect()

    def release(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Release and dispose the port.
        """
        with log_port_lifecycle(_logger, self, "release"):
            if self.origin is None:
                raise exceptions.PortStateError("Cannot release XIL Port. Port is not yet created.")
            if self.state >= PortState.CONNECTED:
                self.disconnect()
            try:
                self.origin.Dispose()
            finally:
                # Reset internal member to provide correct port state.
                self._port = None

    @property
    def testbench(self) -> typing.Any:  # noqa: ANN401 # any built-in Python data type
        """
        Get the underlying XIL API testbench object.
        """
        if self._testbench is None:
            raise exceptions.PortError("Internal Error: XIL API testbench not created.")
        return self._testbench


class XilApiBaseCapture(AbstractCapture):
    """
    Common intermediate implementation of XIL API Captures.
    This is the common (still abstract) base class for `ModelCapture` and `ECUCapture`.
    """

    def __init__(self, port: AbstractPort, raster_name: str | None = None) -> None:
        if not isinstance(port, XilApiBasePort):
            raise ValueError("Port provided to XILCapture has to be a XILAPI Port")

        self._port: XilApiBasePort = port

        # If no raster_name is provided, take the first one...
        self._raster_name: str = raster_name if raster_name is not None else port.origin.TaskNames[0]
        try:
            self._capture = self.port.origin.CreateCapture(self._raster_name)
        except Exception as err:
            raise exceptions.CaptureError(
                f"Failed to create XIL API '{self._port.name}' port capture with '{self._raster_name}' raster. :: {exceptions.format_exc(err)}",
            ) from err

        self._capture_writer = None
        self._capture_result = None

        self._variables: list[FrameworkVariable] = []
        self._mf4_filepath = None

    @property
    def datafile_path(self) -> pathlib.Path | None:
        """
        Returns the configured path to the mf4 capture data file.
        None if not configured.
        """
        return self._mf4_filepath

    @datafile_path.setter
    def datafile_path(self, value: os.PathLike[str] | str) -> None:
        """
        Path of capture result mf4 file (optional)
        """
        p = pathlib.Path(value)
        if not p.suffixes:
            p = p.with_suffix(".mf4")
        elif p.suffix.lower() != ".mf4":
            raise exceptions.CaptureError("Expected filename with .mf4 suffix")
        self._mf4_filepath = p

    @property
    def variables(self) -> list[FrameworkVariable]:
        """
        Collection of alias identifier to capture
        """
        return self._variables

    @variables.setter
    def variables(self, value: typing.Iterable[FrameworkVariable | str]) -> None:
        """
        Collection of alias identifer to capture
        """
        variable_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
        reg = Registry()

        # create list of FrameworkVariabkes from argument, will be stored if setting to XIL origin succeeds
        fw_variables = [
            item if isinstance(item, FrameworkVariable) else reg.get_framework_variable(item) for item in value
        ]

        # Ceate XIL API VariableRef instances
        xil_variable_refs = [
            self._create_variable_reference(Registry().get_port_variable(fw_variable).id)
            for fw_variable in fw_variables
        ]

        self.origin.Variables2 = Array[variable_ref.IVariableRef](xil_variable_refs)
        self._variables = fw_variables

    @property
    def raster_name(self) -> str | None:
        """
        Task name for capture process.
        If no task_name is provided it is up to the implementation to choose one.
        For XIL API ports the first out of the list available rasters for that port is choosen.
        """
        return self._raster_name

    @raster_name.setter
    def raster_name(self, value: str) -> None:
        """
        Set the capture task/raster.
        For XIL API ports it cannot be changed if the capture is already created.
        """
        raise exceptions.CaptureError("For XIL API Captures the `raster_name` cannot be changed.")

    @property
    def origin(self) -> typing.Any:  # noqa: ANN401 # unknown 3rd party object
        """
        Get the underlying XIL API Capture object.
        """
        return self._capture

    @property
    def port(self) -> XilApiBasePort:
        """
        Get the corresponding port object.
        """
        return self._port

    @property
    def state(self) -> CaptureState:
        if self._capture is None:
            return CaptureState.RELEASED

        # NOTE: the numbers are differently ordered as for ma_port
        state = int(self._capture.State)
        if state == 0:  # eCONFIGURED
            return CaptureState.CONFIGURED
        if state == 1:  # eACTIVATED
            return CaptureState.ACTIVATED
        if state == 2:  # eRUNNING
            return CaptureState.RUNNING
        if state == 3:  # eFINISHED
            return CaptureState.FINISHED
        raise exceptions.CaptureStateError(
            f"Unable to determine XIL API Capture state. Retrieved state unknown: {state}",
        )

    @property
    def duration(self) -> float:
        """
        Get the duration of finished capture in seconds.
        """
        return 0.0

    def release(self) -> None:
        """
        Call dispose of XIL capture and release member
        """
        if self._capture is not None:
            self._capture.Dispose()

        self._capture = None

    def __del__(self) -> None:
        self.release()
        self._capture_result = None
        self._port = None

    def start(self) -> None:
        """
        start the model access port capture
        """
        capturing_factory = self.port.testbench.CapturingFactory
        if self.datafile_path:
            writer = capturing_factory.CreateCaptureResultMDFWriterByFileName(os.fspath(self.datafile_path))
        else:
            writer = capturing_factory.CreateCaptureResultMemoryWriter()

        if self.port.state <= PortState.STARTED:
            _logger.warning(
                "start %s: The corresponding %s is not started, but in %s state",
                self.__class__.__name__,
                self.port,
                self.port.state.name,
            )

        self.origin.Start(writer)

    def stop(self) -> None:
        """
        stop the capture and store capture result
        """
        self.origin.Stop()

        self._prepare_capture_result()

    def _create_value_repr(self, value_rep: str) -> None:
        """
        Create an ASAM value representation item
        """
        # TODO Support of raw/physical values in general. In special remove strings here
        variable_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
        if value_rep and value_rep.upper() == "ERAWVALUE":
            return variable_ref.Enum.ValueRepresentation.eRawValue
        return variable_ref.Enum.ValueRepresentation.ePhysicalValue

    def _create_variable_reference(self, test_bench_path: str) -> typing.Any:
        """
        Create a ASAM.XIL.VariableReference item
        """
        return self.port.testbench.VariableRefFactory.CreateGenericVariableRef(
            test_bench_path,
            self._create_value_repr("ePhysicalValue"),
        )

    def _prepare_capture_result(self) -> None:
        """
        Post processing step after capture to prepare capture result member.
        """
        # Capturing has finished.
        # If mf4 data has been captured open storage file for capture result item.
        if self.datafile_path:
            if not self.datafile_path.exists():
                raise exceptions.CaptureError(
                    f"Cannot access captured data from {self.port}. Datafile path does not exist: {self.datafile_path}",
                )

            self._capture_result = self.port.testbench.CapturingFactory.CreateCaptureResult()
            reader = self.port.testbench.CapturingFactory.CreateCaptureResultMDFReaderByFileName(
                os.fspath(self.datafile_path),
            )
            # Open the mf4 file for capture result. CaptureResult than ready to extract single signals.
            self._capture_result.Open(reader)

        # In case of memory writer, get capture result from internal xil capture.
        else:
            self._capture_result = self.origin.CaptureResult

        if not self._capture_result:
            raise exceptions.CaptureError(
                f"Preparation of capture result of port '{self.port.name}' failed. Capture result is not set.",
            )

    def get_signal(self, variable: FrameworkVariable | str) -> Series:
        """
        Get signal from captures measured data by alias name.
        """
        port_variable = Registry().get_port_variable(variable)
        testbench_path = port_variable.id

        # Get signal from capture result
        if self._capture_result:
            var_ref = importlib.import_module("ASAM.XIL.Interfaces.Testbench.Common.VariableRef")
            rep = var_ref.Enum.ValueRepresentation.ePhysicalValue

            if not self._capture_result.SignalGroups:
                raise exceptions.CaptureError(
                    f"Cannot extract signal '{variable}' with path '{testbench_path}' from capture result of port '{self.port.name}'. Capture result contains no signal groups.",
                )

            for cap_sig_group in self._capture_result.SignalGroups:
                for sig_info in cap_sig_group.SignalInfos:
                    if sig_info.Name == testbench_path:
                        variable = self.port.testbench.VariableRefFactory.CreateGenericVariableRef(testbench_path, rep)

                        yValue = list(cap_sig_group.GetScalarSignalValues(variable).Value)
                        xValue = list(cap_sig_group.GetTimestamps(rep).Value)
                        return Series(yValue, index=xValue)
                raise exceptions.CaptureError(
                    f"Cannot extract signal '{variable}' with path '{testbench_path}' from capture result of port '{self.port.name}'. Capture result contains no such testbench path.",
                )

        raise exceptions.CaptureError(
            f"Cannot extract signal '{variable}' with path '{testbench_path}' from capture result of port '{self.port.name}'. Capture result is not set.",
        )

    def get_data_frame(self) -> DataFrame:
        """
        Get all captured data as pandas.DataFrame.
        """
        if self._capture_result:
            data_frame = DataFrame({str(fw_var): self.get_signal(fw_var) for fw_var in self.variables})
            data_frame.index.name = self.raster_name
            return data_frame

        raise exceptions.CaptureError(
            f"Cannot get data_frame from capture result of port {self.port.name}. Capture result is not set.",
        )

    def __getitem__(self, key: str | FrameworkVariable) -> Series:
        return self.get_signal(key)


class TestbenchProvider:
    _openta_testbench_provider_instance: typing.ClassVar[typing.Optional["TestbenchProvider"]] = None
    _assembly_token = {"win32": {"2.2.0": "bf471dff114ae984"}, "linux": {"2.2.0": "f9604847d8afbfbb"}}

    def __new__(cls) -> "TestbenchProvider":
        if cls._openta_testbench_provider_instance is None:
            cls._openta_testbench_provider_instance = super().__new__(cls)
            cls._openta_testbench_provider_instance._initialized = False
        return cls._openta_testbench_provider_instance

    def __init__(self) -> None:
        if not self._initialized:
            self._initialized = True
            self.xil_version: str | None = None
            self._testbench_factory: typing.Any | None = None
            self._testbenches: dict[tuple[str, str, str], typing.Any] = {}
            self.load_assemblies()
            self.create_testbench_factory()

    def load_assemblies(self, xil_version: str = "2.2.0") -> None:
        _logger.info(
            "load ASAM testbench factory assemblies for XIL version: %s",
            xil_version,
        )
        # FIXME: Should not be done here I guess
        if sys.platform == "linux":
            sys.path.append("/opt/dspace/xilapi2024a/Testbench/Main/bin")

        xil_tb_fact = f"ASAM.XIL.Implementation.TestbenchFactory, Version={xil_version}.0, Culture=neutral, PublicKeyToken={self._assembly_token[sys.platform][xil_version]}"
        xil_interfaces = f"ASAM.XIL.Interfaces, Version={xil_version}.0, Culture=neutral, PublicKeyToken={self._assembly_token[sys.platform][xil_version]}"
        # TODO: version specific
        xil_ext_interfaces = "dSPACE.XIL.Testbench.ExtendedInterfaces, Version=22.2.0.0, Culture=neutral, PublicKeyToken=f9604847d8afbfbb"

        # Load ASAM assemblies from the global assembly cache (GAC).
        clr.AddReference(xil_tb_fact)
        clr.AddReference(xil_interfaces)
        clr.AddReference(xil_ext_interfaces)

        # Register XIL API encoder
        clr.AddReference(
            str(resources.files("openta.data.bin").joinpath("dSPACE.AutomationDesk.XILAPIPyObjectEncoder22.dll")),
        )
        encoder22 = importlib.import_module("dSPACE.AutomationDesk.XILAPIPyObjectEncoder22")
        if encoder22:
            encoder22.XILAPIPyObjectEncoderManager22.RegisterPyObjectEncoders()

    def create_testbench_factory(self) -> None:
        tb_module = importlib.import_module("ASAM.XIL.Implementation.TestbenchFactory.Testbench")
        self._testbench_factory = tb_module.TestbenchFactory()

    def get_testbench(self, vendor_name: str, product_name: str, product_version: str) -> typing.Any:
        key = (vendor_name, product_name, product_version)
        if self._testbench_factory is None:
            self.create_testbench_factory()
        if key not in self._testbenches:
            self._testbenches[key] = self._testbench_factory.CreateVendorSpecificTestbench(
                vendor_name,
                product_name,
                product_version,
            )
        return self._testbenches[key]
