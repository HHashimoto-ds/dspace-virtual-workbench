import logging
import typing

import numpy as np

from openta.automation import controldesk
from openta.common import exceptions
from openta.common.variables import PortVariable
from openta.ports.abc import AbstractCapture, AbstractPort, PortState
from openta.ports.logging import log_port_lifecycle

_logger = logging.getLogger(__name__)


class ControlDeskPort(AbstractPort):
    """
    A basic Port implementation for dSPACE ControlDesk,
    supporting read, write and capturing of variables.
    """

    def __init__(
        self,
        name: str,
        order: int,
        target_state: PortState,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, order, target_state, config)
        self._prog_id = self.get_option("prog_id", default=None)
        self._controldesk: typing.Any = None

    @property
    def state(self) -> PortState:
        if self._controldesk is None:
            return PortState.RELEASED
        if not self._controldesk.ActiveExperiment:
            return PortState.CREATED
        if self._controldesk.CalibrationManagement.State == 0:
            return PortState.CONNECTED
        if self._controldesk.CalibrationManagement.State == 1:
            return PortState.STARTED
        raise ValueError(f"ControlDeskPort({self.name}).state: Unable to determine state :(")

    @property
    def origin(self) -> typing.Any:  # noqa: ANN401 # unknown 3rd party object
        """
        Get the underlying ControlDesk application object.
        """
        if self._controldesk is None:
            raise exceptions.PortStateError(
                f"Cannot provide ControlDesk '{self.name}'. Port is not yet created.",
            )
        return self._controldesk

    def create(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Dispatch Control Desk via COM, but nothing more
        """
        with log_port_lifecycle(_logger, self, "create", "Get ControlDesk COM object."):
            self._controldesk = controldesk.get_application(self._prog_id)

    def connect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Load a project and activate an experiment.
        The `port_config_file` is currently used as project file and
        the to be activated experiment is `experiment` from keyword arguments
        """
        with log_port_lifecycle(_logger, self, "connect", "Open project and experiment."):
            if self.state < PortState.CREATED:
                raise ValueError(
                    f"ControlDeskPort({self.name}): Cannot connect ControlDesk. Port has to be at least CREATED ({PortState.CREATED}) state, but is {self.state}.",
                )

            # OPEN
            project_file = self.get_option("project_file", kwargs, raise_error=True)
            experiment = self.get_option("experiment", kwargs, raise_error=False)
            _logger.debug("connect %s: Project:='%s' Experiment:='%s'.", self, project_file, experiment)
            controldesk.open_experiment(project_file, experiment)

    def start(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Start Online Calibration
        """
        with log_port_lifecycle(_logger, self, "start", "Start ControlDesk online calibration."):
            if self.state != PortState.CONNECTED:
                raise ValueError(
                    f"ControlDeskPort({self.name}): Cannot start. Port has to be in CONNECTED ({PortState.CONNECTED}) state, but is {self.state}.",
                )
            self._controldesk.CalibrationManagement.StartOnlineCalibration()

    def stop(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Stop Online Calibration
        """
        with log_port_lifecycle(_logger, self, "stop", "Stop ControlDesk online calibration."):
            if self.state != PortState.STARTED:
                raise ValueError(
                    f"ControlDeskPort({self.name}): Cannot stop. Port has to be in STARTED ({PortState.STARTED}) state, but is {self.state}.",
                )
            self._controldesk.CalibrationManagement.StopOnlineCalibration()

    def disconnect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        close the current active project
        """
        with log_port_lifecycle(_logger, self, "disconnect", "Close ControlDesk active project."):
            if self.state != PortState.CONNECTED:
                raise ValueError(
                    f"ControlDeskPort({self.name}): Cannot stop. Port has to be in CONNECTED ({PortState.CONNECTED}) state, but is {self.state}.",
                )
            # CLOSE active project, do not save changes
            self._controldesk.ActiveProject.Close(False)

    def release(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Destroy the client COM object
        """
        with log_port_lifecycle(_logger, self, "release", "No Operation (Keep ControlDesk Application alive)"):
            if self.state != PortState.CREATED:
                raise ValueError(
                    f"ControlDeskPort({self.name}): Cannot release. Port has to be in CREATED ({PortState.CREATED}) state, but is {self.state}.",
                )
            self._controldesk = None

    def read(self, variable: PortVariable) -> np.generic:
        """
        Read a value from the given variable
        """
        val = controldesk.read_variable(variable.id, variable.port_id)
        return np.float64(val)

    def write(self, variable: PortVariable, value: np.generic | float | bool | str) -> None:  # noqa: FBT001
        """
        Write the given value to variable.
        The given value object is converted to a XIL API BaseValue according to dtype of PortVariable.
        """
        _logger.debug("write %s: '%s' := %s", self, variable, value)
        controldesk.write_variable(variable.id, value, variable.port_id)

    def create_capture(self, **kwargs: typing.Any) -> AbstractCapture:  # noqa: ANN401 # unknown keyword args by design
        """
        Create ControlDesk Capture
        """
        return ControlDeskCapture(self, **kwargs)


class ControlDeskCapture(controldesk.Recorder):
    """
    An implemenatation of AbstractCapture for the ControlDesk port.
    The capture is based on the `openta.automation.controldesk.Recorder` object,
    and merely adds support for the associated port.
    """

    def __init__(self, port: AbstractPort, raster_name: str | None = None) -> None:
        """
        Initialize the capture.
        If a raster_name is provided, it is used as raster for all added signals,
        otherwise the default raster will be chosen by ControlDesk.
        """
        super().__init__([], raster_name)
        self._port = port

    @property
    def port(self) -> AbstractPort:
        """
        Get the underlying ControlDesk Recorder COM object.
        """
        return self._port

    def start(self) -> None:
        """
        Start the capture process
        """
        if self.port.state <= PortState.STARTED:
            _logger.warning(
                "start %s: The corresponding %s is not started, but in %s state",
                self.__class__.__name__,
                self.port,
                self.port.state.name,
            )
        super().start()
