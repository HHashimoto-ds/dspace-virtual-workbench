import importlib
import logging
import typing

from openta.common import exceptions
from openta.common.variables import PortVariable
from openta.ports.abc import PortState
from openta.ports.logging import log_port_action_debug, log_port_lifecycle
from openta.ports.xilapi_base import XilApiBaseCapture, XilApiBasePort

if typing.TYPE_CHECKING:  # pragma: no cover
    import numpy as np

_logger = logging.getLogger(__name__)


class DsEcuCapture(XilApiBaseCapture):
    """
    A dSPACE XIL API ECUPort specific capture object.
    Start and stop trigger are not supported.
    """

    def __init__(self, port: "DsEcuPort", raster_name: str | None = None) -> None:
        """
        Create port specific capture.
        Note that this has to stops a measurement on the ecuport.
        """
        # duck typing for dSPACE XIL API ECUPort (M & C)
        if not (hasattr(port, "start_measurement") or hasattr(port, "stop_measurement")):
            raise exceptions.CaptureError(
                f"Cannot create ECUCapture for '{port}' port instance. Expected a dSPACE XIL API ECUPort.",
            )
        # port must not be in measurement mode, when capture is created
        # note that the port is passed to supers constructor, thus we use the parameter directly here
        port.stop_measurement()
        super().__init__(port, raster_name)

    def set_start_trigger(self, condition: str, delay: float | None = None) -> None:
        """
        Configure the start trigger condition of this capture.
        Only ConditionWatcher supported.
        """
        raise NotImplementedError("Trigger is not supported on ECUCapture.")

    def set_stop_trigger(self, condition_or_duration: str | float, delay: float | None = None) -> None:
        raise NotImplementedError("Trigger is not supported on ECUCapture.")

    def start(self) -> None:
        """
        start the capture.
        For ECU port the measurement has to be started beforehand.
        """
        self.port.start_measurement()
        super().start()


class DsEcuPort(XilApiBasePort):
    def __init__(
        self,
        name: str,
        order: int,
        target_state: PortState,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, order, target_state, config)

    @property
    def origin(self) -> typing.Any:
        """
        Get the underlying XIL API Port object.
        This returns the pythonnet object wrapped by this ECUPort
        """
        if self._port is None:
            raise exceptions.PortStateError("Cannot provide XIL ECUPort. Port is not yet created.")
        return self._port

    @property
    def state(self) -> PortState:
        if self._port is None:
            return PortState.RELEASED

        # TODO: use xil api enums ???
        # NOTE: the numbers are differently ordered as for maport
        state = int(self._port.CalibrationState)
        if state == 0:  # eCALIBRATION_DISCONNECTED
            return PortState.CREATED
        if state == 2:  # eCALIBRATION_ONLINE
            return PortState.STARTED
        if state == 1:  # eCALIBRATION_OFFLINE
            return PortState.CONNECTED
        raise exceptions.PortStateError(f"Unable to determine ECUPort state. Retrieved unknown state: {state}")

    def create(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        with log_port_lifecycle(_logger, self, "create"):
            # call super create(), to create the testbench beforehand
            super().create()

            # NOTE the assemblies have to be already registered
            ext_int = importlib.import_module("dSPACE.XIL.Testbench.ExtendedInterfaces.Testbench")
            self._port = ext_int.IDSTestbench(self._testbench).ECUPortFactory.CreateECUPort(self.name)

    def connect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Load port configuratio file and configure port.
        """
        with log_port_lifecycle(_logger, self, "connect", "Configure the XIL port."):
            port_config_file = self.get_option(["port_config_file", "PortConfigurationFile"], kwargs, raise_error=True)
            _logger.debug("connect %s: port_config_file := '%s'", self, port_config_file)

            # load configuration file and configre the port
            try:
                port_config = self.origin.LoadConfiguration(port_config_file)
            except Exception as err:
                raise exceptions.PortConfigError(
                    f"Cannot load config file '{port_config_file}'. :: {exceptions.format_exc(err)}",
                ) from err

            try:
                self.origin.Configure(port_config)
            except Exception as err:
                raise exceptions.PortConfigError(
                    f"Cannot configure XIL ECUPort. :: {exceptions.format_exc(err)} ",
                ) from err

    def start(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        start the port in order to work with it.
        """
        with log_port_lifecycle(_logger, self, "start", "Start Calibration."):
            loading_type = self.get_option(["loading_type", "LoadingType"], kwargs, default="eUPLOAD")
            _logger.debug("%s start: loading_type=%s", self, loading_type)

            if self.state == PortState.STARTED:
                _logger.warning("start %s: Skipped! Port is already started.", self)
                return

            # start calibration with configured loading type
            self.start_calibration(loading_type)

    def stop(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        stop the port, this is the counterpart of start.
        """
        with log_port_lifecycle(_logger, self, "stop", "Stop Measurement and Calibration."):
            if self.state != PortState.STARTED:
                _logger.warning("stop %s: Skipped! Port is not started.", self)
                return

            # Stop a running measurement
            self.stop_measurement()

            # Stop active calibration
            self.stop_calibration()

    def read(self, variable: PortVariable) -> "np.generic":
        """
        Read the physical value from given variable.
        """
        # TODO: Use Read2 to support physical or raw value
        value = self.origin.Read(variable.id)
        return self._create_numpy_value(value, variable.dtype)

    def write(self, variable: PortVariable, value: typing.Union["np.generic", float, bool, str]) -> None:
        """
        Write the given value to variable.
        The given value object is converted to a XIL API BaseValue according to dtype of PortVariable.
        """
        _logger.debug("write %s: %s := %s", self, variable, value)
        # TODO: Use Write2
        # You can use this method only in the eCALIBRATION_ONLINE state, otherwise the eCOMMON_INVALID_STATE exception occurs.
        converted_value = self._create_base_value(value, variable.dtype)
        return self.origin.Write(variable.id, converted_value)

    def create_capture(self, **kwargs: typing.Any) -> DsEcuCapture:  # noqa: ANN401 # unknown keyword args by design
        """
        Create ECUCapture, all provided keyword arguments are passed to the cpature object.
        """
        return DsEcuCapture(self, **kwargs)

    def start_calibration(self, loading_type: str = "eUPLOAD") -> None:
        """
        Start the calibration of ECU port.
        @params: loading_type - str
            "eUPLOAD"   Transfers values from the ECU to the application.
            "eDOWNLOAD" Transfers values from the application to the ECU.
        """
        with log_port_action_debug(_logger, self, "start calibration"):
            # determine LoadingType
            enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")

            if loading_type.upper() == "EUPLOAD":
                ltype = enums.LoadingType.eUPLOAD
            elif loading_type.upper() == "EDOWNLOAD":
                ltype = enums.LoadingType.eDOWNLOAD
            else:
                raise exceptions.PortConfigError(
                    f"Cannot start ECUPort. Unknown LoadingType {loading_type}. Must be one of 'eUPLOAD' or 'eDOWNLOAD'.",
                )

            # Start Calibration
            enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
            if self.origin.CalibrationState != enums.ECUPortCalibrationState.eCALIBRATION_ONLINE:
                self.origin.StartOnlineCalibration(ltype)
            else:
                _logger.debug("%s: start calibration: Skipped! Port already in eCALIBRATION_ONLINE state")

    def stop_calibration(self) -> None:
        """
        Stop the calibration of ECU port.
        """
        with log_port_action_debug(_logger, self, "stop calibration"):
            enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
            if self.origin.CalibrationState == enums.ECUPortCalibrationState.eCALIBRATION_ONLINE:
                self.origin.StopOnlineCalibration()
            else:
                _logger.debug("%s: stop calibration: Skipped! XIL port not in eCALIBRATION_ONLINE state")

    def start_measurement(self) -> None:
        """
        Ensure a running measurement of ecu port.
        """
        with log_port_action_debug(_logger, self, "start measurement"):
            enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
            if self.origin.MeasurementState == enums.ECUPortMeasurementState.eMEASUREMENT_STOPPED:
                # Start measurement at xil ecuport
                self.origin.StartMeasurement()

            elif self.origin.MeasurementState == enums.ECUPortMeasurementState.eMEASUREMENT_DISCONNECTED:
                raise exceptions.PortError(
                    f"Cannot start ECUPort measuring. Port '{self.name}' has to be configured first.",
                )
            else:
                _logger.debug("%s: start measurement: Skipped! XIL port not in eMEASUREMENT_STOPPED state")

    def stop_measurement(self) -> None:
        """
        Stop the measurement of ECU port.
        """
        with log_port_action_debug(_logger, self, "start measurement"):
            enums = importlib.import_module("dSPACE.XIL.Testbench.ECUPort.Interfaces.Enums")
            if self.origin.MeasurementState == enums.ECUPortMeasurementState.eMEASUREMENT_RUNNING:
                self.origin.StopMeasurement()
            else:
                _logger.debug("%s: stop measurement: Skipped! XIL port not in eMEASUREMENT_RUNNING state")
