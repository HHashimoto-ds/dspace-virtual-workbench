import logging
import typing

from openta.automation import modeldesk
from openta.common import exceptions
from openta.common.variables import PortVariable
from openta.ports.abc import AbstractCapture, AbstractPort, PortState
from openta.ports.logging import log_port_lifecycle

if typing.TYPE_CHECKING:
    import numpy as np

_logger = logging.getLogger(__name__)


class ModelDeskPort(AbstractPort):
    """
    A basic Port implementation for dSPACE ModelDesk.
    NOTE, that the port does not support read, write and capturing of variables,
    but only implements the "life cycle" interface, such that it possible to
    start and configure the dSPACE ModelDesk Application via the test environment yaml file.
    """

    def __init__(
        self,
        name: str,
        order: int,
        target_state: PortState,
        config: dict[str, typing.Any],
    ) -> None:
        super().__init__(name, order, target_state, config)
        self._prog_id = self.get_option("prog_id", default="ModelDesk.Application")
        self._modeldesk: typing.Any = None

    @property
    def state(self) -> PortState:
        if self._modeldesk is None:
            return PortState.RELEASED
        if not self._modeldesk.ActiveProject:
            return PortState.CREATED
        if not self._modeldesk.ActiveProject.ActiveExperiment:
            return PortState.CREATED
        if self._modeldesk.ActiveProject.ActiveExperiment:
            return PortState.CONNECTED
        raise ValueError(f"ModelDeskPort({self.name}).state: Uhmph. Unable to determine state :(")

    @property
    def origin(self) -> typing.Any:  # noqa: ANN401 # unknown 3rd party object
        """
        Get the underlying ModelDesk application object.
        """
        if self._modeldesk is None:
            # TODO
            raise exceptions.PortStateError(
                f"Cannot provide ModelDesk '{self.name}'. Port is not yet created.",
            )
        return self._modeldesk

    def create(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Dispatch ModelDesk via COM, but nothing more.
        """
        with log_port_lifecycle(_logger, self, "create", "Get ModelDesk COM object"):
            self._modeldesk = modeldesk.get_application(self._prog_id)

    def connect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Load a project and activate an experiment.
        The `project_file` and `experiment` from test environment configuration are used.
        """
        with log_port_lifecycle(_logger, self, "connect", "Open project and experiment."):
            if self.state < PortState.CREATED:
                raise ValueError(
                    f"ModelDeskPort({self.name}): Cannot connect. Port has to be at least CREATED ({PortState.CREATED}) state, but is {self.state}.",
                )

            project_file = self.get_option("project_file", kwargs, raise_error=True)
            experiment = self.get_option("experiment", kwargs, raise_error=False)
            _logger.debug("connect %s: Project:='%s' Experiment:='%s'.", self, project_file, experiment)

            # OPEN
            modeldesk.open_experiment(project_file, experiment)

    def start(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Does nothing because port does not support "started"
        """
        with log_port_lifecycle(_logger, self, "start", "No Operation!"):
            pass

    def stop(self, **kwargs: typing.Any) -> None:  # noqa: ANN401 # unknown keyword args by design
        """
        Does nothing because port does not support "started"
        """
        with log_port_lifecycle(_logger, self, "stop", "No Operation!"):
            pass

    def disconnect(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        close the current active project
        """
        with log_port_lifecycle(_logger, self, "disconnect", "Close ModelDesk active project."):
            if self.state != PortState.CONNECTED:
                raise ValueError(
                    f"ModelDeskPort({self.name}): Cannot stop. Port has to be in CONNECTED ({PortState.CONNECTED}) state, but is {self.state}.",
                )
            # TODO keep open or close project?
            # CLOSE active project, do not save changes
            self._modeldesk.ActiveProject.Close(False)

    def release(self, **kwargs: typing.Any) -> None:  # noqa: ANN401, ARG002 # unknown keyword args by design
        """
        Destroy the client COM object
        """
        with log_port_lifecycle(_logger, self, "release", "No Operation! (Keep ModelDesk Application alive)"):
            if self.state != PortState.CREATED:
                raise ValueError(
                    f"ModelDeskPort({self.name}): Cannot release. Port has to be in CREATED ({PortState.CREATED}) state, but is {self.state}.",
                )
            self._modeldesk = None

    def read(self, variable: PortVariable) -> "np.generic":
        """
        Reading of `PortVariables` is not supported.
        Scenario parameters can be written on `Scenario.download()`.
        """
        raise NotImplementedError(
            "ModelDesk Port currently does not support variables. Scenario parameters can be written on `Scenario.download()`. For realtime variables, also configure an MAPort.",
        )

    def write(self, variable: PortVariable, value: "np.generic | float | bool | str") -> None:
        """
        Writing of `PortVariables` is not supported.
        Scenario parameters can be written on `Scenario.download()`.
        """
        raise NotImplementedError(
            "ModelDesk Port currently does not support variables. Scenario parameters can be written on `Scenario.download()`. For realtime variables, also configure an MAPort.",
        )

    def create_capture(self, **kwargs: typing.Any) -> AbstractCapture:  # noqa: ANN401 # unknown keyword args by design
        """
        Capturing variables from the ModelDesk port is not supported.
        """
        raise NotImplementedError("ModelDesk Port does not support capturing of variables.")
