"""
This modules provides utility functions for consistent logging of port lifecycle management
and other (presumably long running) port actions.
The defined context managers should ony be used to log port actions.

Two context managers are defined for sophisticated logging:
- `log_port_lifecycle`, to log life cycle management actions and state transitions.
- `log_port_action_debug`, to log other presumably long runnning actions, but only at debug level.
"""

import contextlib
import logging
import typing

import openta.common.exceptions
import openta.ports.abc


@contextlib.contextmanager
def log_port_lifecycle(
    logger: logging.Logger,
    port: openta.ports.abc.AbstractPort,
    method: str,
    message: str | None = None,
    log_exc: bool = True,  # noqa: FBT001, FBT002
) -> typing.Generator[None, None, None]:
    """
    Context manager to log common life cycle management actions
    of derivates of `AbstractPort`.

    This method logs first an *info*, consisting of the specified method and port identification.
    If an exception occured in the body it is augmented (`Exception.add_note()`) with context information,
    and optionally logged.
    In the end, the completion and current state of the port is logged with debug level.

    use e.g. as follows:
    ```
    def create(self, **kwargs: typing.Any) -> None:
        with _logging.log_port_lifecycle(_logger, self, "create", "Get ControlDesk COM object."):
            self._controldesk = controldesk.get_application(self._prog_id)
    ```

    Args:
        logger (logging.Logger); the logger to use for logging,
            because the name of the logger is (by default) the module issuing the log.
        port (AbstractPort): the managed port
        method (str): the corrosponding lifecycle method, e.g. "create" or "start"
        message (str, optional): An optional message for the log
        log_exc (bool, optional): wether to log an occured exception. Defaults to `True`.

    Yields:
        None: This context manager does not yield any value,
        it is simply used for logging entry and exit of code block
    """
    if message:
        logger.info("%s %s: %s", method, port, message)
    else:
        logger.info("%s %s", method, port)
    try:
        yield
    except Exception as err:
        err.add_note(f"Failed to {method} {port}")
        if log_exc:
            with contextlib.suppress(Exception):
                logger.warning("%s %s: Exception occured: %s", method, port, openta.common.exceptions.format_exc(err))
        raise
    else:
        logger.debug("%s %s: completed. Current state is %s", method, port, port.state.name)


@contextlib.contextmanager
def log_port_action_debug(
    logger: logging.Logger,
    port: openta.ports.abc.AbstractPort,
    action: str,
    message: str | None = None,
    log_exc: bool = True,  # noqa: FBT001, FBT002
) -> typing.Generator[None, None, None]:
    """
    Context manager for debug logging
    of actions of derivates of `AbstractPort`.
    Similar to `log_port_lifecycle`.

    Args:
        logger (logging.Logger); the logger to use for logging,
            because the name of the logger is (by default) the module issuing the log.
        port (AbstractPort): the port, doing the action
        action (str): the corrosponding action, e.g. "start online calibration"
        message (str, optional): An optional message for the log
        log_exc (bool, optional): wether to log an occured exception. Default to `True`.

    Yields:
        None: This context manager does not yield any value,
            it is simply used for logging entry and exit of code block
    """
    if message:
        logger.debug("%s: %s: %s", port, action, message)
    else:
        logger.debug("%s: %s", port, action)
    try:
        yield
    except Exception as err:
        err.add_note(f"{port} failed to {action}")
        if log_exc:
            with contextlib.suppress(Exception):
                logger.warning("%s: %s: Exception occured: %s", port, action, openta.common.exceptions.format_exc(err))
        raise
    else:
        logger.debug("%s: %s completed. Current port state is %s", port, action, port.state.name)
