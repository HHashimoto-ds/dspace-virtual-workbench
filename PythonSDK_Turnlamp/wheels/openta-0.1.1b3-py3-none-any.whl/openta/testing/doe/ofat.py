"""
One-Factor-At-a-Time (OFAT) implementation module.

This module provides functions for generating test cases using the OFAT method,
a Design of Experiments (DoE) approach where each test case varies exactly one
parameter from its default value while keeping all other parameters constant.

OFAT is useful for:
- Isolating the impact of individual parameters on system behavior
- Identifying which parameters have the most significant effects
- Debugging issues related to specific parameter changes
- Creating targeted test coverage with minimal test cases

While OFAT doesn't capture parameter interactions like full factorial designs,
it provides a good balance between test coverage and test case count.
"""

from typing import Any


def ofat_variation(
    param_dict: dict[str, list[Any]],
    defaults: dict[str, Any] | None = None,
    include_all_defaults: bool = True,
) -> tuple[list[str], list[Any]]:
    """
    Implements One-Factor-At-a-Time (OFAT) test case generation.
    Varies one parameter at a time while keeping others at default values.

    Args:
        param_dict: dictionary mapping parameter names to lists of values to test
        defaults: dictionary mapping parameter names to default values.
                 If None, uses the first value from each parameter's list
        include_all_defaults: Whether to include a test case with all defaults

    Returns:
        tuple containing:
            - list of parameter names
            - list of test cases, where each test case is a tuple of parameter values

    Example:
        ```python
        param_names, test_cases = ofat_variation({
            'x': [1, 2, 3],
            'y': ['a', 'b'],
            'z': [True, False]
        })
        ```
    """
    if not param_dict:
        raise ValueError("param_dict cannot be empty")

    # Set defaults to first value of each parameter if not provided
    if defaults is None:
        defaults = {param: values[0] for param, values in param_dict.items()}

    # Validate that all parameters have defaults
    missing_defaults = set(param_dict.keys()) - set(defaults.keys())
    if missing_defaults:
        raise ValueError(f"Missing defaults for parameters: {missing_defaults}")

    param_names = list(param_dict.keys())
    test_cases: list[tuple[Any]] = []

    # Add all-defaults case if requested
    if include_all_defaults:
        all_defaults_case = tuple(defaults[param] for param in param_names)
        test_cases.append(all_defaults_case)

    # For each parameter, create test cases varying that parameter
    for param_to_vary in param_names:
        for value in param_dict[param_to_vary]:
            # Skip if this value is the same as default (avoid duplicates)
            if value == defaults[param_to_vary]:
                continue

            case = tuple(value if param == param_to_vary else defaults[param] for param in param_names)
            test_cases.append(case)

    # Remove duplicates while preserving order
    seen: set[tuple[Any]] = set()
    unique_cases: list[tuple[Any]] = []
    for case in test_cases:
        if case not in seen:
            seen.add(case)
            unique_cases.append(case)

    return param_names, unique_cases
