import collections.abc
import logging
import types
import typing

import allure

from openta.common import exceptions
from openta.common.config.registry import Registry
from openta.common.variables import FrameworkVariable
from openta.common.variables_base import VariableReference
from openta.ports.abc import AbstractPort, PortState

_logger = logging.getLogger(__name__)


class _PortCollection(collections.abc.Mapping[str, AbstractPort]):
    """
    Registry of all configured ports.
    A port is accessible by its configured identifier.
    """

    def __getattr__(self, port_id: str) -> AbstractPort:
        """
        Look up a Port by name in dotted access notation.
        """
        return Registry().get_port(port_id)

    def __getitem__(self, port_id: str) -> AbstractPort:
        """
        Look up a Port by given port_id.
        """
        return Registry().get_port(port_id)

    def __setitem__(self, port_id: str, value: AbstractPort) -> None:
        raise TypeError(f"Cannot set attribute '{port_id}'. The port list is read only")

    def __len__(self) -> int:
        """
        get the number of ports.
        """
        return Registry().get_port_count()

    def __contains__(self, key: object) -> bool:
        try:
            if isinstance(key, str):
                Registry().get_port(key)
            elif isinstance(key, AbstractPort):
                p = Registry().get_port(key.name)
                return p == key
            else:
                raise TypeError(
                    f"Containment check for port not supported for specified key `{key!r}` of type: {type(key)}. Only str and port objects are supported.",
                )
        except exceptions.NotFoundError:
            return False
        return True

    def __iter__(self) -> typing.Iterator[str]:
        for p in Registry().get_ports():
            yield p.name

    def __reversed__(self) -> typing.Iterator[str]:
        for p in reversed(Registry().get_ports()):
            yield p.name


class _VariableCollection(collections.abc.Mapping[str, FrameworkVariable]):
    """
    List of all defined Framework variables.
    Framework variables can be retrieved by dotted access or random access
    if framework labels are not valid python identifiers.
    """

    def __repr__(self) -> str:
        return str(self)

    def __str__(self) -> str:
        return "FrameworkVariables"

    def __getattr__(self, key: str) -> FrameworkVariable:
        """
        Look up a FrameworkVariable by name in dotted access notation.
        """
        return Registry().get_framework_variable(key)

    def __getitem__(self, key: VariableReference | str) -> FrameworkVariable:
        """
        Look up a FrameworkVariable by name.
        """
        if isinstance(key, VariableReference):
            key = key.id
        return Registry().get_framework_variable(key)

    def __setitem__(self, key: VariableReference | str, value: FrameworkVariable) -> None:
        raise TypeError(f"Cannot set attribute '{key}'. The variable list is read only")

    def __len__(self) -> int:
        # look up number of frameworklabels
        return Registry().get_framework_variable_count()

    def __contains__(self, key: object) -> bool:
        try:
            if isinstance(key, str):
                Registry().get_framework_variable(key)
            elif isinstance(key, VariableReference | FrameworkVariable):
                v = Registry().get_framework_variable(key.id)
                return v == key
            else:
                raise TypeError(
                    f"Containment check for variable not supported for specified key `{key!r}` of type: {type(key)}. Only str and FrameworkVariable objects are supported.",
                )
        except exceptions.NotFoundError:
            return False
        return True

    def __iter__(self) -> typing.Iterator[str]:
        for v in Registry().get_framework_variables():
            yield v.id


class TestEnvironmentAccess:
    """
    Currently used as fixture in pytest to grant access to `vars` and `ports` list.
    """

    # This prevents pytest from collecting this class.
    __test__ = False

    def __enter__(self) -> typing.Self:
        """
        Start/Initialize the Framework as configured
        """
        self.setup()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> bool:
        """
        Shutdown Framework and release ports in reverse order.
        """
        self.teardown()
        return False

    def __init__(self) -> None:
        self._ports = _PortCollection()
        self._framework_labels = _VariableCollection()

    def setup(self) -> None:
        try:
            with allure.step("Setup Ports"):
                _logger.info("Setup Ports")
                for port in Registry().get_ports():
                    port_repr = f"[{port.order}] '{port.name}' {port.__class__.__name__}"

                    if port.state < PortState.CREATED <= port.target_state:
                        _logger.info(f"Setup {port_repr}: Create")
                        port.create()

                    # configure
                    if port.state < PortState.CONNECTED <= port.target_state:
                        _logger.info(f"Setup {port_repr}: Connect/Configure")
                        port.connect()

                    # and start if needed
                    if port.state < PortState.STARTED <= port.target_state:
                        _logger.info(f"Setup {port_repr}: Start")
                        port.start()

        except Exception as err:
            _logger.exception(f"Setup Ports Failed: {exceptions.format_exc(err)}")  # noqa: TRY401
            # Initiate the Tear Down of already set up ports.
            self.teardown()
            raise exceptions.PortError(f"Setup of Ports Failed: {exceptions.format_exc(err)}") from err

    def teardown(self) -> None:
        """
        Shutdown Framework
        """
        with allure.step("Teardown Ports"):
            _logger.info("Teardown Ports")
            error = False
            # Shutdown ports in reverse order
            for port in reversed(Registry().get_ports()):
                port_repr = f"[{port.order}] '{port.name}' {port.__class__.__name__}"
                try:
                    if port.state >= PortState.STARTED:
                        _logger.info(f"Teardown {port_repr}: Stop")
                        port.stop()
                    else:
                        _logger.debug(f"Teardown {port_repr}: Stop Skipped. Port not started.")

                    if port.state >= PortState.CONNECTED:
                        _logger.info(f"Teardown {port_repr}: Disconnect")
                        port.disconnect()
                    else:
                        _logger.debug(f"Teardown {port_repr}: Disconnected Skipped. Port not connected.")

                    if port.state >= PortState.CREATED:
                        _logger.info(f"Teardown {port_repr}: Release")
                        port.release()
                    else:
                        _logger.debug(f"Teardown {port_repr}: Release Skipped. Port not created")
                except Exception as err:
                    error = True
                    _logger.exception(f"Teardown {port_repr} Failed: {exceptions.format_exc(err)}")  # noqa: TRY401
        if error:
            raise exceptions.PortError("Teardown of Ports Failed")

    @property
    def vars(self) -> _VariableCollection:
        return self._framework_labels

    @property
    def ports(self) -> _PortCollection:
        """
        get the collection of all defined FrameworkLabels from active mapping.
        The returned FrameworkLabels collections supports random access [] as well as
        dotted access of named aliases.
        """
        return self._ports
