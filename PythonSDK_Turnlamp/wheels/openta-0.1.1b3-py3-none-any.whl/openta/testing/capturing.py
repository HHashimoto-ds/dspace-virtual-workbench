import collections
import pathlib
import types
import typing
from collections import OrderedDict
from datetime import datetime
from os import PathLike

import pandas as pd
from pandas import DataFrame, Series

from openta.common import exceptions
from openta.common.config.registry import Registry
from openta.ports.abc import AbstractCapture

from ..common.variables import FrameworkVariable

if typing.TYPE_CHECKING:  # pragma: no cover
    from openta.ports.abc import AbstractPort


class Capturing:
    """
    Context Manager to start the capturing of Framework variables.
    A capture is always port specific and thus capturing of variables is limited to a single port.
    The provided `FrameworkVariables` are looked up in the provided mapping,
    and if all map to the same port a corresponding capture is setup.

    Instances of this class can act as context managers, which `start` on entering the context and `stop`
    when the context is exited.

    ```python
    ta.vars.TurnSignalLever = 0

    with Capturing([ta.vars.TurnSignalFrontLeft, ta.vars.TurnSignalFrontRight,]) as capture:
        sleep(1)
        ta.vars..TurnSignalLever = 1
        sleep(1)
        ta.vars..TurnSignalLever = 0

    # assert that left signal is at least once flashing, contains on and off
    assert (capture[ta.vars.TurnSignalFrontLeft] == 1).any()
    assert (capture[ta.vars.TurnSignalFrontLeft] == 0).any()

    # assert that right signal is constant off
    assert (capture.TurnSignalFrontRight == 0).all()
    ```
    """

    def __init__(
        self,
        variables: typing.Iterable[str | FrameworkVariable],
        raster_name: str | None = None,
        start_trigger: str | tuple[str, float] | None = None,
        stop_trigger: str | tuple[str, float] | float | None = None,
        datafile_path: str | PathLike[str] | None = None,
    ) -> None:
        """
        Initialize the capture.

        Args:
            variables: iterable of FrameworkVariables to capture
            raster_name: name of the capturing raster (optional) if omitted the port specific capture may choose one.
            start_trigger: (optional) condition as string or tuple of condition and delay
            stop_trigger: (optional) condition as string or tuple of condition and delay
            datafile_path: (optional)
        """
        # determine port from all defined variables to be used for capturing.
        # For this context manager a single port is assumed, otherwise an exception is raised.
        self._port = self._determine_port(variables)

        # Create port specific capture object.
        # Provide raster_name only as keyword argument if defined
        self._capture: AbstractCapture = (
            self.port.create_capture() if raster_name is None else self.port.create_capture(raster_name=raster_name)
        )

        # Further configure the port specific AbstractCapture implementation

        self._capture.variables = variables

        if datafile_path:
            self._capture.datafile_path = datafile_path

        if start_trigger is not None:
            if isinstance(start_trigger, str):
                self._capture.set_start_trigger(start_trigger, None)
            if isinstance(start_trigger, tuple):
                self._capture.set_start_trigger(start_trigger[0], start_trigger[1])
            else:
                raise exceptions.CaptureError("Failed to create capture, defined start_trigger is not well defined")

        if stop_trigger is not None:
            if isinstance(stop_trigger, str | float):
                self._capture.set_stop_trigger(stop_trigger, None)
            if isinstance(stop_trigger, tuple):
                self._capture.set_stop_trigger(stop_trigger[0], stop_trigger[1])
            else:
                raise exceptions.CaptureError("Failed to create capture, defined start_trigger is not well defined")

    def _determine_port(self, variables: typing.Iterable[FrameworkVariable | str]) -> "AbstractPort":
        """
        From the set of defined FrameworkVariables determine their port,
        and ensure that all map to the same port.
        If so, return it.
        Otherwise raise an exception.

        Note that Capturing is port specific and restricted to a single port.
        """
        # Check all variables belong to same port
        if not variables:
            raise exceptions.CaptureError("Variables list of capture must not be empty")

        # determine all port_ids of mapped variables
        port_names = {Registry().get_port_variable(var).port_id for var in variables}

        if len(port_names) != 1:
            raise exceptions.CaptureError(
                f"Capture support only variables from the same port. The following ports were addressed: {', '.join(port_names)}",
            )

        return Registry().get_port(port_names.pop())

    def __enter__(self) -> typing.Self:
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> bool | None:
        self.stop()
        self.release()

    @property
    def port(self) -> "AbstractPort":
        """
        Get the corresponding openta.common.port.
        """
        return self._port

    @property
    def datafile_path(self) -> pathlib.Path | None:
        """
        Returns the configured path to the mf4 capture data file.
        None if not configured.
        """
        return self._capture.datafile_path

    @property
    def variables(self) -> typing.Iterable[FrameworkVariable]:
        """
        Collection of alias identifer to capture
        """
        return self._capture.variables

    @property
    def raster_name(self) -> str | None:
        """
        Task name for capture process
        """
        return self._capture.raster_name

    def start(self) -> None:
        """
        Start the capture
        """
        self._capture.start()

    def stop(self) -> None:
        """
        Stop the capture
        """
        self._capture.stop()

    def release(self) -> None:
        """
        Release the capture
        """
        if self._capture:
            self._capture.release()

    def get_signal(self, key: str | FrameworkVariable) -> Series:
        """
        Get an pandas.series object for captured variable.
        """
        signal = self._capture.get_signal(key)
        if not signal.name:
            signal.name = key.id if isinstance(key, FrameworkVariable) else str(key)
        return signal

    def get_data_frame(self) -> DataFrame:
        """
        Get all measured data as pandas.dataframe
        """
        return self._capture.get_data_frame()

    def __getitem__(self, key: str | FrameworkVariable) -> Series:
        return self._capture.get_signal(key)


class MultiPortCapturing:
    """
    Context Manager to start the capturing of Framework variables.
    Note, that a capture is always port specific and thus capturing of variables is limited to a single port.

    In opposite to the `Capturing` context manager, here
    the provided `FrameworkVariables` are looked up in the provided mapping, and a single capture for each port is started.
    The subordinated captures are started in port order and are in general not synchronized.
    This is merely a convenience to create and start several port specific captures, without having to know the concrete port for the FrameworkVariables

    NOTE,
    if all ports are dSPACE XIL API Ports, the returned signals are shifted in time,
    such that the timestamp 0.0 corresponds always to the start time of the last started capture.
    That means that signals from captures started earlier have also negative timestamps.

    Instances of this class can act as context managers, which `start` on entering the context and `stop`
    when the context is exited.

    ```python
    ta.vars.TurnSignalLever = 0

    with MultiPortCapturing([ta.vars.TurnSignalFrontLeft, ta.vars.TurnSignalFrontRight,]) as capture:
        sleep(1)
        ta.vars..TurnSignalLever = 1
        sleep(1)
        ta.vars..TurnSignalLever = 0

    # assert that left signal is at least once flashing, contains on and off
    assert (capture[ta.vars.TurnSignalFrontLeft] == 1).any()
    assert (capture[ta.vars.TurnSignalFrontLeft] == 0).any()

    # assert that right signal is constant off
    assert (capture.TurnSignalFrontRight == 0).all()
    ```
    """

    def __init__(
        self,
        variables: typing.Iterable[str | FrameworkVariable],
        raster_name: str | None = None,
        datafile_path: str | PathLike[str] | None = None,
    ) -> None:
        reg = Registry()
        variables = [
            var if isinstance(var, FrameworkVariable) else reg.get_framework_variable(var) for var in variables
        ]
        if len(variables) == 0:
            raise Exception("Variables list must not be empty")

        # Determine port of for each configured framework variable
        variables_by_port: collections.defaultdict[str, list[FrameworkVariable]] = collections.defaultdict(list)
        for alias in variables:
            port_var = reg.get_port_variable(alias)
            variables_by_port[port_var.port_id].append(alias)

        self._datafile_path = pathlib.Path(datafile_path) if datafile_path is not None else None

        self._capture_zero_point = None

        # Create a capture item for each port with corresponding framework variables.
        # Configure and store it.
        capture_items: dict[str, Capturing] = {}
        self._capture_items: OrderedDict[str, Capturing] = OrderedDict()
        for port_name, framework_variables in variables_by_port.items():
            mf4path = (
                self._datafile_path / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{port_name}.mf4"
                if self._datafile_path is not None
                else None
            )
            capture_items[port_name] = Capturing(
                variables=framework_variables,
                raster_name=raster_name,
                datafile_path=mf4path,
            )

        # copy local `capture_items` to OrderedDict member, ordered by port order!
        for port in reg.get_ports():
            if port.name in capture_items:
                self._capture_items[port.name] = capture_items[port.name]

    def __enter__(self) -> typing.Self:
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> bool | None:
        self.stop()
        self.release()

    @property
    def datafile_path(self) -> pathlib.Path | None:
        """
        Returns the configured path to the mf4 capture data file.
        None if not configured.
        """
        return self._datafile_path

    @property
    def datafiles(self) -> dict[str, pathlib.Path]:
        """
        Returns a map of portname to capture result filepath
        """
        return {name: cap.datafile_path for name, cap in self._capture_items.items() if cap.datafile_path is not None}

    def start(self) -> None:
        """
        Iterate all capture items and start them due to order of port
        """
        for capture in self._capture_items.values():
            capture.start()

    def stop(self) -> None:
        """
        Iterate all capture items and stop them
        """
        for capture in reversed(self._capture_items.values()):
            capture.stop()

        # If all captures stop call finialize for post capture actions.
        self._capture_zero_point = self._determine_max_capture_start_time()

    def release(self) -> None:
        """
        Iterate all capture items and release them
        """
        for capture in self._capture_items.values():
            capture.release()

    def get_signal(self, key: str | FrameworkVariable) -> Series:
        # Determine capture object belonging to port and get signal from this capture item.
        capture = self._capture_items[Registry().get_port_variable(key).port_id]
        series = capture.get_signal(key)

        # Check if a signal must be shifted to allign x-Axis value with other signals.
        # That means that the x-axis zero value of each signal belongs to the same simulation time value.
        # The member capture_zero_point holds the highest x axis simulation time value of all (XIL) captures.
        # Note: Signals will only be shifted if only XIL API captures has been used.
        if self._capture_zero_point:
            # Ducktyping to detect XILCapture (with support of CaptureStartTime)
            if hasattr(capture._capture, "_capture_result"):
                capture_start_time = capture._capture._capture_result.CaptureStartTime
                shift_value = capture_start_time - self._capture_zero_point
                if shift_value < 0:
                    series.index = series.index + shift_value
        return series

    def __getitem__(self, key: str | FrameworkVariable) -> Series:
        return self.get_signal(key)

    def get_data_frames_by_port(self) -> dict[str, DataFrame]:
        """
        Collects and returns all data frames from the individual capture items.

        Each capture item represents a sub-capture associated with a specific port name.
        This method iterates over all capture items and retrieves their corresponding
        pandas DataFrame, returning a dictionary that maps each port name to its data.

        Returns:
            dict[str, DataFrame]: A dictionary where each key is a port name (str),
            and each value is the corresponding pandas DataFrame containing the
            captured data for that port.
        """
        return {name: cap.get_data_frame() for name, cap in self._capture_items.items()}

    def get_data_frame(self) -> DataFrame:
        """
        Aggregates all measured signals from the available capture items into a single pandas DataFrame.

        This method iterates over all capture items and collects their individual signal variables.
        Each signal is retrieved using `get_signal(var)` and added to a dictionary with the variable
        name as the key. The resulting signals are concatenated along the columns (axis=1), aligning
        them by index. Missing values are automatically filled with NaN to ensure consistent alignment.

        Returns:
            pandas.DataFrame: A DataFrame containing all collected signals, with each column
            representing a signal variable and rows aligned by index.
        """
        signals = {
            str(var): self.get_signal(var) for capture in self._capture_items.values() for var in capture.variables
        }
        # When concatenating along the columns (axis=1), a DataFrame is returned.
        return pd.concat(signals, axis=1)

    def _determine_max_capture_start_time(self) -> float | None:
        """
        Determine the maximum CaptureStartTime of all XIL API Captures,
        assuming that they are using the same "clock".
        If all subordinated captures are XIL API Captures, then return the maximum CaptureStartTime,
        otherwise None.
        """
        start_times: list[float] = [
            capture._capture._capture_result.CaptureStartTime
            for capture in self._capture_items.values()
            if hasattr(capture._capture, "_capture_result") and capture._capture._capture_result is not None
        ]

        if start_times and len(start_times) == len(self._capture_items):
            return max(start_times)

        # else
        return None
